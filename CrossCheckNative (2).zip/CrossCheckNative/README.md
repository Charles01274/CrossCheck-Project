# CrossCheck – 네이티브 안드로이드 프로젝트 (Empty Views Activity)

Figma Make로 디자인한 UI(색상·타이포·레이아웃)를 **WebView 없이** Kotlin + XML(Views)
네이티브 코드로 그대로 옮긴 프로젝트입니다. `Empty Views Activity` 템플릿과 동일하게
XML 레이아웃 + `findViewById` 방식을 사용했고, Jetpack Compose는 쓰지 않았습니다.

## 화면 구성 (원본 4개 화면 그대로)
| 원본 (React) | 네이티브 구현 |
|---|---|
| `NewsFeedScreen.tsx` | `ui/feed/NewsFeedFragment.kt` + `fragment_news_feed.xml` |
| `PerspectiveScreen.tsx` | `ui/perspective/PerspectiveFragment.kt` + `fragment_perspective.xml` |
| `ChatScreen.tsx` | `ui/chat/ChatFragment.kt` + `fragment_chat.xml` |
| `TutorialScreen.tsx` | `ui/tutorial/TutorialFragment.kt` + `fragment_tutorial.xml` |
| `FontBar.tsx` | `ui/common/FontBarView.kt` (재사용 커스텀 뷰, 모든 화면 상단에 포함) |
| `theme.ts` (LIGHT/DARK 팔레트) | `res/values/colors.xml` (라이트) / `res/values-night/colors.xml` (다크) |

`MainActivity`가 하단 `BottomNavigationView`로 4개의 `Fragment`를 전환합니다
(원본 `App.tsx`의 `screen` state 전환과 동일한 구조).

## 주요 기능
- **글씨 크기 3단계 조절 + 다크모드 토글** — 모든 화면 우측 상단 FontBar에서 가능하고,
  `AppViewModel`(공유 ViewModel)로 화면 전환 후에도 상태가 유지됩니다.
- **뉴스 피드** — 카테고리 탭 + 리드 기사 카드 + 목록 (RecyclerView, 2가지 뷰 타입)
- **시각 비교** — AI 3줄 요약, 진보/보수 세그먼트 탭, 관련 영상 가로 스크롤
- **AI 챗봇** — 프리셋 질문 칩 + 채팅 말풍선(RecyclerView) + 입력창 (мок 응답 1.2초 지연)
- **가이드** — 4단계 인터랙티브 튜토리얼 (카드 탭 → 글씨 크기 체험 → 좌우 비교 → 마이크 체험)

## 열기 전에 알아둘 것
- **이미지는 인터넷에서 불러옵니다** (Glide + Unsplash URL). 에뮬레이터/기기가
  인터넷에 연결되어 있어야 뉴스 썸네일이 보입니다. (`INTERNET` 권한은 이미 추가됨)
- Gradle Wrapper(`gradlew`, `gradle-wrapper.jar`)가 프로젝트에 **이미 포함**되어 있어서
  "Create Gradle Wrapper" 단계 없이 바로 동기화가 시작됩니다.

## 여는 방법
1. zip 압축을 **먼저 해제**하세요 (zip 파일 자체를 열면 안 됩니다).
2. 안드로이드 스튜디오 → **File > Open** → 압축 해제한 `CrossCheckNative` 폴더 선택.
3. Gradle Sync가 자동 시작됩니다. 완료될 때까지 기다리세요 (Gradle 8.7 + AGP 8.5.2 사용).
4. 상단 실행 대상이 `app`인지 확인 → 에뮬레이터 선택 → 초록색 ▶ **Run**.

## Sync가 실패한다면
| 증상 | 해결 |
|---|---|
| SDK를 찾을 수 없음 | Settings > Languages & Frameworks > Android SDK에서 **API 34** 설치 확인 |
| Gradle JDK 오류 | Settings > Build Tools > Gradle에서 **Gradle JDK 17 이상**으로 설정 |
| 다운로드 멈춤/타임아웃 | 방화벽/VPN이 `services.gradle.org`, `dl.google.com`을 막는지 확인 |
| 그래도 실패 | 상단 "Open 'Build' View"에 뜨는 빨간 오류 문구를 그대로 복사해서 알려주세요 |

## 디자인을 더 다듬고 싶다면
- 색상은 `res/values/colors.xml`(라이트) / `res/values-night/colors.xml`(다크) 두 곳만
  고치면 앱 전체에 반영됩니다.
- 각 화면의 문구는 대부분 `res/values/strings.xml`에 있고, 목업 뉴스/영상 데이터는
  `model/NewsItem.kt`의 `SampleData` 객체에 있습니다.
- 실제 뉴스 API 연동이 필요하면 `SampleData`를 네트워크 호출(Retrofit 등)로 교체하면 됩니다.
