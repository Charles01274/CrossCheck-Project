package com.silveriron.crosscheck.ui.tutorial

import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.ui.common.FontBarView

class TutorialFragment : Fragment(R.layout.fragment_tutorial) {

    private val totalSteps = 4
    private var step = 0
    private var done = false

    // per-step interaction state
    private var cardTapped = false
    private var fontDemoSize = 16
    private var fontTapped = false
    private var perspectiveTab: String? = null // "left" | "right" | null
    private var tappedLeft = false
    private var tappedRight = false
    private var micActive = false
    private var micDone = false

    private lateinit var stepCountText: TextView
    private lateinit var stepStatusText: TextView
    private lateinit var progressBar: LinearLayout
    private lateinit var stepNumberText: TextView
    private lateinit var stepTitleText: TextView
    private lateinit var stepSubtitleText: TextView
    private lateinit var contentContainer: FrameLayout
    private lateinit var btnPrev: View
    private lateinit var btnNext: View
    private lateinit var btnNextText: TextView

    private data class StepMeta(val number: Int, val title: String, val subtitle: String)

    private val stepsMeta = listOf(
        StepMeta(1, "뉴스 카드 눌러보기", "기사를 탭하면 어떻게 되는지 확인해요"),
        StepMeta(2, "글씨 크기 조절하기", "눈에 편한 크기로 바꿀 수 있어요"),
        StepMeta(3, "두 시각 비교하기", "진보·보수 두 탭을 모두 눌러보세요"),
        StepMeta(4, "AI에게 말로 물어보기", "마이크를 눌러 직접 체험해 보세요")
    )

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel

        val fontBar = view.findViewById<FontBarView>(R.id.fontBar)
        fontBar.listener = object : FontBarView.Listener {
            override fun onLevelChanged(newLevel: Int) = appViewModel.setLevel(newLevel)
            override fun onToggleContrast() = appViewModel.toggleContrast()
        }
        appViewModel.level.observe(viewLifecycleOwner) { level ->
            fontBar.bind(level, appViewModel.highContrast.value ?: false)
        }
        appViewModel.highContrast.observe(viewLifecycleOwner) { hc ->
            fontBar.bind(appViewModel.level.value ?: 1, hc)
        }

        stepCountText = view.findViewById(R.id.stepCountText)
        stepStatusText = view.findViewById(R.id.stepStatusText)
        progressBar = view.findViewById(R.id.progressBar)
        stepNumberText = view.findViewById(R.id.stepNumberText)
        stepTitleText = view.findViewById(R.id.stepTitleText)
        stepSubtitleText = view.findViewById(R.id.stepSubtitleText)
        contentContainer = view.findViewById(R.id.stepContentContainer)
        btnPrev = view.findViewById(R.id.btnPrev)
        btnNext = view.findViewById(R.id.btnNext)
        btnNextText = view.findViewById(R.id.btnNextText)

        btnPrev.setOnClickListener {
            if (step > 0) {
                step -= 1
                done = true
                renderStep()
            }
        }
        btnNext.setOnClickListener {
            if (!done) return@setOnClickListener
            if (step == totalSteps - 1) {
                activity.navigateTo(MainActivity.Screen.FEED)
            } else {
                step += 1
                done = false
                renderStep()
            }
        }

        renderStep()
    }

    private fun renderStep() {
        stepCountText.text = "${step + 1} / $totalSteps 단계"
        stepStatusText.text = if (done) "완료됨" else "아래를 눌러보세요"
        stepStatusText.setTextColor(color(if (done) R.color.green else R.color.faint))

        progressBar.removeAllViews()
        for (i in 0 until totalSteps) {
            val filled = i < step || (i == step && done)
            val segment = View(requireContext())
            val params = LinearLayout.LayoutParams(0, dp(6), 1f)
            params.marginEnd = if (i < totalSteps - 1) dp(6) else 0
            segment.layoutParams = params
            segment.setBackgroundResource(if (filled) R.drawable.bg_progress_filled else R.drawable.bg_progress_empty)
            progressBar.addView(segment)
        }

        val meta = stepsMeta[step]
        stepNumberText.text = meta.number.toString()
        stepTitleText.text = meta.title
        stepSubtitleText.text = meta.subtitle

        contentContainer.removeAllViews()
        contentContainer.addView(
            when (step) {
                0 -> buildStep0()
                1 -> buildStep1()
                2 -> buildStep2()
                else -> buildStep3()
            }
        )

        btnPrev.visibility = if (step > 0) View.VISIBLE else View.GONE
        btnNext.isEnabled = done
        btnNext.setBackgroundResource(
            when {
                !done -> R.drawable.bg_segment_track
                step == totalSteps - 1 -> R.drawable.bg_pill_green
                else -> R.drawable.bg_pill_primary
            }
        )
        btnNextText.text = when {
            !done -> getString(R.string.tutorial_locked_next)
            step == totalSteps - 1 -> getString(R.string.tutorial_start)
            else -> getString(R.string.tutorial_next)
        }
        btnNextText.setTextColor(
            color(if (!done) R.color.faint else if (step == totalSteps - 1) R.color.white else R.color.onPrimary)
        )
    }

    // ---- STEP 0 : tap the news card ----
    private fun buildStep0(): View {
        val container = column()
        container.addView(callout("아래 뉴스 카드를 한 번 눌러보세요. 기사 상세 화면으로 이동합니다."))

        val card = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(if (cardTapped) R.drawable.bg_solid_green_border else R.drawable.bg_dashed_ink)
            layoutParams = topMargin(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 16)
        }
        val image = ImageView(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(150))
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bg_surface_card)
        }
        Glide.with(image).load("https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&h=300&fit=crop&auto=format").centerCrop().into(image)
        card.addView(image)

        val textBox = column().apply { setPadding(dp(16), dp(14), dp(16), dp(14)) }
        textBox.addView(textView("오늘의 이슈", R.color.red, 12f, true))
        textBox.addView(textView("국회, 건강보험 개혁안 놓고 여야 대립", R.color.ink, 17f, true).apply {
            setPadding(0, dp(6), 0, 0)
        })
        card.addView(textBox)
        card.setOnClickListener {
            cardTapped = true
            done = true
            renderStep()
        }
        container.addView(card)
        return container
    }

    // ---- STEP 1 : font size demo ----
    private fun buildStep1(): View {
        val container = column()
        container.addView(callout("오른쪽 A+ 버튼을 눌러보세요. 글씨 크기가 바뀝니다. 이 문장을 보세요."))

        val demoBox = column().apply {
            setBackgroundResource(R.drawable.bg_surface_bordered)
            setPadding(dp(20), dp(24), dp(20), dp(24))
            layoutParams = topMargin(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 16)
        }
        val demoText = textView("글씨 크기가 바뀝니다.\n이 문장을 보세요.", R.color.ink, fontDemoSize.toFloat(), true).apply {
            gravity = Gravity.CENTER
        }
        demoBox.addView(demoText)

        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = topMargin(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 20)
        }
        val minusBtn = squareButton("A−", dp(56), R.drawable.bg_surface_bordered, R.color.ink, 15f)
        minusBtn.setOnClickListener {
            fontDemoSize = (fontDemoSize - 2).coerceAtLeast(12)
            demoText.textSize = fontDemoSize.toFloat()
        }
        val sizeLabel = column().apply {
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.marginStart = dp(20); lp.marginEnd = dp(20)
            layoutParams = lp
        }
        sizeLabel.addView(textView("현재 크기", R.color.faint, 11f, false).apply { gravity = Gravity.CENTER })
        sizeLabel.addView(textView(fontDemoSize.toString(), R.color.ink, 24f, true).apply { gravity = Gravity.CENTER })
        val plusBtn = squareButton(
            "A+", dp(66),
            if (fontTapped) R.drawable.bg_circle_step_green else R.drawable.bg_circle_primary,
            if (fontTapped) R.color.white else R.color.onPrimary, 18f
        )
        plusBtn.setOnClickListener {
            fontDemoSize = (fontDemoSize + 2).coerceAtMost(26)
            demoText.textSize = fontDemoSize.toFloat()
            fontTapped = true
            done = true
            renderStep()
        }
        row.addView(minusBtn); row.addView(sizeLabel); row.addView(plusBtn)
        demoBox.addView(row)
        container.addView(demoBox)

        if (fontTapped) {
            container.addView(success("잘 하셨어요! 모든 화면 오른쪽 위에서 항상 조절할 수 있어요.").apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(16)
            })
        }
        return container
    }

    // ---- STEP 2 : left/right perspective tabs ----
    private fun buildStep2(): View {
        val container = column()
        container.addView(callout("파란 버튼과 빨간 버튼을 모두 눌러 두 시각의 차이를 확인해 보세요."))

        val segmentTrack = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundResource(R.drawable.bg_segment_track)
            setPadding(dp(4), dp(4), dp(4), dp(4))
            layoutParams = topMargin(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 16)
        }
        val leftTab = segmentTabView("진보·여당", R.color.blue, perspectiveTab == "left", tappedLeft)
        val rightTab = segmentTabView("보수·야당", R.color.red, perspectiveTab == "right", tappedRight)
        leftTab.layoutParams = LinearLayout.LayoutParams(0, dp(50), 1f)
        rightTab.layoutParams = LinearLayout.LayoutParams(0, dp(50), 1f)
        leftTab.setOnClickListener {
            perspectiveTab = "left"; tappedLeft = true
            if (tappedLeft && tappedRight) done = true
            renderStep()
        }
        rightTab.setOnClickListener {
            perspectiveTab = "right"; tappedRight = true
            if (tappedLeft && tappedRight) done = true
            renderStep()
        }
        segmentTrack.addView(leftTab); segmentTrack.addView(rightTab)
        container.addView(segmentTrack)

        val resultBox = column().apply {
            layoutParams = topMargin(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 14)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        when (perspectiveTab) {
            "left" -> {
                resultBox.setBackgroundResource(R.drawable.bg_blue_tint_card)
                resultBox.addView(textView("“오래 기다려온 의료 복지의 진전”", R.color.blueText, 16f, true))
                resultBox.addView(textView("진보 언론은 이번 개혁안이 약값 부담으로 고통받는 어르신을 위한 필수 조치라고 강조합니다.", R.color.blueText, 15f, false).apply {
                    setPadding(0, dp(8), 0, 0)
                })
            }
            "right" -> {
                resultBox.setBackgroundResource(R.drawable.bg_red_tint_card)
                resultBox.addView(textView("“정부 개입이 신약 개발 의지를 꺾는다”", R.color.redText, 16f, true))
                resultBox.addView(textView("보수 언론은 가격 통제가 제약사의 연구개발 투자를 위축시킬 수 있다고 경고합니다.", R.color.redText, 15f, false).apply {
                    setPadding(0, dp(8), 0, 0)
                })
            }
            else -> {
                resultBox.setBackgroundResource(R.drawable.bg_surface2_bordered)
                resultBox.gravity = Gravity.CENTER
                resultBox.minimumHeight = dp(80)
                resultBox.addView(textView("위 버튼을 누르면 내용이 나타납니다", R.color.faint, 15f, false))
            }
        }
        container.addView(resultBox)

        if (tappedLeft && tappedRight) {
            container.addView(success("두 시각을 모두 확인하셨어요! 이제 편향 없이 뉴스를 읽을 수 있어요.").apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(14)
            })
        }
        return container
    }

    // ---- STEP 3 : mic demo ----
    private fun buildStep3(): View {
        val container = column()
        container.addView(callout("아래 마이크 버튼을 눌러보세요. AI가 말을 듣고 답해줍니다."))

        val box = column().apply {
            setBackgroundResource(if (micDone) R.drawable.bg_solid_green_border else R.drawable.bg_dashed_ink)
            setPadding(dp(20), dp(20), dp(20), dp(20))
            layoutParams = topMargin(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 16)
        }

        val bubbleRow = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
        }
        val avatar = FrameLayout(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(30))
            setBackgroundResource(R.drawable.bg_badge_primary)
        }
        val avatarIcon = ImageView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(dp(15), dp(15), Gravity.CENTER)
            setImageResource(R.drawable.ic_star_ai)
            setColorFilter(color(R.color.onPrimary))
        }
        avatar.addView(avatarIcon)
        bubbleRow.addView(avatar)

        val bubble = textView(
            if (micDone) "이번 건강보험 개혁은 많은 어르신의 약값을 낮춰드리는 중요한 법안입니다. 쉽게 말씀드리면, 지금보다 더 적은 돈으로 약을 살 수 있게 해주는 제도예요."
            else "안녕하세요! 마이크를 눌러 궁금한 것을 말씀해 보세요.",
            R.color.ink, 15f, false
        ).apply {
            setBackgroundResource(R.drawable.bg_bubble_ai)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(8)
            layoutParams = lp
        }
        bubbleRow.addView(bubble)
        box.addView(bubbleRow)

        if (micActive || micDone) {
            val userBubbleRow = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
                layoutParams = topMargin(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 12)
            }
            userBubbleRow.addView(textView("이 뉴스 쉽게 설명해줘", R.color.onPrimary, 15f, false).apply {
                setBackgroundResource(R.drawable.bg_bubble_user)
                setPadding(dp(16), dp(12), dp(16), dp(12))
            })
            box.addView(userBubbleRow)
        }

        val micRow = column().apply {
            gravity = Gravity.CENTER
            layoutParams = topMargin(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 12)
        }
        if (!micDone) {
            micRow.addView(textView("이 버튼을 눌러보세요", R.color.faint, 12f, false).apply { gravity = Gravity.CENTER })
        }
        val micBtn = FrameLayout(requireContext()).apply {
            layoutParams = topMargin(dp(72), dp(72), 8)
            setBackgroundResource(
                when {
                    micDone -> R.drawable.bg_circle_step_green
                    micActive -> R.drawable.bg_circle_red
                    else -> R.drawable.bg_circle_primary
                }
            )
            isClickable = true
            isFocusable = true
        }
        val micIcon = ImageView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
            setImageResource(if (micDone) R.drawable.ic_check else R.drawable.ic_mic)
            setColorFilter(color(if (micDone) R.color.white else R.color.onPrimary))
        }
        micBtn.addView(micIcon)
        micBtn.setOnClickListener {
            if (micDone) return@setOnClickListener
            micActive = true
            renderStep()
            Handler(Looper.getMainLooper()).postDelayed({
                if (!isAdded) return@postDelayed
                micActive = false
                micDone = true
                done = true
                renderStep()
            }, 2200)
        }
        micRow.addView(micBtn)
        box.addView(micRow)
        container.addView(box)

        if (micDone) {
            container.addView(success("훌륭하세요! 이제 CrossCheck를 자유롭게 사용하실 수 있어요.").apply {
                (layoutParams as LinearLayout.LayoutParams).topMargin = dp(14)
            })
        }
        return container
    }

    // ---- small view builders ----
    private fun column() = LinearLayout(requireContext()).apply { orientation = LinearLayout.VERTICAL }

    private fun topMargin(w: Int, h: Int, marginDp: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(marginDp) }

    private fun textView(text: String, colorRes: Int, sizeSp: Float, bold: Boolean) =
        TextView(requireContext()).apply {
            this.text = text
            setTextColor(color(colorRes))
            textSize = sizeSp
            setLineSpacing(0f, 1.6f)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun callout(text: String): View {
        val tv = textView(text, R.color.ink, 15f, false)
        tv.setBackgroundResource(R.drawable.bg_surface_bordered)
        tv.setPadding(dp(16), dp(12), dp(16), dp(12))
        return tv
    }

    private fun success(text: String): View {
        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_green_tint_card)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
        val icon = ImageView(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
            setImageResource(R.drawable.ic_check)
            setColorFilter(color(R.color.green))
        }
        row.addView(icon)
        row.addView(textView(text, R.color.green, 15f, true).apply {
            val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginStart = dp(10)
            layoutParams = lp
        })
        return row
    }

    private fun squareButton(label: String, size: Int, bgRes: Int, colorRes: Int, textSp: Float): FrameLayout {
        val btn = FrameLayout(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(size, size)
            setBackgroundResource(bgRes)
            isClickable = true
            isFocusable = true
        }
        btn.addView(TextView(requireContext()).apply {
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
            text = label
            setTextColor(color(colorRes))
            textSize = textSp
            setTypeface(typeface, Typeface.BOLD)
        })
        return btn
    }

    private fun segmentTabView(label: String, colorRes: Int, selected: Boolean, tapped: Boolean): LinearLayout {
        val tab = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            if (selected) setBackgroundResource(R.drawable.bg_segment_selected)
        }
        val dot = View(requireContext()).apply {
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9))
            setBackgroundResource(if (tapped) R.drawable.bg_circle_green_flat else R.drawable.bg_circle_flat_generic)
            if (!tapped) background.setTint(color(colorRes))
        }
        tab.addView(dot)
        tab.addView(textView(label, if (selected) colorRes else R.color.ink2, 13f, true).apply {
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.marginStart = dp(6)
            layoutParams = lp
        })
        return tab
    }

    private fun color(res: Int) = resources.getColor(res, requireContext().theme)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
