package com.silveriron.crosscheck.model

data class ChatMessage(
    val id: Long,
    val isUser: Boolean,
    val text: String
)
