package com.silveriron.crosscheck.ui.feed

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.NewsItem

class NewsFeedAdapter(
    private var items: List<NewsItem>,
    private val onClick: (NewsItem) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_LEAD = 0
        private const val TYPE_ROW = 1
    }

    fun submitList(newItems: List<NewsItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int) = if (position == 0) TYPE_LEAD else TYPE_ROW

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_LEAD) {
            LeadViewHolder(inflater.inflate(R.layout.item_news_lead, parent, false))
        } else {
            RowViewHolder(inflater.inflate(R.layout.item_news_row, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        when (holder) {
            is LeadViewHolder -> holder.bind(item, onClick)
            is RowViewHolder -> holder.bind(item, position == 1, onClick)
        }
    }

    class LeadViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val image: android.widget.ImageView = view.findViewById(R.id.leadImage)
        private val tag: android.widget.TextView = view.findViewById(R.id.leadTag)
        private val time: android.widget.TextView = view.findViewById(R.id.leadTime)
        private val title: android.widget.TextView = view.findViewById(R.id.leadTitle)
        private val summary: android.widget.TextView = view.findViewById(R.id.leadSummary)
        private val perspectiveCount: android.widget.TextView = view.findViewById(R.id.leadPerspectiveCount)

        fun bind(item: NewsItem, onClick: (NewsItem) -> Unit) {
            tag.text = item.tag.uppercase()
            time.text = "· ${item.time}"
            title.text = item.title
            summary.text = item.summary
            perspectiveCount.text = "${item.perspectives}개 시각 비교"
            Glide.with(image).load(item.imageUrl).centerCrop().into(image)
            itemView.setOnClickListener { onClick(item) }
        }
    }

    class RowViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val divider: View = view.findViewById(R.id.rowDivider)
        private val image: android.widget.ImageView = view.findViewById(R.id.rowImage)
        private val tag: android.widget.TextView = view.findViewById(R.id.rowTag)
        private val time: android.widget.TextView = view.findViewById(R.id.rowTime)
        private val title: android.widget.TextView = view.findViewById(R.id.rowTitle)
        private val perspectiveCount: android.widget.TextView = view.findViewById(R.id.rowPerspectiveCount)

        fun bind(item: NewsItem, isFirstRow: Boolean, onClick: (NewsItem) -> Unit) {
            divider.visibility = if (isFirstRow) View.GONE else View.VISIBLE
            tag.text = item.tag.uppercase()
            time.text = "· ${item.time}"
            title.text = item.title
            perspectiveCount.text = "${item.perspectives}개 시각"
            Glide.with(image).load(item.imageUrl).centerCrop().into(image)
            itemView.setOnClickListener { onClick(item) }
        }
    }
}
