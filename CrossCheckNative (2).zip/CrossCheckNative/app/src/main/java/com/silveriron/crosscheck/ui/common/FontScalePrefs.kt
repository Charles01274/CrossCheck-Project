package com.silveriron.crosscheck.ui.common

import android.content.Context

/**
 * Persists the user's chosen text-size level (1–3) and converts it into an
 * Android `Configuration.fontScale` multiplier. MainActivity applies that
 * scale in `attachBaseContext()`, which is what actually makes every `sp`
 * text size in the app grow/shrink — the FontBar view itself only draws its
 * own buttons/dots and never resized real content on its own.
 */
object FontScalePrefs {
    private const val PREFS_NAME = "crosscheck_prefs"
    private const val KEY_LEVEL = "font_level"

    fun getLevel(context: Context): Int =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getInt(KEY_LEVEL, 1)

    fun setLevel(context: Context, level: Int) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_LEVEL, level)
            .apply()
    }

    /** Matches theme.ts LEVEL_SIZE ratios (16 / 19 / 22sp) as a scale multiplier. */
    fun scaleForLevel(level: Int): Float = when (level) {
        1 -> 1.0f
        2 -> 1.1875f
        else -> 1.375f
    }
}
