package com.silveriron.crosscheck

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.silveriron.crosscheck.ui.chat.ChatFragment
import com.silveriron.crosscheck.ui.common.AppViewModel
import com.silveriron.crosscheck.ui.common.FontScalePrefs
import com.silveriron.crosscheck.ui.feed.NewsFeedFragment
import com.silveriron.crosscheck.ui.perspective.PerspectiveFragment
import com.silveriron.crosscheck.ui.tutorial.TutorialFragment

class MainActivity : AppCompatActivity() {

    lateinit var appViewModel: AppViewModel
        private set

    private lateinit var bottomNav: BottomNavigationView
    private var currentScreen = Screen.FEED

    /**
     * Applies the persisted text-size level as a real Configuration.fontScale
     * BEFORE the activity inflates any view. This is what makes every `sp`
     * text size in every screen (including RecyclerView rows and the
     * programmatically-built Tutorial/Perspective views) actually grow or
     * shrink -- not just the FontBar's own buttons.
     */
    override fun attachBaseContext(newBase: Context) {
        val level = FontScalePrefs.getLevel(newBase)
        val config = Configuration(newBase.resources.configuration)
        config.fontScale = FontScalePrefs.scaleForLevel(level)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        appViewModel = ViewModelProvider(this)[AppViewModel::class.java]
        bottomNav = findViewById(R.id.bottomNav)

        if (savedInstanceState != null) {
            currentScreen = Screen.values()[savedInstanceState.getInt(KEY_CURRENT_SCREEN, 0)]
        }
        // Keep the bottom-nav highlight correct after a recreate() without
        // re-triggering a redundant fragment replace (the fragment itself is
        // already restored automatically by the FragmentManager).
        bottomNav.menu.findItem(menuIdFor(currentScreen))?.isChecked = true

        if (savedInstanceState == null) {
            showScreen(Screen.FEED)
        }

        bottomNav.setOnItemSelectedListener { item ->
            val screen = when (item.itemId) {
                R.id.nav_feed -> Screen.FEED
                R.id.nav_perspective -> Screen.PERSPECTIVE
                R.id.nav_chat -> Screen.CHAT
                else -> Screen.TUTORIAL
            }
            currentScreen = screen
            showScreen(screen)
            true
        }

        // The FontBar only reports the new level; actually applying it requires
        // a fresh Configuration (set in attachBaseContext above), so recreate
        // the activity whenever the level really changes.
        appViewModel.level.observe(this) { level ->
            if (level != FontScalePrefs.getLevel(this)) {
                FontScalePrefs.setLevel(this, level)
                recreate()
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_CURRENT_SCREEN, currentScreen.ordinal)
    }

    enum class Screen { FEED, PERSPECTIVE, CHAT, TUTORIAL }

    /** Lets fragments navigate the way `setScreen()` does in the original React app. */
    fun navigateTo(screen: Screen) {
        currentScreen = screen
        bottomNav.selectedItemId = menuIdFor(screen)
        showScreen(screen)
    }

    private fun menuIdFor(screen: Screen) = when (screen) {
        Screen.FEED -> R.id.nav_feed
        Screen.PERSPECTIVE -> R.id.nav_perspective
        Screen.CHAT -> R.id.nav_chat
        Screen.TUTORIAL -> R.id.nav_tutorial
    }

    private fun showScreen(screen: Screen) {
        val fragment: Fragment = when (screen) {
            Screen.FEED -> NewsFeedFragment()
            Screen.PERSPECTIVE -> PerspectiveFragment()
            Screen.CHAT -> ChatFragment()
            Screen.TUTORIAL -> TutorialFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    companion object {
        private const val KEY_CURRENT_SCREEN = "current_screen"
    }
}
