package com.silveriron.crosscheck.model

data class NewsItem(
    val id: Int,
    val tag: String,
    val title: String,
    val summary: String,
    val imageUrl: String,
    val time: String,
    val perspectives: Int
)

object SampleData {
    val CATEGORIES = listOf("오늘의 이슈", "정치", "사회", "경제")

    val NEWS = listOf(
        NewsItem(
            id = 1,
            tag = "오늘의 이슈",
            title = "국회, 건강보험 개혁안 놓고 여야 대립",
            summary = "의약품 가격 인하와 급여 확대를 둘러싼 여야 충돌이 본회의 표결을 앞두고 격화되고 있습니다.",
            imageUrl = "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&h=500&fit=crop&auto=format",
            time = "2시간 전",
            perspectives = 4
        ),
        NewsItem(
            id = 2,
            tag = "경제",
            title = "한국은행, 기준금리 3개월째 동결 결정",
            summary = "물가·성장 혼조 속에 한은 금통위가 연 3.25% 금리를 유지하기로 했습니다.",
            imageUrl = "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=400&fit=crop&auto=format",
            time = "4시간 전",
            perspectives = 6
        ),
        NewsItem(
            id = 3,
            tag = "사회",
            title = "60대 이상 스마트폰 과다 사용, 수면 질 저하 연관",
            summary = "연구진은 취침 2시간 전 화면 사용을 줄이면 수면의 질이 크게 개선된다고 밝혔습니다.",
            imageUrl = "https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=400&h=400&fit=crop&auto=format",
            time = "6시간 전",
            perspectives = 3
        ),
        NewsItem(
            id = 4,
            tag = "정치",
            title = "지방선거 사전투표율 역대 최고 경신",
            summary = "4년 전 대비 18% 상승한 투표율로, 유권자들의 높은 관심이 반영됐습니다.",
            imageUrl = "https://images.unsplash.com/photo-1540910419892-4a36d2c3266c?w=400&h=400&fit=crop&auto=format",
            time = "8시간 전",
            perspectives = 5
        )
    )

    data class VideoItem(val id: Int, val title: String, val label: String, val duration: String, val thumbUrl: String)

    val VIDEOS = listOf(
        VideoItem(1, "건강보험 개혁안, 5분 만에 이해하기", "쉬운 해설", "5:12", "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=320&h=180&fit=crop&auto=format"),
        VideoItem(2, "어르신이 꼭 알아야 할 의약품 급여 변화", "생활 정보", "8:44", "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=320&h=180&fit=crop&auto=format"),
        VideoItem(3, "여야가 보는 의료 개혁, 어떻게 다른가", "심층 비교", "12:30", "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=320&h=180&fit=crop&auto=format")
    )
}
