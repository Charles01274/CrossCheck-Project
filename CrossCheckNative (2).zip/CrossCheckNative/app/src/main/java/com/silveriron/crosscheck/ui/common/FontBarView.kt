package com.silveriron.crosscheck.ui.common

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.silveriron.crosscheck.R

/**
 * Reusable accessibility bar shown on every screen (mirrors FontBar.tsx):
 *  - 3-step text size stepper (A− / level dots / A+)
 *  - Light / dark (high-contrast) mode toggle
 */
class FontBarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    interface Listener {
        fun onLevelChanged(newLevel: Int)
        fun onToggleContrast()
    }

    var listener: Listener? = null

    private val btnMinus: TextView
    private val btnPlus: TextView
    private val btnContrast: FrameLayout
    private val contrastIcon: ImageView
    private val dots: List<android.view.View>

    private var level = 1
    private var highContrast = false

    init {
        orientation = HORIZONTAL
        inflate(context, R.layout.view_font_bar, this)

        btnMinus = findViewById(R.id.btnMinus)
        btnPlus = findViewById(R.id.btnPlus)
        btnContrast = findViewById(R.id.btnContrast)
        contrastIcon = findViewById(R.id.contrastIcon)
        dots = listOf(findViewById(R.id.dot1), findViewById(R.id.dot2), findViewById(R.id.dot3))

        btnMinus.setOnClickListener {
            if (level > 1) {
                level -= 1
                listener?.onLevelChanged(level)
                refresh()
            }
        }
        btnPlus.setOnClickListener {
            if (level < 3) {
                level += 1
                listener?.onLevelChanged(level)
                refresh()
            }
        }
        btnContrast.setOnClickListener {
            highContrast = !highContrast
            listener?.onToggleContrast()
            refresh()
        }
    }

    /** Call once when the screen loads (and whenever shared state changes) to sync the UI. */
    fun bind(level: Int, highContrast: Boolean) {
        this.level = level.coerceIn(1, 3)
        this.highContrast = highContrast
        refresh()
    }

    private fun refresh() {
        btnMinus.alpha = if (level <= 1) 0.3f else 1f
        btnMinus.isEnabled = level > 1
        btnPlus.alpha = if (level >= 3) 0.4f else 1f
        btnPlus.isEnabled = level < 3

        val dp5 = (5 * resources.displayMetrics.density).toInt()
        val dp11 = (11 * resources.displayMetrics.density).toInt()
        dots.forEachIndexed { index, dot ->
            val n = index + 1
            val params = dot.layoutParams
            params.height = if (n == level) dp11 else dp5
            dot.layoutParams = params
            dot.setBackgroundResource(if (n <= level) R.drawable.bg_dot_active else R.drawable.bg_dot)
        }

        btnContrast.setBackgroundResource(
            if (highContrast) R.drawable.bg_contrast_toggle_on else R.drawable.bg_contrast_toggle_off
        )
        contrastIcon.setColorFilter(
            resources.getColor(if (highContrast) R.color.onPrimary else R.color.ink, context.theme)
        )
    }
}
