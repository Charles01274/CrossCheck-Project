package com.silveriron.crosscheck.ui.common

import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

/**
 * Mirrors the top-level state in App.tsx: `level` (1–3 text size) and
 * `highContrast` (dark palette on/off). Shared across every fragment so the
 * FontBar in each screen stays in sync no matter which tab is active.
 */
class AppViewModel : ViewModel() {

    private val _level = MutableLiveData(1)
    val level: LiveData<Int> = _level

    private val _highContrast = MutableLiveData(false)
    val highContrast: LiveData<Boolean> = _highContrast

    fun setLevel(n: Int) {
        _level.value = n.coerceIn(1, 3)
    }

    fun toggleContrast() {
        val newValue = !(_highContrast.value ?: false)
        _highContrast.value = newValue
        AppCompatDelegate.setDefaultNightMode(
            if (newValue) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    companion object {
        /** theme.ts LEVEL_SIZE — base body text size (sp) per level. */
        fun bodySizeSp(level: Int): Float = when (level) {
            1 -> 16f
            2 -> 19f
            else -> 22f
        }
    }
}
