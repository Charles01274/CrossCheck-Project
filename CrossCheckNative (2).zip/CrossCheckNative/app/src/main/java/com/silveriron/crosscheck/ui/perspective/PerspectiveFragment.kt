package com.silveriron.crosscheck.ui.perspective

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.flexbox.FlexboxLayout
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.SampleData
import com.silveriron.crosscheck.ui.common.FontBarView

class PerspectiveFragment : Fragment(R.layout.fragment_perspective) {

    private val summaryLines = listOf(
        "국회는 의약품 급여 확대를 위한 건강보험 개혁안을 표결에 부칠 예정입니다.",
        "찬성 측은 고령층 의약품 부담 완화를, 반대 측은 신약 개발 위축을 우려합니다.",
        "이번 개혁안은 전국 약 3,600만 명의 건강보험 가입자에게 직접 영향을 미칩니다."
    )
    private val leftKeywords = listOf("건강보험 보장성 강화", "의약품 접근성 확대", "공공 이익 우선")
    private val rightKeywords = listOf("시장 자율 해결", "신약 개발 투자 보호", "정부 역할 최소화")

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel

        view.findViewById<View>(R.id.btnBack).setOnClickListener {
            activity.navigateTo(MainActivity.Screen.FEED)
        }

        val fontBar = view.findViewById<FontBarView>(R.id.fontBar)
        fontBar.listener = object : FontBarView.Listener {
            override fun onLevelChanged(newLevel: Int) = appViewModel.setLevel(newLevel)
            override fun onToggleContrast() = appViewModel.toggleContrast()
        }
        appViewModel.level.observe(viewLifecycleOwner) { level ->
            fontBar.bind(level, appViewModel.highContrast.value ?: false)
        }
        appViewModel.highContrast.observe(viewLifecycleOwner) { hc ->
            fontBar.bind(appViewModel.level.value ?: 1, hc)
        }

        Glide.with(view)
            .load("https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&h=400&fit=crop&auto=format")
            .centerCrop()
            .into(view.findViewById(R.id.articleImage))

        val summaryList = view.findViewById<LinearLayout>(R.id.summaryList)
        summaryLines.forEachIndexed { i, line -> summaryList.addView(buildSummaryRow(i + 1, line)) }

        view.findViewById<View>(R.id.btnAskAi).setOnClickListener {
            activity.navigateTo(MainActivity.Screen.CHAT)
        }

        val leftKeywordsView = view.findViewById<FlexboxLayout>(R.id.leftKeywords)
        leftKeywords.forEach { leftKeywordsView.addView(buildChip(it, R.drawable.bg_chip_blue, R.color.blueText)) }
        val rightKeywordsView = view.findViewById<FlexboxLayout>(R.id.rightKeywords)
        rightKeywords.forEach { rightKeywordsView.addView(buildChip(it, R.drawable.bg_chip_red, R.color.redText)) }

        val tabLeft = view.findViewById<LinearLayout>(R.id.tabLeft)
        val tabRight = view.findViewById<LinearLayout>(R.id.tabRight)
        val tabLeftLabel = tabLeft.getChildAt(1) as TextView
        val tabRightLabel = tabRight.getChildAt(1) as TextView
        val leftContent = view.findViewById<View>(R.id.leftContent)
        val rightContent = view.findViewById<View>(R.id.rightContent)

        fun selectTab(left: Boolean) {
            tabLeft.setBackgroundResource(if (left) R.drawable.bg_segment_selected else 0)
            tabRight.setBackgroundResource(if (!left) R.drawable.bg_segment_selected else 0)
            tabLeftLabel.setTextColor(resources.getColor(if (left) R.color.blue else R.color.ink2, requireContext().theme))
            tabRightLabel.setTextColor(resources.getColor(if (!left) R.color.red else R.color.ink2, requireContext().theme))
            leftContent.visibility = if (left) View.VISIBLE else View.GONE
            rightContent.visibility = if (!left) View.VISIBLE else View.GONE
        }
        tabLeft.setOnClickListener { selectTab(true) }
        tabRight.setOnClickListener { selectTab(false) }
        selectTab(true)

        val videoRecycler = view.findViewById<RecyclerView>(R.id.videoRecycler)
        videoRecycler.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        videoRecycler.adapter = VideoAdapter(SampleData.VIDEOS)
    }

    private fun buildSummaryRow(number: Int, text: String): View {
        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, if (number > 1) dp(14) else 0, 0, 0)
        }
        val numberView = TextView(requireContext()).apply {
            this.text = number.toString()
            setTextColor(resources.getColor(R.color.faint, requireContext().theme))
            textSize = 18f
            setTypeface(android.graphics.Typeface.SERIF, android.graphics.Typeface.BOLD)
        }
        val textView = TextView(requireContext()).apply {
            this.text = text
            setTextColor(resources.getColor(R.color.ink, requireContext().theme))
            textSize = 15f
            setLineSpacing(0f, 1.7f)
            setPadding(dp(12), 0, 0, 0)
        }
        row.addView(numberView)
        row.addView(textView)
        return row
    }

    private fun buildChip(label: String, bgRes: Int, colorRes: Int): View {
        val tv = LayoutInflater.from(requireContext())
            .inflate(R.layout.item_keyword_chip, null) as TextView
        tv.text = label
        tv.setBackgroundResource(bgRes)
        tv.setTextColor(resources.getColor(colorRes, requireContext().theme))
        return tv
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    class VideoAdapter(private val items: List<SampleData.VideoItem>) :
        RecyclerView.Adapter<VideoAdapter.VH>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false)
            return VH(view)
        }

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])

        class VH(view: View) : RecyclerView.ViewHolder(view) {
            private val thumb: ImageView = view.findViewById(R.id.videoThumb)
            private val duration: TextView = view.findViewById(R.id.videoDuration)
            private val title: TextView = view.findViewById(R.id.videoTitle)
            private val label: TextView = view.findViewById(R.id.videoLabel)

            fun bind(item: SampleData.VideoItem) {
                Glide.with(thumb).load(item.thumbUrl).centerCrop().into(thumb)
                duration.text = item.duration
                title.text = item.title
                label.text = item.label
            }
        }
    }
}
