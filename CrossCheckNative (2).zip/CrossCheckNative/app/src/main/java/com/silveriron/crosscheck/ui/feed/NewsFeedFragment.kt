package com.silveriron.crosscheck.ui.feed

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.SampleData
import com.silveriron.crosscheck.ui.common.AppViewModel
import com.silveriron.crosscheck.ui.common.FontBarView

class NewsFeedFragment : Fragment(R.layout.fragment_news_feed) {

    private var activeTab = 0

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel

        val fontBar = view.findViewById<FontBarView>(R.id.fontBar)
        val recycler = view.findViewById<RecyclerView>(R.id.newsRecycler)
        val tabsContainer = view.findViewById<android.widget.LinearLayout>(R.id.categoryTabs)

        recycler.layoutManager = LinearLayoutManager(requireContext())
        val adapter = NewsFeedAdapter(filteredNews()) {
            activity.navigateTo(MainActivity.Screen.PERSPECTIVE)
        }
        recycler.adapter = adapter

        buildCategoryTabs(tabsContainer) { index ->
            activeTab = index
            adapter.submitList(filteredNews())
        }
        highlightTab(tabsContainer, activeTab)

        fontBar.listener = object : FontBarView.Listener {
            override fun onLevelChanged(newLevel: Int) = appViewModel.setLevel(newLevel)
            override fun onToggleContrast() = appViewModel.toggleContrast()
        }
        appViewModel.level.observe(viewLifecycleOwner) { level ->
            fontBar.bind(level, appViewModel.highContrast.value ?: false)
        }
        appViewModel.highContrast.observe(viewLifecycleOwner) { hc ->
            fontBar.bind(appViewModel.level.value ?: 1, hc)
        }
    }

    private fun filteredNews() =
        if (activeTab == 0) SampleData.NEWS
        else SampleData.NEWS.filter { it.tag == SampleData.CATEGORIES[activeTab] }

    private fun buildCategoryTabs(container: android.widget.LinearLayout, onSelect: (Int) -> Unit) {
        container.removeAllViews()
        SampleData.CATEGORIES.forEachIndexed { index, label ->
            val tv = TextView(requireContext()).apply {
                text = label
                textSize = 15f
                setPadding(0, 0, 0, dp(6))
                setOnClickListener {
                    onSelect(index)
                    highlightTab(container, index)
                }
            }
            val params = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
            params.marginEnd = dp(20)
            container.addView(tv, params)
        }
    }

    private fun highlightTab(container: android.widget.LinearLayout, activeIndex: Int) {
        for (i in 0 until container.childCount) {
            val tv = container.getChildAt(i) as TextView
            val on = i == activeIndex
            tv.setTextColor(resources.getColor(if (on) R.color.ink else R.color.faint, requireContext().theme))
            tv.setTypeface(null, if (on) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            tv.setBackgroundResource(if (on) R.drawable.underline_active else 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
