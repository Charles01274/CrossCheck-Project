package com.silveriron.crosscheck.ui.chat

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.ChatMessage
import com.silveriron.crosscheck.ui.common.FontBarView

class ChatFragment : Fragment(R.layout.fragment_chat) {

    private val prompts = listOf("3줄 요약", "어려운 단어 설명", "왜 중요한가요?")

    private val aiResponses = mapOf(
        "3줄 요약" to "① 국회가 의약품 급여를 늘리는 건강보험 개혁안을 논의하고 있습니다.\n② 찬성 측은 어르신 약값 부담 완화를, 반대 측은 신약 개발 위축을 우려합니다.\n③ 표결은 이번 주 본회의에서 이루어질 예정이며, 결과에 따라 약값이 크게 달라질 수 있습니다.",
        "어려운 단어 설명" to "건강보험: 아플 때 병원비와 약값을 나라가 함께 부담해주는 제도입니다.\n급여 확대: 지금보다 더 많은 약과 치료가 건강보험 혜택을 받게 되는 것입니다.\n제약사 R&D: 새로운 약을 연구하고 개발하는 활동으로, 막대한 비용이 필요합니다.",
        "왜 중요한가요?" to "이 법이 통과되면 현재 직접 부담하시는 약값이 크게 줄어들 수 있습니다. 특히 고혈압·당뇨 등 만성질환 약을 꾸준히 드시는 어르신들께 가장 큰 혜택이 돌아갑니다. 지난 10년 사이 가장 큰 의료 복지 변화 중 하나입니다."
    )

    private var nextId = 1L
    private lateinit var adapter: ChatAdapter
    private lateinit var recycler: RecyclerView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel

        view.findViewById<View>(R.id.btnBack).setOnClickListener {
            activity.navigateTo(MainActivity.Screen.PERSPECTIVE)
        }

        val fontBar = view.findViewById<FontBarView>(R.id.fontBar)
        fontBar.listener = object : FontBarView.Listener {
            override fun onLevelChanged(newLevel: Int) = appViewModel.setLevel(newLevel)
            override fun onToggleContrast() = appViewModel.toggleContrast()
        }
        appViewModel.level.observe(viewLifecycleOwner) { level ->
            fontBar.bind(level, appViewModel.highContrast.value ?: false)
        }
        appViewModel.highContrast.observe(viewLifecycleOwner) { hc ->
            fontBar.bind(appViewModel.level.value ?: 1, hc)
        }

        recycler = view.findViewById(R.id.messageRecycler)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        val initial = mutableListOf(
            ChatMessage(nextId++, false, "안녕하세요! 오늘의 건강보험 개혁 뉴스에 대해 쉽게 설명해 드릴게요. 궁금한 것이 있으시면 언제든지 물어보세요.")
        )
        adapter = ChatAdapter(initial)
        recycler.adapter = adapter

        val chipsContainer = view.findViewById<LinearLayout>(R.id.promptChips)
        prompts.forEach { label ->
            val chip = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_prompt_chip, chipsContainer, false) as TextView
            chip.text = label
            chip.setOnClickListener { sendMessage(label) }
            chipsContainer.addView(chip)
        }

        val input = view.findViewById<EditText>(R.id.messageInput)
        view.findViewById<View>(R.id.btnSend).setOnClickListener {
            val text = input.text.toString()
            if (text.isNotBlank()) {
                sendMessage(text)
                input.text.clear()
            }
        }
        input.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEND ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                val text = input.text.toString()
                if (text.isNotBlank()) {
                    sendMessage(text)
                    input.text.clear()
                }
                true
            } else {
                false
            }
        }
    }

    private fun sendMessage(text: String) {
        adapter.addMessage(ChatMessage(nextId++, true, text))
        recycler.scrollToPosition(adapter.itemCount - 1)

        Handler(Looper.getMainLooper()).postDelayed({
            if (!isAdded) return@postDelayed
            val response = aiResponses[text]
                ?: "좋은 질문이세요! 이 기사에서 핵심은 정부 정책이 일상적인 의료비에 미치는 영향입니다. 혹시 더 구체적으로 궁금한 부분이 있으신가요?"
            adapter.addMessage(ChatMessage(nextId++, false, response))
            recycler.scrollToPosition(adapter.itemCount - 1)
        }, 1200)
    }
}
