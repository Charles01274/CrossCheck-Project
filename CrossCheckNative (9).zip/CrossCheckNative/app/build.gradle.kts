import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ── 비밀 값은 코드가 아니라 local.properties에서 읽어요 ─────────────────
// local.properties는 .gitignore에 들어 있어서 GitHub에 올라가지 않아요.
// 예)  GEMINI_API_KEY=AIza....
//      GEMINI_MODEL=gemini-3.5-flash-lite      (생략 가능)
//      AI_REPORT_URL=https://...               (생략 가능, AI 답변 신고 수신 주소)
//      NAVER_CLIENT_ID=...  NAVER_CLIENT_SECRET=...   (실시간 뉴스·속보: 네이버 뉴스 검색 API)
//      YOUTUBE_API_KEY=...                     (관련 영상 하이퍼링크: YouTube Data API v3)
val localProps = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

fun localProp(name: String, default: String = ""): String =
    (localProps.getProperty(name) ?: System.getenv(name) ?: "")
        .trim()
        .ifEmpty { default }
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")

android {
    namespace = "com.silveriron.crosscheck"
    // 플레이스토어 규정: 2026-08-31부터 신규 앱·업데이트는 API 36 이상을 target 해야 해요.
    compileSdk = 36

    defaultConfig {
        applicationId = "com.silveriron.crosscheck"
        minSdk = 24
        targetSdk = 36
        versionCode = 2
        versionName = "1.1"

        // 전시용: 뉴스 자동 갱신(6시간·속보·네이버 API) 끄기. 정식 앱 개발 때 true로 바꾸면 다시 켜져요.
        buildConfigField("boolean", "LIVE_NEWS_ENABLED", "false")
        buildConfigField("String", "GEMINI_API_KEY", "\"${localProp("GEMINI_API_KEY")}\"")
        buildConfigField("String", "GEMINI_MODEL", "\"${localProp("GEMINI_MODEL", "gemini-3.5-flash-lite")}\"")
        buildConfigField("String", "AI_REPORT_URL", "\"${localProp("AI_REPORT_URL")}\"")
        buildConfigField("String", "NAVER_CLIENT_ID", "\"${localProp("NAVER_CLIENT_ID")}\"")
        buildConfigField("String", "NAVER_CLIENT_SECRET", "\"${localProp("NAVER_CLIENT_SECRET")}\"")
        buildConfigField("String", "YOUTUBE_API_KEY", "\"${localProp("YOUTUBE_API_KEY")}\"")
        // 카카오 로그인: 카카오 개발자 콘솔의 '네이티브 앱 키' (local.properties의 KAKAO_NATIVE_APP_KEY)
        buildConfigField("String", "KAKAO_NATIVE_APP_KEY", "\"${localProp("KAKAO_NATIVE_APP_KEY")}\"")
        manifestPlaceholders["kakaoScheme"] = "kakao${localProp("KAKAO_NATIVE_APP_KEY")}"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("com.github.bumptech.glide:glide:4.16.0")
    implementation("com.google.android.flexbox:flexbox:3.0.0")
    // 6시간마다 뉴스를 새로 받아오는 백그라운드 작업 (SDK 35 이상으로 컴파일된 안정 버전)
    implementation("androidx.work:work-runtime:2.10.5")
    // 카카오 로그인 (2026년 2월 최신 버전)
    implementation("com.kakao.sdk:v2-user:2.23.3")
}
