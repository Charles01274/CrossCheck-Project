package com.silveriron.crosscheck.news

/**
 * 받아온 기사들을 화면 순서로 정리해요 (단독 테스트 가능한 순수 로직).
 *  - 속보: 최근 24시간 안의 [속보] 기사, **최신순**, 최대 5건 → 화면 맨 위
 *  - 최신 뉴스: 나머지 최근 48시간 기사, 최신순
 *  - 여러 검색어에서 같은 기사가 겹치면 하나만 남겨요.
 */
object FeedArranger {
    const val BREAKING_WINDOW_MS = 24L * 60 * 60 * 1000
    const val KEEP_WINDOW_MS = 48L * 60 * 60 * 1000
    const val MAX_BREAKING = 5
    const val MAX_LATEST = 40

    data class Arranged(val breaking: List<LiveArticle>, val latest: List<LiveArticle>)

    fun merge(batches: List<List<LiveArticle>>): List<LiveArticle> {
        val byKey = LinkedHashMap<String, LiveArticle>()
        val titleToKey = HashMap<String, String>()
        for (article in batches.flatten().sortedByDescending { it.publishedAt }) {
            val titleKey = normalize(article.title)
            val existingKey = when {
                byKey.containsKey(article.id) -> article.id
                titleKey.isNotEmpty() && titleToKey.containsKey(titleKey) -> titleToKey[titleKey]
                else -> null
            }
            if (existingKey == null) {
                byKey[article.id] = article
                if (titleKey.isNotEmpty()) titleToKey[titleKey] = article.id
            } else if (article.isBreaking) {
                // 같은 기사가 한쪽 검색에서만 속보로 잡혔다면 속보로 표시해요.
                val kept = byKey.getValue(existingKey)
                if (!kept.isBreaking) byKey[existingKey] = kept.copy(isBreaking = true, category = "속보")
            }
        }
        return byKey.values.sortedByDescending { it.publishedAt }
    }

    fun arrange(all: List<LiveArticle>, now: Long, category: String? = null): Arranged {
        val sorted = all.sortedByDescending { it.publishedAt }
        val breaking = sorted
            .filter { it.isBreaking && now - it.publishedAt <= BREAKING_WINDOW_MS }
            .take(MAX_BREAKING)
        val breakingIds = breaking.map { it.id }.toSet()
        val latest = sorted
            .filter { it.id !in breakingIds && now - it.publishedAt <= KEEP_WINDOW_MS }
            .filter { category == null || it.category == category }
            .take(MAX_LATEST)
        return Arranged(breaking, latest)
    }

    private fun normalize(title: String): String =
        title.lowercase().replace(Regex("[^0-9a-z가-힣]"), "")
}
