package com.silveriron.crosscheck.youtube

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.net.HttpURLConnection
import java.security.MessageDigest

/**
 * Google Cloud 콘솔에서 API 키를 'Android 앱'으로 제한해 두면,
 * 요청에 앱 패키지 이름과 서명 지문(SHA-1)을 함께 보내야 해요.
 * 이렇게 하면 누가 앱에서 키를 빼내도 다른 곳에서는 쓸 수 없어요. (README 참고)
 */
object AndroidKeyHeaders {

    @Volatile private var cachedSha1: String? = null

    fun apply(context: Context, connection: HttpURLConnection) {
        connection.setRequestProperty("X-Android-Package", context.packageName)
        signingSha1(context)?.let { connection.setRequestProperty("X-Android-Cert", it) }
    }

    @Suppress("DEPRECATION")
    private fun signingSha1(context: Context): String? {
        cachedSha1?.let { return it }
        return try {
            val pm = context.packageManager
            val signatures: Array<Signature>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signing = info.signingInfo
                when {
                    signing == null -> null
                    signing.hasMultipleSigners() -> signing.apkContentsSigners
                    else -> signing.signingCertificateHistory
                }
            } else {
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
            }
            val first = signatures?.firstOrNull() ?: return null
            val digest = MessageDigest.getInstance("SHA-1").digest(first.toByteArray())
            digest.joinToString("") { "%02X".format(it) }.also { cachedSha1 = it }
        } catch (e: Exception) {
            null
        }
    }
}
