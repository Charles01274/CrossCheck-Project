package com.silveriron.crosscheck.youtube

/** 유튜브 검색으로 찾은 실제 영상 한 개 */
data class YouTubeVideo(
    val videoId: String,
    val title: String,
    val channel: String,
    val thumbnailUrl: String
)

/**
 * 시니어 사용자에게 검증되지 않은 채널(가짜뉴스·자극적 영상)이 연결되지 않도록,
 * 국내 주요 방송·통신사의 공식 뉴스 채널 영상만 골라요. (채널 이름 일부로 판별)
 * 성향이 다른 방송사를 고루 넣었고, 필요하면 이 목록만 고치면 돼요.
 */
object TrustedChannels {
    val KEYWORDS = listOf(
        "연합뉴스", "KBS", "MBC", "SBS", "JTBC", "YTN",
        "채널A", "TV CHOSUN", "TV조선", "TVCHOSUN", "MBN"
    )

    fun isTrusted(channel: String): Boolean =
        KEYWORDS.any { channel.contains(it, ignoreCase = true) }

    fun pick(videos: List<YouTubeVideo>, max: Int): List<YouTubeVideo> =
        videos.filter { isTrusted(it.channel) }.distinctBy { it.videoId }.take(max)
}
