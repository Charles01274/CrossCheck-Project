package com.silveriron.crosscheck.ui.feed

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.NewsItem
import com.silveriron.crosscheck.news.LiveArticle
import com.silveriron.crosscheck.news.NewsText
import com.silveriron.crosscheck.ui.common.NewsPhotos

/** 뉴스 화면의 한 줄 */
sealed class FeedRow {
    data class Status(val text: String) : FeedRow()
    data class Header(val title: String, val subtitle: String, val breaking: Boolean) : FeedRow()
    data class Breaking(val article: LiveArticle) : FeedRow()
    data class Live(val article: LiveArticle, val first: Boolean) : FeedRow()
    data class SampleLead(val item: NewsItem) : FeedRow()
    data class SampleRow(val item: NewsItem, val first: Boolean) : FeedRow()
}

class NewsFeedAdapter(
    private val onSample: (NewsItem) -> Unit,
    private val onLive: (LiveArticle) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var rows: List<FeedRow> = emptyList()

    fun submit(newRows: List<FeedRow>) {
        rows = newRows
        notifyDataSetChanged()
    }

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int) = when (rows[position]) {
        is FeedRow.Status -> TYPE_STATUS
        is FeedRow.Header -> TYPE_HEADER
        is FeedRow.Breaking -> TYPE_BREAKING
        is FeedRow.Live -> TYPE_LIVE
        is FeedRow.SampleLead -> TYPE_LEAD
        is FeedRow.SampleRow -> TYPE_ROW
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_STATUS -> StatusHolder(inflater.inflate(R.layout.item_feed_status, parent, false))
            TYPE_HEADER -> HeaderHolder(inflater.inflate(R.layout.item_feed_section_header, parent, false))
            TYPE_BREAKING -> BreakingHolder(inflater.inflate(R.layout.item_breaking, parent, false))
            TYPE_LIVE -> LiveHolder(inflater.inflate(R.layout.item_live_news, parent, false))
            TYPE_LEAD -> LeadHolder(inflater.inflate(R.layout.item_news_lead, parent, false))
            else -> RowHolder(inflater.inflate(R.layout.item_news_row, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val now = System.currentTimeMillis()
        when (val row = rows[position]) {
            is FeedRow.Status -> (holder as StatusHolder).bind(row)
            is FeedRow.Header -> (holder as HeaderHolder).bind(row)
            is FeedRow.Breaking -> (holder as BreakingHolder).bind(row.article, now, onLive)
            is FeedRow.Live -> (holder as LiveHolder).bind(row, now, onLive)
            is FeedRow.SampleLead -> (holder as LeadHolder).bind(row.item, onSample)
            is FeedRow.SampleRow -> (holder as RowHolder).bind(row.item, row.first, onSample)
        }
    }

    class StatusHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val text: TextView = view.findViewById(R.id.statusText)
        fun bind(row: FeedRow.Status) {
            text.text = row.text
        }
    }

    class HeaderHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val dot: View = view.findViewById(R.id.headerDot)
        private val title: TextView = view.findViewById(R.id.headerTitle)
        private val subtitle: TextView = view.findViewById(R.id.headerSubtitle)
        fun bind(row: FeedRow.Header) {
            dot.visibility = if (row.breaking) View.VISIBLE else View.GONE
            title.text = row.title
            subtitle.text = row.subtitle
            subtitle.visibility = if (row.subtitle.isBlank()) View.GONE else View.VISIBLE
        }
    }

    class BreakingHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val meta: TextView = view.findViewById(R.id.breakingMeta)
        private val title: TextView = view.findViewById(R.id.breakingTitle)
        fun bind(article: LiveArticle, now: Long, onLive: (LiveArticle) -> Unit) {
            meta.text = "${NewsText.timeAgo(article.publishedAt, now)} · ${article.source}"
            title.text = article.title
            itemView.contentDescription = itemView.context.getString(
                R.string.breaking_row_description, article.source, article.title
            )
            itemView.setOnClickListener { onLive(article) }
        }
    }

    class LiveHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val divider: View = view.findViewById(R.id.liveDivider)
        private val row: View = view.findViewById(R.id.liveRow)
        private val meta: TextView = view.findViewById(R.id.liveMeta)
        private val title: TextView = view.findViewById(R.id.liveTitle)
        fun bind(item: FeedRow.Live, now: Long, onLive: (LiveArticle) -> Unit) {
            val article = item.article
            divider.visibility = if (item.first) View.GONE else View.VISIBLE
            meta.text = "${article.category} · ${NewsText.timeAgo(article.publishedAt, now)} · ${article.source}"
            title.text = article.title
            row.setOnClickListener { onLive(article) }
        }
    }

    class LeadHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val image: ImageView = view.findViewById(R.id.leadImage)
        private val tag: TextView = view.findViewById(R.id.leadTag)
        private val time: TextView = view.findViewById(R.id.leadTime)
        private val title: TextView = view.findViewById(R.id.leadTitle)
        private val summary: TextView = view.findViewById(R.id.leadSummary)
        private val perspectiveCount: TextView = view.findViewById(R.id.leadPerspectiveCount)
        private val credit: TextView = view.findViewById(R.id.leadCredit)

        init {
            image.clipToOutline = true // 둥근 배경 모양대로 사진 모서리를 잘라요
        }

        fun bind(item: NewsItem, onClick: (NewsItem) -> Unit) {
            tag.text = item.tag.uppercase()
            time.text = "· ${item.time}"
            title.text = item.title
            summary.text = item.summary
            perspectiveCount.text = "${item.perspectives}개 시각 비교"
            NewsPhotos.load(image, item)
            credit.text = item.photoCredit
            credit.visibility = if (item.photoCredit.isBlank()) View.GONE else View.VISIBLE
            itemView.setOnClickListener { onClick(item) }
        }
    }

    class RowHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val divider: View = view.findViewById(R.id.rowDivider)
        // 안쪽 줄이 터치를 받기 때문에 클릭도 여기에 연결해요 (예전엔 바깥에 연결돼 눌러도 반응이 없었어요)
        private val clickArea: View = view.findViewById(R.id.rowClickArea)
        private val image: ImageView = view.findViewById(R.id.rowImage)
        private val tag: TextView = view.findViewById(R.id.rowTag)
        private val time: TextView = view.findViewById(R.id.rowTime)
        private val title: TextView = view.findViewById(R.id.rowTitle)
        private val perspectiveCount: TextView = view.findViewById(R.id.rowPerspectiveCount)

        init {
            image.clipToOutline = true
        }

        fun bind(item: NewsItem, isFirstRow: Boolean, onClick: (NewsItem) -> Unit) {
            divider.visibility = if (isFirstRow) View.GONE else View.VISIBLE
            tag.text = item.tag.uppercase()
            time.text = "· ${item.time}"
            title.text = item.title
            perspectiveCount.text = "${item.perspectives}개 시각"
            NewsPhotos.load(image, item, square = true)
            clickArea.setOnClickListener { onClick(item) }
        }
    }

    companion object {
        private const val TYPE_STATUS = 0
        private const val TYPE_HEADER = 1
        private const val TYPE_BREAKING = 2
        private const val TYPE_LIVE = 3
        private const val TYPE_LEAD = 4
        private const val TYPE_ROW = 5
    }
}
