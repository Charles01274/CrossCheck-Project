package com.silveriron.crosscheck

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.silveriron.crosscheck.auth.AuthStore
import com.silveriron.crosscheck.ui.chat.ChatFragment
import com.silveriron.crosscheck.ui.feed.LiveArticleFragment
import com.silveriron.crosscheck.ui.feed.NewsFeedFragment
import com.silveriron.crosscheck.ui.perspective.PerspectiveFragment
import com.silveriron.crosscheck.ui.settings.SettingsFragment
import com.silveriron.crosscheck.ui.tutorial.TutorialFragment

class MainActivity : BaseActivity() {

    private lateinit var bottomNav: BottomNavigationView
    private var currentScreen = Screen.FEED

    /**
     * 휴대폰의 '뒤로' 버튼/제스처 처리.
     * AI 질문 → 시각 비교 → 뉴스 순서로 돌아가고, 뉴스 화면에서만 앱을 나가요.
     * (API 36부터는 onBackPressed()가 호출되지 않아서 이 방식이 필수예요.)
     */
    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            goBack()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 로그인하지 않았고 둘러보기 중도 아니면 로그인 화면으로 (예: 오래 꺼져 있다 복원된 경우)
        if (!AuthStore.hasAccess(this)) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setContentView(R.layout.activity_main)
        bottomNav = findViewById(R.id.bottomNav)
        // 키보드가 올라오면 하단 탭을 잠시 숨겨서 입력창이 키보드 바로 위에 오게 해요.
        applyWindowInsets(findViewById(R.id.root)) { imeVisible ->
            bottomNav.visibility = if (imeVisible) View.GONE else View.VISIBLE
        }
        hideStatusBar()

        if (savedInstanceState != null) {
            val saved = savedInstanceState.getInt(KEY_CURRENT_SCREEN, 0)
            currentScreen = Screen.entries.getOrElse(saved) { Screen.FEED }
        }
        bottomNav.menu.findItem(menuIdFor(currentScreen))?.isChecked = true

        bottomNav.setOnItemSelectedListener { item ->
            val screen = screenFor(item.itemId)
            val hasFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainer) != null
            if (screen != currentScreen || !hasFragment) {
                showScreen(screen)
            }
            currentScreen = screen
            backCallback.isEnabled = screen != Screen.FEED
            true
        }

        if (savedInstanceState == null) {
            // 처음 로그인했다면 사용 가이드부터 안내해요 (기획서의 '로그인 후 튜토리얼 자동 연결').
            val first = if (intent.getBooleanExtra(EXTRA_OPEN_GUIDE, false)) Screen.TUTORIAL else Screen.FEED
            bottomNav.selectedItemId = menuIdFor(first)
        }

        onBackPressedDispatcher.addCallback(this, backCallback)
        backCallback.isEnabled = currentScreen != Screen.FEED
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_CURRENT_SCREEN, currentScreen.ordinal)
    }

    enum class Screen { FEED, PERSPECTIVE, CHAT, TUTORIAL, LIVE_ARTICLE, SETTINGS }

    /** 원본 React 앱의 setScreen()과 같은 역할이에요. 하단 탭 선택도 함께 바뀌어요. */
    fun navigateTo(screen: Screen) {
        if (screen == Screen.LIVE_ARTICLE) {
            // 실시간 기사 화면은 하단 탭이 없는 화면이라 '뉴스' 탭을 켜 둔 채 직접 열어요.
            bottomNav.menu.findItem(R.id.nav_feed)?.isChecked = true
            showScreen(screen)
            currentScreen = screen
            backCallback.isEnabled = true
        } else {
            bottomNav.selectedItemId = menuIdFor(screen)
        }
    }

    /**
     * 화면 안의 '뒤로' 버튼과 휴대폰 뒤로가기가 같은 곳으로 가요.
     *  AI 질문 → (실시간 기사에 대해 묻던 중이면) 실시간 기사 / (아니면) 시각 비교
     *  그 밖의 화면(실시간 기사·시각 비교·가이드·설정) → 뉴스
     */
    fun goBack() {
        val target = when (currentScreen) {
            Screen.CHAT -> if (appViewModel.isChatAboutLive) Screen.LIVE_ARTICLE else Screen.PERSPECTIVE
            else -> Screen.FEED
        }
        navigateTo(target)
    }

    private fun menuIdFor(screen: Screen) = when (screen) {
        Screen.FEED, Screen.LIVE_ARTICLE -> R.id.nav_feed
        Screen.PERSPECTIVE -> R.id.nav_perspective
        Screen.CHAT -> R.id.nav_chat
        Screen.TUTORIAL -> R.id.nav_tutorial
        Screen.SETTINGS -> R.id.nav_settings
    }

    private fun screenFor(menuId: Int) = when (menuId) {
        R.id.nav_perspective -> Screen.PERSPECTIVE
        R.id.nav_chat -> Screen.CHAT
        R.id.nav_tutorial -> Screen.TUTORIAL
        R.id.nav_settings -> Screen.SETTINGS
        else -> Screen.FEED
    }

    private fun showScreen(screen: Screen) {
        val fragment: Fragment = when (screen) {
            Screen.FEED -> NewsFeedFragment()
            Screen.PERSPECTIVE -> PerspectiveFragment()
            Screen.CHAT -> ChatFragment()
            Screen.TUTORIAL -> TutorialFragment()
            Screen.LIVE_ARTICLE -> LiveArticleFragment()
            Screen.SETTINGS -> SettingsFragment()
        }
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    companion object {
        private const val KEY_CURRENT_SCREEN = "current_screen"

        /** 로그인 화면이 '처음 로그인함'을 알려줄 때 쓰는 값 */
        const val EXTRA_OPEN_GUIDE = "open_guide"
    }
}
