package com.silveriron.crosscheck.ui.perspective

import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.google.android.flexbox.FlexboxLayout
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.Perspective
import com.silveriron.crosscheck.news.NewsText
import com.silveriron.crosscheck.ui.common.FontBarView
import com.silveriron.crosscheck.ui.common.NewsPhotos
import com.silveriron.crosscheck.ui.common.RelatedLink
import com.silveriron.crosscheck.ui.common.RelatedVideoSection
import com.silveriron.crosscheck.ui.common.openYoutubeSearch
import com.silveriron.crosscheck.ui.common.openYoutubeVideo
import com.silveriron.crosscheck.youtube.YouTubeVideo

class PerspectiveFragment : Fragment(R.layout.fragment_perspective) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel
        // 피드에서 누른 기사를 보여줘요 (하단 탭으로 바로 들어오면 오늘의 대표 기사).
        val article = appViewModel.selectedArticle()

        view.findViewById<View>(R.id.btnBack).setOnClickListener {
            activity.navigateTo(MainActivity.Screen.FEED)
        }
        view.findViewById<FontBarView>(R.id.fontBar).connect(viewLifecycleOwner, appViewModel)

        // ── 기사 머리 ──
        view.findViewById<TextView>(R.id.articleTag).text = article.tag
        view.findViewById<TextView>(R.id.articleTime).text = getString(R.string.article_time, article.time)
        view.findViewById<TextView>(R.id.articleTitle).text = article.title
        val image = view.findViewById<ImageView>(R.id.articleImage)
        image.clipToOutline = true
        NewsPhotos.load(image, article)
        view.findViewById<TextView>(R.id.photoCredit).apply {
            text = article.photoCredit
            visibility = if (article.photoCredit.isBlank()) View.GONE else View.VISIBLE
        }

        // ── AI 3줄 요약 ──
        val summaryList = view.findViewById<LinearLayout>(R.id.summaryList)
        article.summaryLines.forEachIndexed { i, line -> summaryList.addView(buildSummaryRow(i + 1, line)) }

        view.findViewById<View>(R.id.btnAskAi).setOnClickListener {
            appViewModel.useComparisonForChat()
            activity.navigateTo(MainActivity.Screen.CHAT)
        }

        // ── 두 가지 시각 ──
        bindPerspective(
            view, article.left,
            R.id.leftCaption, R.id.leftHeadline, R.id.leftBody, R.id.leftKeywords,
            R.drawable.bg_chip_blue, R.color.blueText
        )
        bindPerspective(
            view, article.right,
            R.id.rightCaption, R.id.rightHeadline, R.id.rightBody, R.id.rightKeywords,
            R.drawable.bg_chip_red, R.color.redText
        )

        val tabLeft = view.findViewById<View>(R.id.tabLeft)
        val tabRight = view.findViewById<View>(R.id.tabRight)
        val tabLeftLabel = view.findViewById<TextView>(R.id.tabLeftLabel)
        val tabRightLabel = view.findViewById<TextView>(R.id.tabRightLabel)
        val leftContent = view.findViewById<View>(R.id.leftContent)
        val rightContent = view.findViewById<View>(R.id.rightContent)
        tabLeftLabel.text = article.left.label
        tabRightLabel.text = article.right.label

        fun selectTab(left: Boolean) {
            tabLeft.setBackgroundResource(if (left) R.drawable.bg_segment_selected else 0)
            tabRight.setBackgroundResource(if (!left) R.drawable.bg_segment_selected else 0)
            tabLeft.isSelected = left   // 화면 낭독기가 '선택됨'을 읽어줘요
            tabRight.isSelected = !left
            tabLeftLabel.setTextColor(color(if (left) R.color.blue else R.color.ink2))
            tabRightLabel.setTextColor(color(if (!left) R.color.red else R.color.ink2))
            leftContent.visibility = if (left) View.VISIBLE else View.GONE
            rightContent.visibility = if (!left) View.VISIBLE else View.GONE
        }
        tabLeft.setOnClickListener { selectTab(true) }
        tabRight.setOnClickListener { selectTab(false) }
        selectTab(true)

        // ── 관련 영상 (유튜브 하이퍼링크 시스템) ──
        // 1) 바로 '유튜브에서 찾아보기' 카드를 보여주고, 2) 방송사 공식 영상을 찾으면 실제 영상으로 바꿔요.
        val query = NewsText.searchQueryFor(article.title)
        // 기사마다 골라 둔 방송사 공식 영상 (썸네일은 영상 ID로 바로 불러와요)
        val curated = article.videos.map { YouTubeVideo(it.videoId, it.title, it.channel, "") }
        val fallback = listOf(
            RelatedLink.Search(getString(R.string.related_videos_more), getString(R.string.video_badge_search), query, "")
        )
        val videos = RelatedVideoSection(
            fragment = this,
            recycler = view.findViewById<RecyclerView>(R.id.videoRecycler),
            status = view.findViewById(R.id.relatedVideosHint)
        )
        videos.load(query, curated, fallback)

        // 기사 사진을 누르면 관련 영상으로 이동해요 (찾은 영상이 있으면 바로 재생, 없으면 유튜브 검색).
        view.findViewById<View>(R.id.articlePhotoPlay).visibility = View.VISIBLE
        val openRelated = View.OnClickListener { v ->
            val top = videos.topVideo
            if (top != null) openYoutubeVideo(v.context, top.videoId) else openYoutubeSearch(v.context, fallback.first().query)
        }
        image.setOnClickListener(openRelated)
        image.contentDescription = getString(R.string.article_photo_description)
        view.findViewById<View>(R.id.articlePhotoPlay).setOnClickListener(openRelated)
    }

    private fun bindPerspective(
        root: View,
        perspective: Perspective,
        captionId: Int,
        headlineId: Int,
        bodyId: Int,
        keywordsId: Int,
        chipBackground: Int,
        chipColor: Int
    ) {
        root.findViewById<TextView>(captionId).text = perspective.caption
        root.findViewById<TextView>(headlineId).text = perspective.headline
        root.findViewById<TextView>(bodyId).text = perspective.body
        val keywords = root.findViewById<FlexboxLayout>(keywordsId)
        keywords.removeAllViews()
        perspective.keywords.forEach { keywords.addView(buildChip(keywords, it, chipBackground, chipColor)) }
    }

    private fun buildSummaryRow(number: Int, text: String): View {
        val row = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, if (number > 1) dp(14) else 0, 0, 0)
        }
        val numberView = TextView(requireContext()).apply {
            this.text = number.toString()
            setTextColor(color(R.color.faint))
            textSize = 18f
            setTypeface(Typeface.SERIF, Typeface.BOLD)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val textView = TextView(requireContext()).apply {
            this.text = text
            setTextColor(color(R.color.ink))
            textSize = 15f
            setLineSpacing(0f, 1.7f)
            setPadding(dp(12), 0, 0, 0)
        }
        row.addView(numberView)
        row.addView(textView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    /** 부모(Flexbox)를 넘겨서 inflate해야 XML의 바깥 여백(margin)이 살아 있어요. */
    private fun buildChip(parent: ViewGroup, label: String, bgRes: Int, colorRes: Int): View {
        val chip = LayoutInflater.from(requireContext())
            .inflate(R.layout.item_keyword_chip, parent, false) as TextView
        chip.text = label
        chip.setBackgroundResource(bgRes)
        chip.setTextColor(color(colorRes))
        return chip
    }

    private fun color(res: Int): Int = resources.getColor(res, requireContext().theme)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
