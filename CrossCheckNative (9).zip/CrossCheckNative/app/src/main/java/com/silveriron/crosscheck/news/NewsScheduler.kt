package com.silveriron.crosscheck.news

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequest
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/**
 * 6시간 주기 뉴스 갱신 예약.
 * KEEP 정책이라 앱을 여러 번 켜도 예약이 겹치지 않고, 휴대폰을 껐다 켜도 유지돼요.
 * (안드로이드 절전 정책 때문에 정확히 6시간 0분이 아니라 '대략 6시간마다' 실행돼요.)
 */
object NewsScheduler {
    private const val WORK_NAME = "crosscheck-news-sync"

    fun schedule(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequest.Builder(
            NewsSyncWorker::class.java,
            LiveNewsRepository.REFRESH_INTERVAL_HOURS,
            TimeUnit.HOURS
        ).setConstraints(constraints).build()

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    /** 예전 버전이 휴대폰에 예약해 둔 자동 갱신까지 깨끗이 취소해요 (전시용). */
    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}
