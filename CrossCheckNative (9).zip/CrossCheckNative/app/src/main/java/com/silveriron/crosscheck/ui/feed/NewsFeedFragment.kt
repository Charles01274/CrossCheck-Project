package com.silveriron.crosscheck.ui.feed

import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.silveriron.crosscheck.BuildConfig
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.NewsItem
import com.silveriron.crosscheck.model.SampleData
import com.silveriron.crosscheck.news.FeedArranger
import com.silveriron.crosscheck.news.LiveNewsRepository
import com.silveriron.crosscheck.news.NaverNewsClient
import com.silveriron.crosscheck.news.NewsText
import com.silveriron.crosscheck.ui.common.FontBarView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 뉴스 화면 (위에서부터)
 *  1) 업데이트 상태: "마지막 업데이트 15분 전 · 6시간마다 새 소식"
 *  2) 속보: 최근 24시간 [속보] 기사, 최신순
 *  3) 같은 뉴스, 두 시각: 관점 비교가 준비된 이슈 (지금은 시연용 예시)
 *  4) 최신 뉴스: 네이버 뉴스 검색 결과, 최신순
 */
class NewsFeedFragment : Fragment(R.layout.fragment_news_feed) {

    private var activeTab = 0
    private var latestSnapshot: LiveNewsRepository.Snapshot? = null
    private lateinit var adapter: NewsFeedAdapter

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel

        view.findViewById<FontBarView>(R.id.fontBar).connect(viewLifecycleOwner, appViewModel)
        view.findViewById<TextView>(R.id.dateText).text = todayLabel()

        val recycler = view.findViewById<RecyclerView>(R.id.newsRecycler)
        val tabsContainer = view.findViewById<LinearLayout>(R.id.categoryTabs)
        val swipeRefresh = view.findViewById<SwipeRefreshLayout>(R.id.swipeRefresh)

        recycler.layoutManager = LinearLayoutManager(requireContext())
        adapter = NewsFeedAdapter(
            onSample = { item: NewsItem ->
                appViewModel.selectArticle(item.id)
                activity.navigateTo(MainActivity.Screen.PERSPECTIVE)
            },
            onLive = { article ->
                appViewModel.selectLive(article)
                activity.navigateTo(MainActivity.Screen.LIVE_ARTICLE)
            }
        )
        recycler.adapter = adapter
        adapter.submit(buildRows())

        if (BuildConfig.LIVE_NEWS_ENABLED) {
            // 당겨서 새로고침 → 네이버 뉴스에서 바로 다시 받아와요.
            swipeRefresh.setColorSchemeResources(R.color.red)
            swipeRefresh.setOnRefreshListener { LiveNewsRepository.refreshNow(requireContext()) }

            LiveNewsRepository.snapshot.observe(viewLifecycleOwner) { snapshot ->
                latestSnapshot = snapshot
                adapter.submit(buildRows())
            }
            LiveNewsRepository.refreshing.observe(viewLifecycleOwner) { busy ->
                swipeRefresh.isRefreshing = busy
            }

            // 저장된 뉴스를 먼저 보여주고, 마지막 갱신 후 6시간이 지났으면 바로 새로 받아와요.
            LiveNewsRepository.ensureLoaded(requireContext())
            LiveNewsRepository.refreshIfStale(requireContext())
        } else {
            // 전시용: 고정 뉴스만 보여주므로 당겨서 새로고침도 꺼 둬요.
            swipeRefresh.isEnabled = false
        }

        buildCategoryTabs(tabsContainer) { index ->
            activeTab = index
            adapter.submit(buildRows())
        }
        highlightTab(tabsContainer, activeTab)
    }

    private fun buildRows(): List<FeedRow> {
        val rows = ArrayList<FeedRow>()
        val now = System.currentTimeMillis()
        val category = if (activeTab == 0) null else SampleData.CATEGORIES[activeTab]
        val arranged = FeedArranger.arrange(latestSnapshot?.articles.orEmpty(), now, category)

        if (BuildConfig.LIVE_NEWS_ENABLED) rows += FeedRow.Status(statusText(now))

        // 속보는 어느 분야 탭에서든 맨 위에 보여줘요 (급한 소식이니까요).
        if (arranged.breaking.isNotEmpty()) {
            rows += FeedRow.Header(getString(R.string.section_breaking), getString(R.string.section_breaking_sub), breaking = true)
            arranged.breaking.forEach { rows += FeedRow.Breaking(it) }
        }

        val samples = filteredSamples()
        if (samples.isNotEmpty()) {
            rows += FeedRow.Header(getString(R.string.section_compare), getString(R.string.section_compare_sub), breaking = false)
            rows += FeedRow.SampleLead(samples.first())
            samples.drop(1).forEachIndexed { i, item -> rows += FeedRow.SampleRow(item, first = i == 0) }
        }

        if (arranged.latest.isNotEmpty()) {
            rows += FeedRow.Header(getString(R.string.section_latest), getString(R.string.section_latest_sub), breaking = false)
            arranged.latest.forEachIndexed { i, article -> rows += FeedRow.Live(article, first = i == 0) }
        }
        return rows
    }

    private fun statusText(now: Long): String {
        val snapshot = latestSnapshot ?: return getString(R.string.feed_status_loading)
        val problem = when (snapshot.lastError) {
            NaverNewsClient.Reason.NOT_CONFIGURED -> getString(R.string.feed_status_no_key)
            NaverNewsClient.Reason.NETWORK -> getString(R.string.feed_status_offline)
            NaverNewsClient.Reason.QUOTA -> getString(R.string.feed_status_quota)
            NaverNewsClient.Reason.AUTH -> getString(R.string.feed_status_auth)
            NaverNewsClient.Reason.SERVER -> getString(R.string.feed_status_error)
            null -> null
        }
        val updated = if (snapshot.updatedAt > 0) {
            getString(R.string.feed_status_updated, NewsText.timeAgo(snapshot.updatedAt, now), LiveNewsRepository.REFRESH_INTERVAL_HOURS)
        } else {
            null
        }
        return when {
            problem != null && updated != null -> "$problem\n$updated"
            problem != null -> problem
            updated != null -> updated
            else -> getString(R.string.feed_status_loading)
        }
    }

    private fun filteredSamples(): List<NewsItem> =
        if (activeTab == 0) SampleData.NEWS
        else SampleData.NEWS.filter { it.tag == SampleData.CATEGORIES[activeTab] }

    private fun buildCategoryTabs(container: LinearLayout, onSelect: (Int) -> Unit) {
        container.removeAllViews()
        val ripple = TypedValue()
        requireContext().theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)

        SampleData.CATEGORIES.forEachIndexed { index, label ->
            val tab = TextView(requireContext()).apply {
                text = label
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(dp(4), 0, dp(4), 0)
                // 글자 줄 높이만이 아니라 48dp 전체를 누를 수 있게 해요 (시니어 터치 영역 기준).
                minHeight = dp(48)
                isClickable = true
                isFocusable = true
                // 배경은 '선택됨' 밑줄 표시에 쓰이므로, 눌림 효과(리플)는 foreground에 둬요.
                foreground = resources.getDrawable(ripple.resourceId, requireContext().theme)
                setOnClickListener {
                    onSelect(index)
                    highlightTab(container, index)
                }
            }
            val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48))
            params.marginEnd = dp(12)
            container.addView(tab, params)
        }
    }

    private fun highlightTab(container: LinearLayout, activeIndex: Int) {
        for (i in 0 until container.childCount) {
            val tab = container.getChildAt(i) as TextView
            val on = i == activeIndex
            tab.setTextColor(resources.getColor(if (on) R.color.ink else R.color.faint, requireContext().theme))
            tab.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            tab.setBackgroundResource(if (on) R.drawable.underline_active else 0)
            tab.isSelected = on
        }
    }

    private fun todayLabel(): String {
        val formatter = SimpleDateFormat("M월 d일 EEEE", Locale.KOREA)
        return "${formatter.format(Date())} · ${getString(R.string.masthead_subtitle)}"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
