package com.silveriron.crosscheck.auth

import android.app.Activity
import android.content.Intent
import com.silveriron.crosscheck.LoginActivity

/** 로그아웃·로그인 화면 이동처럼 여러 화면에서 쓰는 동작 */
object AuthActions {

    /** 로그아웃: 카카오 세션 정리 → 저장된 로그인 정보 삭제 → 로그인 화면으로 (뒤로가기로 못 돌아오게) */
    fun logout(activity: Activity) {
        val session = AuthStore.current(activity)
        val finishLogout = {
            AuthStore.clear(activity)
            openLogin(activity)
        }
        if (session?.type == LoginType.KAKAO) KakaoAuth.logout(finishLogout) else finishLogout()
    }

    /** 둘러보기 중인 사람이 '로그인하기'를 누르면 */
    fun openLogin(activity: Activity) {
        AuthStore.guestMode = false
        activity.startActivity(
            Intent(activity, LoginActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        activity.finish()
    }
}
