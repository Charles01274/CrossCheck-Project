package com.silveriron.crosscheck.ui.common

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.silveriron.crosscheck.model.NewsItem
import com.silveriron.crosscheck.model.SampleData
import com.silveriron.crosscheck.news.LiveArticle
import com.silveriron.crosscheck.news.NewsText
import com.silveriron.crosscheck.news.toNewsItem

/**
 * 모든 화면이 함께 쓰는 상태예요 (원본 App.tsx의 최상위 state와 같은 역할).
 *  - level: 글씨 크기 단계 (1~3)
 *  - highContrast: 고대비(어두운) 화면 여부
 *  - selectedArticleId: 사용자가 마지막으로 연 기사 → 시각 비교 / AI 질문 화면이 이 기사를 보여줘요
 *
 * 실제 저장(SharedPreferences)과 화면 재구성은 MainActivity가 담당해요.
 */
class AppViewModel : ViewModel() {

    private val _level = MutableLiveData<Int>()
    val level: LiveData<Int> = _level

    private val _highContrast = MutableLiveData<Boolean>()
    val highContrast: LiveData<Boolean> = _highContrast

    var selectedArticleId: Int = SampleData.NEWS.first().id
        private set

    private var initialized = false

    /**
     * 저장된 설정으로 한 번만 시작값을 채워요.
     * (예전에는 항상 1단계로 시작해서, 앱을 다시 켤 때마다 고른 글씨 크기가 초기화됐어요.)
     */
    fun initFromPrefs(savedLevel: Int, savedHighContrast: Boolean) {
        if (initialized) return
        initialized = true
        _level.value = savedLevel
        _highContrast.value = savedHighContrast
    }

    val currentLevel: Int
        get() = _level.value ?: AppPrefs.MIN_LEVEL

    val isHighContrast: Boolean
        get() = _highContrast.value ?: false

    fun setLevel(n: Int) {
        _level.value = n.coerceIn(AppPrefs.MIN_LEVEL, AppPrefs.MAX_LEVEL)
    }

    fun toggleContrast() {
        _highContrast.value = !isHighContrast
    }

    /** 피드에서 연 실시간 기사 (속보·최신 뉴스) */
    var selectedLive: LiveArticle? = null
        private set

    /** AI 돋보기가 지금 실시간 기사에 대해 답하는 중인지 */
    private var chatAboutLive = false

    val isChatAboutLive: Boolean
        get() = chatAboutLive && selectedLive != null

    /** '시각 비교' 예시 기사 선택 → AI 돋보기도 이 기사로 */
    fun selectArticle(id: Int) {
        selectedArticleId = id
        chatAboutLive = false
    }

    fun selectLive(article: LiveArticle) {
        selectedLive = article
    }

    /** 실시간 기사 화면에서 'AI에게 물어보기'를 누르면 호출 */
    fun useLiveForChat() {
        chatAboutLive = selectedLive != null
    }

    /** 시각 비교 화면에서 'AI에게 더 물어보기'를 누르면 호출 */
    fun useComparisonForChat() {
        chatAboutLive = false
    }

    /** 시각 비교 화면이 보여줄 기사 (항상 두 시각이 준비된 기사) */
    fun selectedArticle(): NewsItem = SampleData.findById(selectedArticleId)

    /** AI 돋보기가 설명할 기사 */
    fun chatArticle(): NewsItem {
        val live = selectedLive
        return if (chatAboutLive && live != null) {
            live.toNewsItem(NewsText.timeAgo(live.publishedAt, System.currentTimeMillis()))
        } else {
            selectedArticle()
        }
    }
}
