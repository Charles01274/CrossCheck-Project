package com.silveriron.crosscheck.youtube

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * 기사 → 관련 유튜브 영상 찾기 (하이퍼링크 시스템의 중심).
 *  1) 같은 검색어는 24시간 동안 휴대폰에 저장한 결과를 다시 써서 할당량을 아껴요.
 *  2) 공식 뉴스 채널 영상만 남겨요 (TrustedChannels).
 *  3) 키가 없거나 실패하면 빈 목록 → 화면은 '유튜브에서 찾아보기' 링크로 대신 연결해요.
 * 결과는 항상 메인(화면) 스레드로 돌려줘요.
 */
object RelatedVideoRepository {

    private const val PREFS = "crosscheck_related_videos"
    private const val TTL_MS = 24L * 60 * 60 * 1000
    private const val MAX_VIDEOS = 5

    private val memory = ConcurrentHashMap<String, Pair<Long, List<YouTubeVideo>>>()
    private val executor = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun find(context: Context, query: String, callback: (List<YouTubeVideo>) -> Unit) {
        val key = query.trim().lowercase()
        val client = YouTubeClient()
        if (key.isEmpty() || !client.isConfigured) {
            callback(emptyList())
            return
        }
        memory[key]?.let { (savedAt, videos) ->
            if (System.currentTimeMillis() - savedAt < TTL_MS) {
                callback(videos)
                return
            }
        }

        val app = context.applicationContext
        executor.execute {
            val videos = readDisk(app, key) ?: when (val result = client.search(app, query)) {
                is YouTubeClient.Result.Success -> TrustedChannels.pick(result.videos, MAX_VIDEOS).also { writeDisk(app, key, it) }
                is YouTubeClient.Result.Failure -> null // 실패는 저장하지 않아요 (다음에 다시 시도)
            }
            if (videos != null) memory[key] = System.currentTimeMillis() to videos
            main.post { callback(videos.orEmpty()) }
        }
    }

    private fun prefKey(key: String): String =
        MessageDigest.getInstance("SHA-1").digest(key.toByteArray(Charsets.UTF_8))
            .take(10).joinToString("") { "%02x".format(it) }

    private fun readDisk(app: Context, key: String): List<YouTubeVideo>? = try {
        val raw = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(prefKey(key), null)
        if (raw == null) {
            null
        } else {
            val json = JSONObject(raw)
            if (System.currentTimeMillis() - json.optLong("savedAt") > TTL_MS) {
                null
            } else {
                val array = json.optJSONArray("videos") ?: JSONArray()
                (0 until array.length()).mapNotNull { i ->
                    array.optJSONObject(i)?.let {
                        YouTubeVideo(it.optString("id"), it.optString("title"), it.optString("channel"), it.optString("thumb"))
                    }
                }
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun writeDisk(app: Context, key: String, videos: List<YouTubeVideo>) {
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val array = JSONArray()
        videos.forEach { v ->
            array.put(JSONObject().put("id", v.videoId).put("title", v.title).put("channel", v.channel).put("thumb", v.thumbnailUrl))
        }
        val editor = prefs.edit()
        // 오래된 저장분은 정리해서 저장 공간이 계속 늘지 않게 해요.
        val now = System.currentTimeMillis()
        prefs.all.forEach { (k, value) ->
            val savedAt = try { JSONObject(value as? String ?: "{}").optLong("savedAt") } catch (e: Exception) { 0L }
            if (now - savedAt > TTL_MS) editor.remove(k)
        }
        editor.putString(prefKey(key), JSONObject().put("savedAt", now).put("videos", array).toString()).apply()
    }
}
