package com.silveriron.crosscheck.news

import android.content.Context
import androidx.work.ListenableWorker
import androidx.work.Worker
import androidx.work.WorkerParameters

/** 6시간마다 WorkManager가 깨워서 뉴스를 새로 받아와요 (앱이 꺼져 있어도 동작). */
class NewsSyncWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): ListenableWorker.Result =
        when (LiveNewsRepository.refreshBlocking(applicationContext)) {
            null -> ListenableWorker.Result.success()
            // 키가 없거나 잘못됐거나 한도 초과: 다시 시도해도 같으니 다음 주기를 기다려요.
            NaverNewsClient.Reason.NOT_CONFIGURED,
            NaverNewsClient.Reason.AUTH,
            NaverNewsClient.Reason.QUOTA -> ListenableWorker.Result.success()
            // 인터넷·서버 문제: WorkManager가 잠시 뒤 다시 시도해요.
            NaverNewsClient.Reason.NETWORK,
            NaverNewsClient.Reason.SERVER -> ListenableWorker.Result.retry()
        }
}
