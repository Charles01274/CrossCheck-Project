package com.silveriron.crosscheck.model

import com.silveriron.crosscheck.R

/** 한쪽 시각(언론 성향)의 보도 내용 */
data class Perspective(
    val label: String,          // 탭에 보이는 짧은 이름 (예: 진보 성향)
    val caption: String,        // 카드 맨 위 설명 줄
    val headline: String,       // 대표 문장
    val body: String,           // 본문
    val keywords: List<String>  // 핵심 키워드 칩
)

/** 어려운 용어 풀이 (AI 돋보기 기본 답변과 Gemini 문맥에 함께 쓰여요) */
data class GlossaryTerm(
    val term: String,
    val explanation: String,
    val keywords: List<String> = listOf(term)
)

/**
 * 관련 유튜브 영상 (방송사 공식 채널의 실제 영상).
 * 썸네일은 영상 ID로 유튜브에서 바로 불러와요 → API 키가 필요 없어요.
 */
data class VideoItem(
    val title: String,
    val channel: String,
    val videoId: String
)

data class NewsItem(
    val id: Int,
    val tag: String,
    val title: String,
    val summary: String,
    val imageRes: Int,          // 앱 안에 넣어 둔 기사 그림 (가로형) → 인터넷이 없어도 절대 안 깨져요
    val thumbRes: Int,          // 목록용 정사각형 그림
    val time: String,
    val perspectives: Int,
    val summaryLines: List<String>,
    val whyItMatters: String,
    val outlook: String,
    val left: Perspective,
    val right: Perspective,
    val glossary: List<GlossaryTerm> = emptyList(),
    val videos: List<VideoItem> = emptyList(),
    val photoFile: String = "",       // 위키미디어 공용의 실제 사진 파일 이름 (없으면 imageRes 그림을 써요)
    val photoCredit: String = "",     // 사진 출처·이용 조건 (CC BY 4.0은 출처 표시가 조건이에요)
    val isLive: Boolean = false,      // 네이버 뉴스로 받아온 실시간 기사인지 (전시용에서는 사용 안 함)
    val sourceName: String = ""       // 실시간 기사의 언론사 이름
)

/**
 * 전시용 고정 기사 — 러시아·우크라이나 전쟁 (2026년 10월 중순 기준으로 정리).
 *  - 실제 보도된 사실을 바탕으로 쉽게 다시 썼고, 한쪽의 '주장'은 누구의 주장인지 밝혔어요.
 *  - 양쪽 시각은 국내 언론의 대표적인 논조를 단순화한 예시예요 (특정 언론사 인용 아님).
 *  - 정식 앱에서는 뉴스 수집 백엔드가 이 자리를 실제 기사로 채워요.
 */
object SampleData {
    val CATEGORIES = listOf("오늘의 이슈", "외교", "안보", "경제")

    private const val AS_OF = "2026년 10월 기준"

    val NEWS: List<NewsItem> = listOf(
        NewsItem(
            id = 1,
            tag = "오늘의 이슈",
            title = "러·우 전쟁 5년째, 종전 협상은 다시 갈림길",
            summary = "미국이 '에너지 휴전 합의'를 발표했지만 러시아는 확인하지 않았고, 멈춰 있는 미·러·우 3자 협상의 재개도 불투명합니다.",
            imageRes = R.drawable.news_ceasefire,
            thumbRes = R.drawable.news_ceasefire_square,
            photoFile = "Trump, Putin Alaska Arrival (9260683).jpg",
            photoCredit = "사진: 미 국방부(DoD) · 2025년 8월 알래스카 미·러 정상회담 · 퍼블릭 도메인",
            time = AS_OF,
            perspectives = 2,
            summaryLines = listOf(
                "2022년 2월 시작된 러시아·우크라이나 전쟁이 5년째 이어지고 있습니다.",
                "미국이 중재해 온 미·러·우 3자 종전 협상은 올해 2월 회의 이후 멈췄고, 재개 여부가 거론되고 있습니다.",
                "최근 미국이 서로 에너지 시설을 공격하지 않는 '에너지 휴전' 합의를 발표했지만 러시아는 확인하지 않아, 실제 이행은 불투명합니다."
            ),
            whyItMatters = "전쟁이 멈추느냐에 따라 기름값·곡물값 같은 세계 물가와, 러시아와 가까워지는 북한 문제까지 영향을 받아요. 우리 생활비와 한반도 안보 모두와 연결된 소식이에요.",
            outlook = "미국은 3자 실무 회담을 다시 여는 방안을 추진하고 있고, 러시아도 협상 재개 가능성을 닫지는 않았어요. 다만 휴전 발표를 두고 양측 입장이 엇갈려, 실제 협상이 열릴지는 더 지켜봐야 해요.",
            left = Perspective(
                label = "진보 성향",
                caption = "진보 성향 언론 — 대화·단계적 휴전 강조",
                headline = "“작은 휴전부터 쌓아 종전으로”",
                body = "이 시각의 언론은 에너지 시설 공격 중단처럼 작은 합의라도 이어가는 것이 민간인 피해를 줄이고 종전으로 가는 현실적인 길이라고 봅니다. 강대국 중심의 협상에서도 우크라이나 국민의 안전과 인도적 문제가 우선돼야 한다고 강조합니다.",
                keywords = listOf("단계적 휴전", "민간인 보호", "대화와 외교")
            ),
            right = Perspective(
                label = "보수 성향",
                caption = "보수 성향 언론 — 러시아 견제·안전보장 강조",
                headline = "“말뿐인 휴전, 압박 없이는 어렵다”",
                body = "이 시각의 언론은 휴전 발표 뒤에도 공격이 이어진 점을 들어 러시아의 종전 의지를 의심합니다. 서방의 단합된 압박과 확실한 안전보장 없이는 협상이 결실을 맺기 어렵다고 보고, 러시아와 북한의 밀착도 경계해야 한다고 주장합니다.",
                keywords = listOf("러시아 견제", "안전보장", "한·미 공조")
            ),
            glossary = listOf(
                GlossaryTerm("3자 협상", "미국이 중재하고 러시아·우크라이나가 함께 참여하는 종전 협상이에요.", listOf("3자 협상", "3자 회담", "3자")),
                GlossaryTerm("에너지 휴전", "발전소·정유 시설 같은 에너지 시설만큼은 서로 공격하지 말자는 부분 휴전이에요.", listOf("에너지 휴전", "에너지휴전")),
                GlossaryTerm("휴전과 종전", "휴전은 싸움을 잠시 멈추는 것이고, 종전은 협정을 맺어 전쟁을 공식적으로 끝내는 것이에요.", listOf("휴전", "종전")),
                GlossaryTerm("안전보장", "전쟁이 끝난 뒤 다시 침공받지 않도록 다른 나라들이 약속하는 보호 장치예요.", listOf("안전보장", "안전 보장"))
            ),
            videos = listOf(
                VideoItem("트럼프 “러-우 에너지 휴전”…러, 드론 공격 (9시 뉴스, 10월 12일)", "KBS News", "P6goLjfaVQs"),
                VideoItem("머나먼 종전의 길…5년차 러-우 전쟁 어디로? (뉴스in뉴스)", "KBS News", "mBlHfT2WECA"),
                VideoItem("미·러·우 3번째 종전 협상…돌파구 찾을까?", "YTN", "pb-TtseCvV4")
            )
        ),
        NewsItem(
            id = 2,
            tag = "외교",
            title = "방공망 지원 요청에 포로 이송 공개까지…한·우크라 관계 시험대",
            summary = "우크라이나가 한국에 방공 무기 지원을 공개적으로 요청한 데 이어, 북한군 포로의 한국 이송 사실을 먼저 공개하면서 두 나라 관계가 시험대에 올랐습니다.",
            imageRes = R.drawable.news_korea_ukraine,
            thumbRes = R.drawable.news_korea_ukraine_square,
            photoFile = "Patriot sam in ukrainian service net.jpg",
            photoCredit = "사진: 우크라이나군 총참모부 · 우크라이나군의 패트리엇 방공 시스템(2026) · CC BY 4.0",
            time = AS_OF,
            perspectives = 2,
            summaryLines = listOf(
                "젤렌스키 우크라이나 대통령이 지난 8월 한국을 콕 집어 방공 시스템 지원을 요청했습니다.",
                "최근에는 비공개로 하기로 했던 북한군 포로 2명의 한국 이송 사실을 우크라이나가 먼저 공개해 외교 마찰이 빚어졌습니다.",
                "러시아는 한국이 우크라이나 무기 지원에 참여하면 보복하겠다고 경고한 바 있어, 우리의 선택에 관심이 모입니다."
            ),
            whyItMatters = "북한군 포로 문제는 한반도와 직접 연결돼 있고, 무기 지원 여부는 러시아와의 관계와 현지 교민·기업의 안전에도 영향을 줄 수 있어요. 국제 사회와의 연대와 우리 국익 사이에서 균형을 찾아야 하는 문제예요.",
            outlook = "포로 문제와 지원 요청을 두고 두 나라의 외교적 조율이 이어질 전망이에요. 무기 지원 여부는 앞으로도 국내에서 논쟁이 계속될 사안이에요.",
            left = Perspective(
                label = "진보 성향",
                caption = "진보 성향 언론 — 신중한 외교·인도적 지원 강조",
                headline = "“살상무기 지원은 신중해야”",
                body = "이 시각의 언론은 무기 지원이 러시아와의 관계를 악화시켜 교민과 기업의 안전, 한반도 정세에 부담이 될 수 있다고 우려합니다. 인도적 지원과 재건 협력 중심으로 역할을 하고, 포로 문제는 조용한 외교로 풀어야 한다고 봅니다.",
                keywords = listOf("신중한 외교", "인도적 지원", "국익 우선")
            ),
            right = Perspective(
                label = "보수 성향",
                caption = "보수 성향 언론 — 가치 연대·방어용 지원 강조",
                headline = "“북·러 밀착에 맞서 역할 키워야”",
                body = "이 시각의 언론은 북한군이 러시아 편에서 싸우는 상황에서 지켜보기만 할 수는 없다고 봅니다. 방공 무기 같은 방어용 지원을 적극 검토하고 자유 진영과의 연대를 강화해야 한다고 주장합니다. 다만 포로 공개처럼 신뢰를 해친 일에는 분명히 문제를 제기해야 한다고 지적합니다.",
                keywords = listOf("가치 연대", "방어용 지원", "북·러 견제")
            ),
            glossary = listOf(
                GlossaryTerm("방공 시스템", "날아오는 미사일이나 드론을 하늘에서 막아내는 무기 체계예요.", listOf("방공 시스템", "방공망", "방공")),
                GlossaryTerm("북한군 포로", "러시아 편에서 싸우다 우크라이나군에 붙잡힌 북한 군인이에요. 이들이 한국으로 오기를 원하는지가 관심을 모았어요.", listOf("포로")),
                GlossaryTerm("살상무기", "사람을 직접 해칠 수 있는 무기예요. 방어 장비나 구호 물품과는 구분해서 말해요.", listOf("살상무기", "살상 무기")),
                GlossaryTerm("PURL", "우크라이나에 필요한 무기 목록을 정하고 동맹국들이 비용을 함께 대는 나토(NATO)의 지원 방식이에요.", listOf("PURL", "purl"))
            ),
            videos = listOf(
                VideoItem("우크라이나, 한국에 방공망 지원 요청 (8월 15일 이슈)", "KBS News", "GOP8i_V_hdo"),
                VideoItem("북한군 포로 이송 공개 뒤 한·우크라 외교 마찰 (자막뉴스)", "SBS 뉴스", "szEzJKK8oyU"),
                VideoItem("러시아, 한국에 “무기 지원 참여하면 보복” 경고 (뉴스쏙)", "연합뉴스TV", "PmKuhS1KWHI")
            )
        ),
        NewsItem(
            id = 3,
            tag = "안보",
            title = "러시아 간 북한군, 추가 파병 주장까지…한반도 안보 우려",
            summary = "우크라이나 측이 북한군의 추가 파병 준비를 잇따라 주장하면서, 북한이 그 대가로 무엇을 얻는지에 대한 우려가 커지고 있습니다.",
            imageRes = R.drawable.news_nk_troops,
            thumbRes = R.drawable.news_nk_troops_square,
            photoFile = "Vladimir Putin and Kim Jong-un (2024-06-19) 01.jpg",
            photoCredit = "사진: www.kremlin.ru · 2024년 6월 평양 북·러 정상회담 · CC BY 4.0",
            time = AS_OF,
            perspectives = 2,
            summaryLines = listOf(
                "북한은 2024년부터 러시아에 군대를 보내 우크라이나 전쟁에 참여시켜 왔습니다.",
                "젤렌스키 대통령은 최근 러시아 영토에 북한군 8천 명 이상이 있고, 1만 명 규모의 추가 배치도 준비 중이라고 주장했습니다.",
                "러시아가 그 대가로 북한에 군사 기술이나 경제 지원을 줄 수 있다는 우려가 나오면서, 한반도 안보에 미칠 영향에 관심이 쏠립니다."
            ),
            whyItMatters = "북한군이 실제 전쟁 경험을 쌓고 러시아의 군사 기술까지 얻게 되면 한반도의 군사적 긴장이 높아질 수 있어요. 먼 나라의 전쟁이 우리 안보와 직접 연결되는 이유예요.",
            outlook = "추가 파병이 실제로 이뤄지는지, 러시아가 북한에 어떤 대가를 주는지가 앞으로의 관심사예요. 정부와 국제 사회의 대응도 함께 지켜봐야 해요.",
            left = Perspective(
                label = "진보 성향",
                caption = "진보 성향 언론 — 긴장 관리·대화 강조",
                headline = "“군사 대응만으론 위험, 대화 창구 열어야”",
                body = "이 시각의 언론은 북·러 밀착에 맞서 군사적 대응만 키우면 한반도 긴장이 더 높아질 수 있다고 우려합니다. 남북·북미 대화와 외교로 위험을 관리해야 한다고 강조합니다.",
                keywords = listOf("긴장 완화", "대화 창구", "외교적 해법")
            ),
            right = Perspective(
                label = "보수 성향",
                caption = "보수 성향 언론 — 억지력·한미일 공조 강조",
                headline = "“북·러 군사 협력, 억지력 강화로 대응해야”",
                body = "이 시각의 언론은 북한이 전쟁 경험과 러시아의 기술을 얻는 것을 심각한 안보 위협으로 봅니다. 한·미·일 안보 협력을 강화하고 국제 사회와 함께 제재를 이어가야 한다고 주장합니다.",
                keywords = listOf("억지력 강화", "한·미·일 공조", "대북 제재")
            ),
            glossary = listOf(
                GlossaryTerm("파병", "군대를 다른 나라로 보내는 것이에요.", listOf("파병", "파견")),
                GlossaryTerm("억지력", "상대가 공격할 엄두를 내지 못하게 만드는 힘이에요.", listOf("억지력", "억제력")),
                GlossaryTerm("대북 제재", "북한에 돈이나 무기 재료가 들어가지 않도록 여러 나라가 거래를 막는 조치예요.", listOf("대북 제재", "제재")),
                GlossaryTerm("북·러 밀착", "북한과 러시아가 군사·경제적으로 가까워지는 것을 말해요.", listOf("북·러", "북러", "밀착"))
            ),
            videos = listOf(
                VideoItem("젤렌스키 “러, 북한군 3만 명 추가 파병 추진” (7월 26일)", "KBS News", "wLD_19o4Km4"),
                VideoItem("“북한군 1만 명 추가 파견 임박”…러시아가 건넨 대가는 (자막뉴스)", "SBS 뉴스", "NzIU-le0o6U"),
                VideoItem("러시아 훈련장서 포착된 북한군, 추가 파병 정황 (뉴스9)", "TV조선", "HhNiotT7nTU")
            )
        ),
        NewsItem(
            id = 4,
            tag = "경제",
            title = "에너지 시설 공방에 흑해 항만 공격까지…에너지·곡물값 영향은",
            summary = "러시아와 우크라이나가 서로의 에너지 시설을 공격하고 곡물 수출 통로인 흑해 항만까지 공격받으면서, 에너지·곡물 가격에 대한 걱정이 이어지고 있습니다.",
            imageRes = R.drawable.news_energy_grain,
            thumbRes = R.drawable.news_energy_grain_square,
            photoFile = "Trypilska Thermal Power Plant after Russian attack, 2024-04-11 (39).jpg",
            photoCredit = "사진: 우크라이나 국가비상서비스(DSNS) · 공습 후 트리필스카 화력발전소(2024) · CC BY 4.0",
            time = AS_OF,
            perspectives = 2,
            summaryLines = listOf(
                "러시아는 우크라이나의 발전소 등 에너지 시설을, 우크라이나는 러시아의 정유 시설을 공격하는 공방이 이어지고 있습니다.",
                "우크라이나는 세계적인 곡물 수출국이어서, 수출 통로인 흑해 항만이 공격받으면 국제 곡물 시장이 불안해질 수 있습니다.",
                "에너지와 곡물을 수입에 기대는 우리나라도 기름값, 난방비, 밀가루 같은 식품 가격에 영향을 받을 수 있습니다."
            ),
            whyItMatters = "에너지와 곡물 가격이 오르면 시간이 지나 우리 집 난방비와 장바구니 물가에도 반영될 수 있어요. 특히 겨울을 앞두고 에너지 가격의 흐름은 생활비와 바로 연결돼요.",
            outlook = "서로 에너지 시설을 공격하지 말자는 '에너지 휴전'이 실제로 지켜지면 시장 불안이 줄어들 수 있어요. 반대로 공방이 계속되면 겨울철 에너지 가격이 크게 움직일 수 있어 지켜봐야 해요.",
            left = Perspective(
                label = "진보 성향",
                caption = "진보 성향 언론 — 서민 물가 부담 완화 강조",
                headline = "“난방비·장바구니 물가 대책 서둘러야”",
                body = "이 시각의 언론은 전쟁의 여파가 결국 서민의 생활비로 이어진다는 점을 강조합니다. 겨울철 난방비 지원과 취약계층을 위한 물가 대책을 미리 마련해야 한다고 봅니다.",
                keywords = listOf("서민 물가", "난방비 지원", "취약계층 보호")
            ),
            right = Perspective(
                label = "보수 성향",
                caption = "보수 성향 언론 — 에너지 안보·공급망 강조",
                headline = "“에너지 수입처 다변화가 근본 해법”",
                body = "이 시각의 언론은 일시적인 지원보다 에너지·곡물 수입처를 넓히고 비축을 늘리는 등 공급망을 튼튼히 하는 것이 중요하다고 주장합니다. 안정적인 에너지원을 확보하는 것도 함께 강조합니다.",
                keywords = listOf("에너지 안보", "공급망 다변화", "비축 확대")
            ),
            glossary = listOf(
                GlossaryTerm("정유 시설", "땅에서 뽑은 원유를 휘발유·경유 같은 연료로 만드는 공장이에요.", listOf("정유 시설", "정유시설", "정유")),
                GlossaryTerm("흑해 항만", "우크라이나 남쪽 바다(흑해)에 있는 항구들로, 우크라이나 곡물을 배로 실어 나르는 길목이에요.", listOf("흑해", "항만", "항구")),
                GlossaryTerm("공급망", "물건이 만들어져 우리 손에 오기까지 이어지는 생산·운송 과정 전체를 말해요.", listOf("공급망")),
                GlossaryTerm("에너지 휴전", "발전소·정유 시설 같은 에너지 시설만큼은 서로 공격하지 말자는 부분 휴전이에요.", listOf("에너지 휴전", "에너지휴전"))
            ),
            videos = listOf(
                VideoItem("추위를 무기로 쓴 전쟁…얼어붙은 우크라이나", "KBS 시사", "HrgiVg3yy24"),
                VideoItem("전쟁 4주년 앞두고…러-우, 에너지 시설 끝없는 공방", "KBS News", "RBXel7JEQKs")
            )
        )
    )

    fun findById(id: Int): NewsItem = NEWS.firstOrNull { it.id == id } ?: NEWS.first()
}
