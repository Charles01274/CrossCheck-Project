package com.silveriron.crosscheck.model

/** 말풍선이 어디서 왔는지 구분해요. */
enum class MessageSource {
    USER,       // 사용자가 보낸 질문
    GREETING,   // 화면을 열었을 때 첫 인사
    AI,         // 생성형 AI(Gemini)가 만든 답변 → 'AI가 만든 답변' 표시 + 신고 버튼
    OFFLINE,    // AI 키가 없거나 연결이 안 될 때 앱에 내장된 기본 답변
    NOTICE,     // 안내 문구 (답변 거절 등)
    TYPING      // '답변을 준비하고 있어요…' 임시 말풍선
}

data class ChatMessage(
    val id: Long,
    val source: MessageSource,
    val text: String
) {
    val isUser: Boolean get() = source == MessageSource.USER
    val isTyping: Boolean get() = source == MessageSource.TYPING
    val isGenerated: Boolean get() = source == MessageSource.AI

    /** AI에게 '이전 대화'로 다시 보내줄 메시지인지 (인사·오류 안내는 빼요) */
    val includeInHistory: Boolean
        get() = source == MessageSource.USER || source == MessageSource.AI
}
