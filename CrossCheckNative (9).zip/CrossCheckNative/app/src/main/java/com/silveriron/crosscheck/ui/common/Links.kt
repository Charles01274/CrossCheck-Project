package com.silveriron.crosscheck.ui.common

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.silveriron.crosscheck.R

/**
 * 하이퍼링크 열기 모음.
 * 열 수 있는 앱이 없어도 앱이 꺼지지 않도록 안내 메시지만 보여줘요.
 */

/** 특정 유튜브 영상을 바로 재생해요: 유튜브 앱 → 없으면 브라우저 */
fun openYoutubeVideo(context: Context, videoId: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$videoId")))
    } catch (e: ActivityNotFoundException) {
        openWebPage(context, "https://www.youtube.com/watch?v=" + Uri.encode(videoId))
    }
}

/** 유튜브 검색 결과로 연결해요 (관련 영상을 못 찾았을 때의 대안) */
fun openYoutubeSearch(context: Context, query: String) {
    openWebPage(context, "https://www.youtube.com/results?search_query=" + Uri.encode(query))
}

/** 원문 기사 등 웹 페이지 열기 */
fun openWebPage(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, R.string.link_open_failed, Toast.LENGTH_SHORT).show()
    }
}
