package com.silveriron.crosscheck.news

import com.silveriron.crosscheck.model.NewsItem
import com.silveriron.crosscheck.model.Perspective

/** 네이버 뉴스 검색으로 받아온 실시간 기사 (제목·요약·원문 링크만 가져와요) */
data class LiveArticle(
    val id: String,
    val title: String,
    val summary: String,
    val link: String,
    val originalLink: String,
    val source: String,
    val category: String,
    val publishedAt: Long,
    val isBreaking: Boolean
) {
    /** 원문 기사 주소 (언론사 사이트 우선) */
    val bestLink: String
        get() = originalLink.ifBlank { link }
}

/**
 * AI 돋보기가 실시간 기사에 대해서도 답할 수 있도록 NewsItem 형태로 바꿔요.
 * 실시간 기사에는 '두 시각'·'해설' 자료가 아직 없으니 그 칸은 비워 두고(isLive = true),
 * AI와 기본 답변 엔진이 '제목·요약 안에서만' 설명하도록 해요.
 */
fun LiveArticle.toNewsItem(timeLabel: String): NewsItem = NewsItem(
    id = liveNumericId(id),
    tag = category,
    title = title,
    summary = summary,
    imageRes = 0,
    thumbRes = 0,
    time = timeLabel,
    perspectives = 0,
    summaryLines = listOf(summary.ifBlank { title }),
    whyItMatters = "",
    outlook = "",
    left = Perspective("", "", "", "", emptyList()),
    right = Perspective("", "", "", "", emptyList()),
    glossary = emptyList(),
    videos = emptyList(),
    isLive = true,
    sourceName = source
)

/** 샘플 기사 id(1, 2, 3…)와 절대 겹치지 않는 음수 id */
private fun liveNumericId(id: String): Int = -1000 - (id.hashCode() and 0x3FFFFFFF)
