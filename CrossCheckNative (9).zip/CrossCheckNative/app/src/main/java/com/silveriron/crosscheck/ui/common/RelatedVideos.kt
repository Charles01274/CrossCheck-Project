package com.silveriron.crosscheck.ui.common

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.youtube.RelatedVideoRepository
import com.silveriron.crosscheck.youtube.YouTubeVideo

/** 관련 영상 카드 한 장: 실제 영상(바로 재생) 또는 유튜브 검색 링크 */
sealed class RelatedLink {
    data class Video(val video: YouTubeVideo) : RelatedLink()
    data class Search(val title: String, val label: String, val query: String, val thumbUrl: String) : RelatedLink()
}

class RelatedVideoAdapter : RecyclerView.Adapter<RelatedVideoAdapter.VH>() {

    private var items: List<RelatedLink> = emptyList()

    fun submit(list: List<RelatedLink>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_video, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val thumb: ImageView = view.findViewById(R.id.videoThumb)
        private val badge: TextView = view.findViewById(R.id.videoBadge)
        private val title: TextView = view.findViewById(R.id.videoTitle)
        private val label: TextView = view.findViewById(R.id.videoLabel)

        init {
            thumb.clipToOutline = true
        }

        fun bind(link: RelatedLink) {
            val context = itemView.context
            when (link) {
                is RelatedLink.Video -> {
                    loadYoutubeThumbnail(thumb, link.video)
                    badge.setText(R.string.video_badge_youtube)
                    title.text = link.video.title
                    label.text = link.video.channel
                    itemView.contentDescription =
                        context.getString(R.string.video_play_description, link.video.channel, link.video.title)
                    itemView.setOnClickListener { openYoutubeVideo(it.context, link.video.videoId) }
                }
                is RelatedLink.Search -> {
                    if (link.thumbUrl.isNotBlank()) {
                        Glide.with(thumb).load(link.thumbUrl).centerCrop()
                            .placeholder(R.drawable.bg_video_placeholder).error(R.drawable.bg_video_placeholder).into(thumb)
                    } else {
                        thumb.setImageResource(R.drawable.bg_video_placeholder)
                    }
                    badge.setText(R.string.video_badge_search)
                    title.text = link.title
                    label.text = link.label
                    itemView.contentDescription = context.getString(R.string.video_open_description, link.title)
                    itemView.setOnClickListener { openYoutubeSearch(it.context, link.query) }
                }
            }
        }
    }
}

/**
 * 관련 영상 영역을 채워요.
 * 1) 먼저 '유튜브에서 찾아보기' 카드를 바로 보여주고 (빈 화면 없이)
 * 2) 방송사 공식 영상을 찾으면 실제 영상 카드로 바꿔요. 찾은 첫 영상은 기사 사진을 눌렀을 때도 재생돼요.
 */
class RelatedVideoSection(
    private val fragment: Fragment,
    private val recycler: RecyclerView,
    private val status: TextView
) {
    private val adapter = RelatedVideoAdapter()

    /** 찾은 영상 중 첫 번째 (아직 없으면 null) */
    var topVideo: YouTubeVideo? = null
        private set

    fun load(query: String, curated: List<YouTubeVideo>, fallback: List<RelatedLink.Search>) {
        val context = fragment.requireContext()
        recycler.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        recycler.adapter = adapter

        // 기사에 골라 둔 공식 영상이 있으면 그대로 보여줘요 (API 키·검색 없이 동작)
        if (curated.isNotEmpty()) {
            topVideo = curated.first()
            adapter.submit(curated.map { RelatedLink.Video(it) } + fallback.take(1))
            status.setText(R.string.related_videos_trusted)
            return
        }

        adapter.submit(fallback)
        status.setText(R.string.related_videos_loading)

        RelatedVideoRepository.find(context, query) { videos ->
            // 저장된 결과는 화면이 붙기 전에 '바로' 돌아올 수 있어서, 화면 부착 여부가 아니라
            // 화면(fragment)이 아직 살아 있는지로 판단해요.
            if (!fragment.isAdded || fragment.view == null) return@find
            if (videos.isEmpty()) {
                status.setText(R.string.related_videos_fallback)
                adapter.submit(fallback)
            } else {
                topVideo = videos.first()
                status.setText(R.string.related_videos_trusted)
                // 공식 영상 + 마지막에 '유튜브에서 더 찾아보기' 한 장
                adapter.submit(videos.map { RelatedLink.Video(it) } + fallback.take(1))
            }
        }
    }
}

/**
 * 유튜브 썸네일을 선명하게 불러와요.
 *  1) maxresdefault(1280×720, 16:9) → 대부분의 방송사 영상에 있어요
 *  2) 없으면 hqdefault(480×360) → 위아래 검은 띠는 가운데 맞춤 자르기로 잘려 나가요
 *  3) 인터넷이 없으면 어두운 자리표시 카드 (깨진 그림 대신)
 */
fun loadYoutubeThumbnail(target: ImageView, video: YouTubeVideo) {
    if (video.thumbnailUrl.isNotBlank()) {
        Glide.with(target).load(video.thumbnailUrl).centerCrop()
            .placeholder(R.drawable.bg_video_placeholder).error(R.drawable.bg_video_placeholder).into(target)
        return
    }
    val base = "https://i.ytimg.com/vi/" + video.videoId
    Glide.with(target)
        .load("$base/maxresdefault.jpg")
        .centerCrop()
        .placeholder(R.drawable.bg_video_placeholder)
        .error(
            Glide.with(target).load("$base/hqdefault.jpg").centerCrop().error(R.drawable.bg_video_placeholder)
        )
        .into(target)
}
