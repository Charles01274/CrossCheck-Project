package com.silveriron.crosscheck.ui.chat

import com.silveriron.crosscheck.model.NewsItem

/**
 * 오프라인 기본 답변 엔진 (키워드 매칭).
 *
 * 이제 진짜 생성형 AI(Gemini)가 답하고, 이 엔진은 아래 경우에만 '대신' 답해요.
 *  - local.properties에 GEMINI_API_KEY를 아직 넣지 않았을 때
 *  - 인터넷이 끊기거나 AI 사용량 한도를 넘었을 때
 *
 * 예전 버전은 우크라이나 기사 하나에만 맞춰져 있었는데, 이제는 각 기사가 가진 데이터
 * (3줄 요약·왜 중요한가·두 시각·용어 풀이)로 답을 만들어서 어떤 기사에서도 동작해요.
 */
object NewsChatEngine {

    private class Rule(val keywords: List<String>, val answer: (NewsItem) -> String)

    private val rules = listOf(
        Rule(listOf("요약", "정리", "핵심", "세줄", "3줄", "간단히", "쉽게 설명")) { numbered(it.summaryLines) },
        Rule(listOf("단어", "용어", "무슨 말", "무슨 뜻", "뜻이", "어려운")) { glossaryAll(it) },
        Rule(listOf("왜", "중요", "의미", "영향", "나한테")) { it.whyItMatters.ifBlank { noCommentary(it) } },
        Rule(listOf("찬성", "반대", "입장", "여당", "야당", "진보", "보수", "시각", "관점", "차이", "누가 옳")) { bothSides(it) },
        Rule(listOf("앞으로", "다음", "이후", "언제", "일정", "어떻게 되", "어떻게 돼")) { it.outlook.ifBlank { noCommentary(it) } },
        Rule(listOf("안녕", "고마워", "감사", "반가워")) { GREETING_REPLY }
    )

    /** 뜻을 묻는 말투 */
    private val DEFINITION_CUES = listOf("뭐", "뜻", "무슨", "무엇", "이란", "란?", "어떤 거", "말이에요", "설명해")

    private const val GREETING_REPLY =
        "네, 안녕하세요! 이 기사에 대해 궁금하신 점을 편하게 물어보세요. '왜 중요한가요?', '양쪽 입장은 어떻게 달라요?' 같은 질문도 좋아요."

    private const val FALLBACK =
        "죄송해요, 정확히 이해하지 못했어요. 이런 질문은 어떠세요?\n· 3줄로 요약해 주세요\n· 왜 중요한가요?\n· 양쪽 입장은 어떻게 달라요?"

    fun respond(article: NewsItem, userText: String): String {
        val text = userText.trim()
        if (text.isEmpty()) return FALLBACK

        val terms = article.glossary.filter { term -> term.keywords.any { text.contains(it) } }
        val best = rules
            .map { rule -> rule to rule.keywords.count { text.contains(it) } }
            .filter { (_, score) -> score > 0 }
            .maxByOrNull { (_, score) -> score }
            ?.first
        val asksMeaning = DEFINITION_CUES.any { text.contains(it) }

        // 1) "○○가 뭐예요?"처럼 뜻을 물으면 용어 풀이를 먼저 해요.
        // 2) "종전 협상은 언제 열려요?"처럼 다른 걸 물으면, 질문 속 용어보다 질문 의도를 우선해요.
        return when {
            terms.isNotEmpty() && (asksMeaning || best == null) ->
                terms.joinToString("\n\n") { "${it.term}: ${it.explanation}" }
            best != null -> best.answer.invoke(article)
            else -> FALLBACK
        }
    }

    private fun numbered(lines: List<String>): String {
        val marks = listOf("①", "②", "③", "④", "⑤")
        return lines.mapIndexed { i, line -> "${marks.getOrElse(i) { "${i + 1}." }} $line" }
            .joinToString("\n")
    }

    private fun glossaryAll(article: NewsItem): String =
        if (article.glossary.isEmpty()) {
            "이 기사에는 따로 정리해 둔 어려운 용어가 없어요. 궁금한 낱말을 직접 적어서 물어봐 주세요."
        } else {
            article.glossary.joinToString("\n") { "${it.term}: ${it.explanation}" }
        }

    private fun noCommentary(article: NewsItem): String =
        "이 기사는 아직 자세한 해설 자료가 없어요. 요약하면 이래요.\n${article.summaryLines.firstOrNull().orEmpty()}\n\n자세한 내용은 '원문 기사 보기'에서 확인해 주세요."

    private fun bothSides(article: NewsItem): String =
        if (article.left.label.isBlank()) {
            "이 기사는 아직 언론사별 시각 비교가 준비되지 않았어요. '시각 비교' 탭에서 두 시각이 정리된 이슈를 보실 수 있어요."
        } else bothSidesText(article)

    private fun bothSidesText(article: NewsItem): String =
        "[${article.left.label}] ${article.left.headline}\n${article.left.body}\n\n" +
            "[${article.right.label}] ${article.right.headline}\n${article.right.body}\n\n" +
            "어느 쪽이 옳은지는 직접 판단해 보세요. 두 시각은 '시각 비교' 화면에서 나란히 보실 수 있어요."
}
