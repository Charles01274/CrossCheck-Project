package com.silveriron.crosscheck.ui.settings

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.silveriron.crosscheck.BuildConfig
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.auth.AuthActions
import com.silveriron.crosscheck.auth.AuthStore
import com.silveriron.crosscheck.auth.LoginType
import com.silveriron.crosscheck.ui.common.AppViewModel
import com.silveriron.crosscheck.ui.common.FontBarView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 설정 화면 (하단 탭 맨 끝).
 *  내 정보 · 글씨 크기 · 화면 밝기 · 도움말 · 앱 정보 · 로그아웃
 * 시니어 사용자에게 꼭 필요한 것만 두고, 버튼은 모두 손가락으로 누르기 쉬운 크기로 만들었어요.
 */
class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel

        view.findViewById<FontBarView>(R.id.fontBar).connect(viewLifecycleOwner, appViewModel)

        bindAccount(view)
        bindFontSize(view, appViewModel)
        bindTheme(view, appViewModel)

        view.findViewById<View>(R.id.rowGuide).setOnClickListener {
            activity.navigateTo(MainActivity.Screen.TUTORIAL)
        }
        view.findViewById<View>(R.id.rowAiInfo).setOnClickListener {
            showInfo(R.string.settings_ai_info_title, R.string.settings_ai_info_body)
        }
        view.findViewById<View>(R.id.rowPrivacy).setOnClickListener {
            showInfo(R.string.settings_privacy_title, R.string.settings_privacy_body)
        }

        view.findViewById<TextView>(R.id.appInfo).text =
            getString(R.string.settings_app_info, BuildConfig.VERSION_NAME)

        // 로그인한 사람은 '로그아웃', 둘러보기 중인 사람은 '로그인하기'
        val logoutText = view.findViewById<TextView>(R.id.btnLogoutText)
        val btnLogout = view.findViewById<View>(R.id.btnLogout)
        if (AuthStore.current(requireContext()) == null) {
            logoutText.setText(R.string.settings_login)
            btnLogout.setOnClickListener { AuthActions.openLogin(activity) }
        } else {
            logoutText.setText(R.string.settings_logout)
            btnLogout.setOnClickListener { confirmLogout(activity) }
        }
    }

    private fun bindAccount(view: View) {
        val name = view.findViewById<TextView>(R.id.accountName)
        val detail = view.findViewById<TextView>(R.id.accountDetail)
        val session = AuthStore.current(requireContext())
        if (session == null) {
            name.setText(R.string.settings_guest_name)
            detail.setText(R.string.settings_guest_detail)
            return
        }
        name.text = session.displayName
        val method = getString(
            if (session.type == LoginType.KAKAO) R.string.settings_login_kakao else R.string.settings_login_phone
        )
        val date = SimpleDateFormat("yyyy년 M월 d일", Locale.KOREA).format(Date(session.loggedInAt))
        detail.text = getString(R.string.settings_account_detail, method, date)
    }

    /** 글씨 크기 3단계 — 누르면 바로 모든 화면에 적용되고 저장돼요. */
    private fun bindFontSize(view: View, appViewModel: AppViewModel) {
        val options = listOf(R.id.fontLevel1 to 1, R.id.fontLevel2 to 2, R.id.fontLevel3 to 3)
        options.forEach { (id, level) ->
            val segment = view.findViewById<TextView>(id)
            markSelected(segment, appViewModel.currentLevel == level)
            segment.contentDescription = getString(R.string.settings_font_option, segment.text, level)
            segment.setOnClickListener {
                if (appViewModel.currentLevel != level) appViewModel.setLevel(level)
            }
        }
    }

    /** 밝은 화면 / 어두운 화면(고대비) */
    private fun bindTheme(view: View, appViewModel: AppViewModel) {
        val light = view.findViewById<TextView>(R.id.themeLight)
        val dark = view.findViewById<TextView>(R.id.themeDark)
        markSelected(light, !appViewModel.isHighContrast)
        markSelected(dark, appViewModel.isHighContrast)
        light.setOnClickListener { if (appViewModel.isHighContrast) appViewModel.toggleContrast() }
        dark.setOnClickListener { if (!appViewModel.isHighContrast) appViewModel.toggleContrast() }
    }

    private fun markSelected(segment: TextView, selected: Boolean) {
        segment.setBackgroundResource(if (selected) R.drawable.bg_segment_selected else 0)
        segment.setTextColor(resources.getColor(if (selected) R.color.ink else R.color.ink2, requireContext().theme))
        segment.setTypeface(null, if (selected) Typeface.BOLD else Typeface.NORMAL)
        segment.isSelected = selected
    }

    private fun confirmLogout(activity: MainActivity) {
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.settings_logout_confirm_title)
            .setMessage(R.string.settings_logout_confirm_body)
            .setPositiveButton(R.string.settings_logout) { _, _ -> AuthActions.logout(activity) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showInfo(title: Int, body: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMessage(body)
            .setPositiveButton(R.string.ok, null)
            .show()
    }
}
