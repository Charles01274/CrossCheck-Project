package com.silveriron.crosscheck.ui.chat

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.silveriron.crosscheck.ai.GeminiClient
import com.silveriron.crosscheck.ai.PromptBuilder
import com.silveriron.crosscheck.model.ChatMessage
import com.silveriron.crosscheck.model.MessageSource
import com.silveriron.crosscheck.model.NewsItem
import java.util.concurrent.Executors

/**
 * AI 돋보기 대화 상태를 관리해요. MainActivity 범위로 만들어서
 *  - 다른 탭에 갔다 와도, 글씨 크기를 바꿔 화면이 다시 그려져도 대화가 지워지지 않고
 *  - 기사마다 대화를 따로 기억해요.
 * 답변을 기다리는 중에 다른 화면으로 가도, 도착한 답변은 원래 기사의 대화에 들어가요.
 */
class ChatViewModel : ViewModel() {

    private val gemini = GeminiClient()
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private val conversations = mutableMapOf<Int, MutableList<ChatMessage>>()
    private var article: NewsItem? = null
    private var pendingArticleId: Int? = null
    private var nextId = 1L

    private val _messages = MutableLiveData<List<ChatMessage>>(emptyList())
    val messages: LiveData<List<ChatMessage>> = _messages

    private val _isWaiting = MutableLiveData(false)
    val isWaiting: LiveData<Boolean> = _isWaiting

    /** local.properties에 Gemini 키가 들어 있는지 */
    val isAiConfigured: Boolean
        get() = gemini.isConfigured

    fun bindArticle(item: NewsItem) {
        article = item
        conversations.getOrPut(item.id) {
            mutableListOf(ChatMessage(nextId++, MessageSource.GREETING, greetingFor(item)))
        }
        publish()
    }

    /** @return 실제로 보냈으면 true (빈 글자이거나 이전 답변을 기다리는 중이면 false) */
    fun send(rawText: String): Boolean {
        val current = article ?: return false
        val question = rawText.trim()
        if (question.isEmpty() || pendingArticleId != null) return false

        val conversation = conversations.getOrPut(current.id) { mutableListOf() }
        val history = conversation.toList()
        conversation.add(ChatMessage(nextId++, MessageSource.USER, question))
        pendingArticleId = current.id
        publish()

        executor.execute {
            val reply = produceReply(current, history, question) // 백그라운드 스레드
            mainHandler.post { deliver(current.id, reply) }
        }
        return true
    }

    /** 신고할 답변 바로 앞에 사용자가 했던 질문을 찾아요. */
    fun questionBefore(message: ChatMessage): String? {
        val current = article ?: return null
        val list = conversations[current.id] ?: return null
        val index = list.indexOfFirst { it.id == message.id }
        if (index <= 0) return null
        return list.subList(0, index).lastOrNull { it.isUser }?.text
    }

    private fun produceReply(item: NewsItem, history: List<ChatMessage>, question: String): ChatMessage {
        if (!gemini.isConfigured) {
            // 키를 아직 넣지 않았으면 앱에 내장된 기본 답변으로 동작해요.
            return ChatMessage(0, MessageSource.OFFLINE, NewsChatEngine.respond(item, question))
        }

        val result = gemini.generate(
            PromptBuilder.systemInstruction(item),
            PromptBuilder.userTurn(history, question)
        )
        return when (result) {
            is GeminiClient.Result.Success -> ChatMessage(0, MessageSource.AI, result.text)
            is GeminiClient.Result.Failure -> {
                Log.w(TAG, "AI fallback: ${result.reason} ${result.detail}")
                fallbackFor(item, question, result.reason)
            }
        }
    }

    private fun fallbackFor(item: NewsItem, question: String, reason: GeminiClient.Reason): ChatMessage {
        if (reason == GeminiClient.Reason.BLOCKED) {
            return ChatMessage(
                0, MessageSource.NOTICE,
                "죄송해요, 이 질문에는 답변을 드리기 어려워요. 기사 내용에 대해 다른 질문을 해 주시겠어요?"
            )
        }
        val prefix = when (reason) {
            GeminiClient.Reason.NETWORK -> "인터넷 연결이 원활하지 않아 기본 답변으로 알려드릴게요."
            GeminiClient.Reason.QUOTA -> "지금은 AI를 찾는 분이 많아 잠시 기본 답변으로 알려드릴게요."
            else -> "AI가 잠시 답변하지 못해 기본 답변으로 알려드릴게요."
        }
        return ChatMessage(0, MessageSource.OFFLINE, prefix + "\n\n" + NewsChatEngine.respond(item, question))
    }

    private fun deliver(articleId: Int, reply: ChatMessage) {
        conversations.getOrPut(articleId) { mutableListOf() }.add(reply.copy(id = nextId++))
        pendingArticleId = null
        publish()
    }

    private fun publish() {
        val current = article ?: return
        val list = conversations[current.id].orEmpty().toMutableList()
        if (pendingArticleId == current.id) {
            list.add(ChatMessage(TYPING_ID, MessageSource.TYPING, "답변을 준비하고 있어요…"))
        }
        _messages.value = list
        _isWaiting.value = pendingArticleId != null
    }

    private fun greetingFor(item: NewsItem): String =
        "안녕하세요! '${item.title}' 기사에 대해 쉽게 설명해 드릴게요. 궁금한 점을 편하게 물어보세요."

    override fun onCleared() {
        mainHandler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        super.onCleared()
    }

    companion object {
        private const val TAG = "ChatViewModel"
        private const val TYPING_ID = -1L
    }
}
