package com.silveriron.crosscheck.youtube

import android.content.Context
import android.util.Log
import com.silveriron.crosscheck.BuildConfig
import com.silveriron.crosscheck.news.NewsText
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * YouTube Data API v3 검색으로 기사와 관련된 '실제 영상'을 찾아요.
 *  - 한국 지역·한국어 우선, 안전 검색(strict)
 *  - 검색 1번에 할당량 100 단위가 들어요 (기본 하루 10,000 단위) → RelatedVideoRepository가 하루 동안 저장해 둬요.
 */
class YouTubeClient(private val apiKey: String = BuildConfig.YOUTUBE_API_KEY) {

    val isConfigured: Boolean
        get() = apiKey.isNotBlank()

    sealed class Result {
        data class Success(val videos: List<YouTubeVideo>) : Result()
        data class Failure(val detail: String) : Result()
    }

    /** 네트워크를 쓰므로 백그라운드 스레드에서 호출하세요. */
    fun search(context: Context, query: String, maxResults: Int = 15): Result {
        if (!isConfigured) return Result.Failure("not configured")
        val url = URL(
            "$ENDPOINT?part=snippet&type=video&order=relevance&regionCode=KR&relevanceLanguage=ko" +
                "&safeSearch=strict&maxResults=${maxResults.coerceIn(1, 50)}" +
                "&q=${URLEncoder.encode(query, "UTF-8")}&key=${URLEncoder.encode(apiKey, "UTF-8")}"
        )
        var connection: HttpURLConnection? = null
        return try {
            val conn = url.openConnection() as HttpURLConnection
            connection = conn
            conn.requestMethod = "GET"
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            AndroidKeyHeaders.apply(context, conn)

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code in 200..299) {
                Result.Success(parse(raw))
            } else {
                Log.w(TAG, "YouTube search HTTP $code: ${raw.take(300)}")
                Result.Failure("HTTP $code")
            }
        } catch (e: IOException) {
            Log.w(TAG, "YouTube network error", e)
            Result.Failure(e.javaClass.simpleName)
        } catch (e: Exception) {
            Log.w(TAG, "YouTube unexpected error", e)
            Result.Failure(e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    private fun parse(raw: String): List<YouTubeVideo> {
        val items = JSONObject(raw).optJSONArray("items") ?: return emptyList()
        val videos = ArrayList<YouTubeVideo>(items.length())
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val videoId = item.optJSONObject("id")?.optString("videoId", "").orEmpty()
            val snippet = item.optJSONObject("snippet") ?: continue
            if (videoId.isBlank()) continue
            val thumbs = snippet.optJSONObject("thumbnails")
            val thumb = listOf("medium", "high", "default")
                .firstNotNullOfOrNull { size -> thumbs?.optJSONObject(size)?.optString("url", "")?.takeIf { it.isNotBlank() } }
                ?: "https://i.ytimg.com/vi/$videoId/mqdefault.jpg"
            videos += YouTubeVideo(
                videoId = videoId,
                // API는 제목 속 따옴표 등을 &quot; 같은 기호로 보내서 원래 글자로 바꿔요.
                title = NewsText.stripHtml(snippet.optString("title", "")),
                channel = NewsText.stripHtml(snippet.optString("channelTitle", "")),
                thumbnailUrl = thumb
            )
        }
        return videos
    }

    companion object {
        private const val TAG = "YouTubeClient"
        private const val ENDPOINT = "https://www.googleapis.com/youtube/v3/search"
    }
}
