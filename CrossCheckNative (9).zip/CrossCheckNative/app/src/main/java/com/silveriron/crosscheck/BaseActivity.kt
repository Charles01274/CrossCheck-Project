package com.silveriron.crosscheck

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModelProvider
import com.silveriron.crosscheck.ui.common.AppPrefs
import com.silveriron.crosscheck.ui.common.AppViewModel

/**
 * 모든 화면(로그인·메인)이 함께 쓰는 기본 설정이에요.
 *  - 저장된 글씨 단계를 실제 글씨 배율로 적용
 *  - 글씨 크기·고대비 설정이 바뀌면 저장하고 화면을 다시 그리기
 *  - 상단 상태바(시간·와이파이·배터리) 숨기기, 노치·키보드 여백 계산
 * 예전에는 MainActivity 안에만 있었는데, 로그인 화면에도 똑같이 적용하려고 분리했어요.
 */
abstract class BaseActivity : AppCompatActivity() {

    lateinit var appViewModel: AppViewModel
        private set

    /**
     * 저장된 글씨 단계를 실제 글씨 배율(fontScale)로 적용해요.
     * 휴대폰 설정의 글씨 크기에 곱해지기 때문에, 이미 크게 쓰시는 분은 그보다 더 크게 보여요.
     */
    override fun attachBaseContext(newBase: Context) {
        val config = Configuration(newBase.resources.configuration)
        config.fontScale = AppPrefs.effectiveFontScale(config.fontScale, AppPrefs.getLevel(newBase))
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupWindow()

        appViewModel = ViewModelProvider(this)[AppViewModel::class.java]
        appViewModel.initFromPrefs(AppPrefs.getLevel(this), AppPrefs.isHighContrast(this))

        // 글씨 크기: 저장 → 화면 다시 그리기 (fontScale은 화면을 새로 만들 때만 적용돼요)
        appViewModel.level.observe(this) { level ->
            if (level != AppPrefs.getLevel(this)) {
                AppPrefs.setLevel(this, level)
                recreate()
            }
        }
        // 고대비: 저장 → 어두운/밝은 화면 전환 (AppCompat이 화면을 자동으로 다시 그려요)
        appViewModel.highContrast.observe(this) { enabled ->
            if (enabled != AppPrefs.isHighContrast(this)) {
                AppPrefs.setHighContrast(this, enabled)
                AppCompatDelegate.setDefaultNightMode(
                    if (enabled) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hideStatusBar()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 대화상자·키보드가 닫힌 뒤 일부 기기에서 상태바가 다시 나타나는 걸 막아요.
        if (hasFocus) hideStatusBar()
    }

    @Suppress("DEPRECATION")
    private fun setupWindow() {
        // 화면 끝까지 그리고(edge-to-edge), 시스템 바 영역만큼의 여백은 applyWindowInsets에서 계산해요.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // 상태바를 숨겼을 때 카메라 구멍(노치) 영역에 검은 띠가 생기지 않게 해요.
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.navigationBarColor = Color.TRANSPARENT
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            // Android 10 이하는 상태바를 숨기면 adjustResize가 동작하지 않는 오래된 버그가 있어서,
            // 키보드가 입력창을 가리지 않도록 화면을 위로 밀어 올리는 방식(adjustPan)을 써요.
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        }
    }

    /**
     * 노치·하단 내비게이션 바·키보드 높이만큼 여백을 줘서 화면이 가려지지 않게 해요.
     * @param onImeVisibility 키보드가 열리고 닫힐 때 알려줘요 (예: 하단 탭 숨기기)
     */
    protected fun applyWindowInsets(root: View, onImeVisibility: (Boolean) -> Unit = {}) {
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val imeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            val imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            view.setPadding(bars.left, bars.top, bars.right, if (imeVisible) imeBottom else bars.bottom)
            onImeVisibility(imeVisible)
            WindowInsetsCompat.CONSUMED
        }
    }

    /**
     * 화면 맨 위의 상태바(시간·와이파이·배터리)를 숨겨요.
     * 화면 위쪽 끝을 아래로 쓸어내리면 잠깐 다시 보였다가 자동으로 사라져요.
     */
    protected fun hideStatusBar() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.statusBars())

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        controller.isAppearanceLightStatusBars = !night
        controller.isAppearanceLightNavigationBars = !night
    }
}
