package com.silveriron.crosscheck.news

import android.util.Log
import com.silveriron.crosscheck.BuildConfig
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 네이버 검색 API(뉴스)로 최신 기사 목록을 받아와요. (하루 25,000회까지 무료)
 *
 * 왜 RSS가 아니라 네이버 API인가요?
 *  국내 주요 언론사 이용 규칙(한국디지털뉴스협회 기준)은 RSS를 '개인 구독'에만 허용하고,
 *  허락 없이 앱에서 여러 사람에게 다시 배포하는 것을 금지해요. 그래서 정식으로 검색 결과를
 *  제공하는 네이버 API를 쓰고, 화면에는 제목·짧은 요약·원문 링크만 보여줘요.
 */
class NaverNewsClient(
    private val clientId: String = BuildConfig.NAVER_CLIENT_ID,
    private val clientSecret: String = BuildConfig.NAVER_CLIENT_SECRET
) {
    val isConfigured: Boolean
        get() = clientId.isNotBlank() && clientSecret.isNotBlank()

    sealed class Result {
        data class Success(val items: List<LiveArticle>) : Result()
        data class Failure(val reason: Reason, val detail: String = "") : Result()
    }

    enum class Reason { NOT_CONFIGURED, NETWORK, QUOTA, AUTH, SERVER }

    /** 네트워크를 쓰므로 백그라운드 스레드에서 호출하세요. */
    fun search(query: String, display: Int, category: String, fetchedAt: Long): Result {
        if (!isConfigured) return Result.Failure(Reason.NOT_CONFIGURED)

        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("$ENDPOINT?query=$encoded&display=${display.coerceIn(1, 100)}&start=1&sort=date")
        var connection: HttpURLConnection? = null
        return try {
            val conn = url.openConnection() as HttpURLConnection
            connection = conn
            conn.requestMethod = "GET"
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.setRequestProperty("X-Naver-Client-Id", clientId)
            conn.setRequestProperty("X-Naver-Client-Secret", clientSecret)

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            when {
                code in 200..299 -> Result.Success(parse(raw, category, fetchedAt))
                code == 429 -> Result.Failure(Reason.QUOTA, raw.take(200))
                code == 401 || code == 403 -> Result.Failure(Reason.AUTH, raw.take(200))
                else -> Result.Failure(Reason.SERVER, "HTTP $code ${raw.take(200)}")
            }.also { if (it is Result.Failure) Log.w(TAG, "Naver news '$query' failed: ${it.reason} ${it.detail}") }
        } catch (e: IOException) {
            Log.w(TAG, "Naver news network error", e)
            Result.Failure(Reason.NETWORK, e.javaClass.simpleName)
        } catch (e: Exception) {
            Log.w(TAG, "Naver news unexpected error", e)
            Result.Failure(Reason.SERVER, e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    private fun parse(raw: String, category: String, fetchedAt: Long): List<LiveArticle> {
        val items = JSONObject(raw).optJSONArray("items") ?: return emptyList()
        val result = ArrayList<LiveArticle>(items.length())
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val rawTitle = NewsText.stripHtml(item.optString("title", ""))
            if (rawTitle.isBlank()) continue
            val originalLink = item.optString("originallink", "").trim()
            val link = item.optString("link", "").trim()
            val anyLink = originalLink.ifBlank { link }
            if (anyLink.isBlank()) continue

            val breaking = NewsText.isBreaking(rawTitle)
            result += LiveArticle(
                id = NewsText.stableId(anyLink),
                title = NewsText.cleanTitle(rawTitle),
                summary = NewsText.stripHtml(item.optString("description", "")),
                link = link,
                originalLink = originalLink,
                source = NewsText.outletName(anyLink),
                category = if (breaking) "속보" else category,
                publishedAt = NewsText.parseDate(item.optString("pubDate", "")) ?: fetchedAt,
                isBreaking = breaking
            )
        }
        return result
    }

    companion object {
        private const val TAG = "NaverNewsClient"
        private const val ENDPOINT = "https://openapi.naver.com/v1/search/news.json"
    }
}
