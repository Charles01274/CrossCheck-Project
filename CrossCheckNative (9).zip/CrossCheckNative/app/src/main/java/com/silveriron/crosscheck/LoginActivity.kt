package com.silveriron.crosscheck

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.silveriron.crosscheck.auth.AuthSession
import com.silveriron.crosscheck.auth.AuthStore
import com.silveriron.crosscheck.auth.KakaoAuth
import com.silveriron.crosscheck.auth.LoginType
import com.silveriron.crosscheck.auth.OtpSession
import com.silveriron.crosscheck.auth.PhoneNumbers
import com.silveriron.crosscheck.ui.common.FontBarView

/**
 * 앱의 첫 화면(시작 화면).
 *  - 이미 로그인한 적이 있으면 이 화면을 건너뛰고 바로 뉴스로 들어가요 (자동 로그인).
 *  - 카카오 로그인 / 전화번호 로그인 / 로그인 없이 둘러보기
 *  - 처음 로그인하면 사용 가이드로 바로 안내해요.
 */
class LoginActivity : BaseActivity() {

    /** 글씨 크기를 바꾸면 화면이 다시 그려져서, 입력 중이던 인증 상태를 여기에 보관해요. */
    class LoginState : ViewModel() {
        val otp = OtpSession()
        var phoneDigits: String = ""
        var autoFilled = false
    }

    private lateinit var state: LoginState
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var scroll: NestedScrollView
    private lateinit var phoneInput: EditText
    private lateinit var btnRequestCode: View
    private lateinit var codeSection: View
    private lateinit var smsDemo: TextView
    private lateinit var codeInput: EditText
    private lateinit var autoFillNote: TextView
    private lateinit var timerText: TextView
    private lateinit var btnKakao: View
    private lateinit var kakaoLabel: TextView

    /** 1초마다 남은 시간을 새로 표시해요. */
    private val ticker = object : Runnable {
        override fun run() {
            renderTimer()
            if (state.otp.code != null && state.otp.remainingMs() > 0) handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 자동 로그인: 저장된 로그인 정보가 있으면 이 화면 없이 바로 들어가요.
        if (AuthStore.current(this) != null) {
            openMain(firstLogin = false)
            return
        }

        setContentView(R.layout.activity_login)
        applyWindowInsets(findViewById(R.id.root))
        hideStatusBar()
        findViewById<FontBarView>(R.id.fontBar).connect(this, appViewModel)
        state = ViewModelProvider(this)[LoginState::class.java]

        scroll = findViewById(R.id.scroll)
        phoneInput = findViewById(R.id.phoneInput)
        btnRequestCode = findViewById(R.id.btnRequestCode)
        codeSection = findViewById(R.id.codeSection)
        smsDemo = findViewById(R.id.smsDemo)
        codeInput = findViewById(R.id.codeInput)
        autoFillNote = findViewById(R.id.autoFillNote)
        timerText = findViewById(R.id.timerText)
        btnKakao = findViewById(R.id.btnKakao)
        kakaoLabel = findViewById(R.id.kakaoLabel)

        // ── 카카오 로그인 ──
        if (!KakaoAuth.isConfigured) findViewById<View>(R.id.kakaoNotice).visibility = View.VISIBLE
        btnKakao.setOnClickListener { startKakaoLogin() }

        // ── 전화번호 로그인 ──
        // 입력하는 대로 010-1234-5678 모양으로 하이픈을 넣어 줘요.
        phoneInput.addTextChangedListener(PhoneHyphenWatcher())
        phoneInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                requestCode()
                true
            } else {
                false
            }
        }
        btnRequestCode.setOnClickListener { requestCode() }
        findViewById<View>(R.id.btnResend).setOnClickListener { requestCode() }
        findViewById<View>(R.id.btnVerify).setOnClickListener { verifyCode() }
        codeInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                verifyCode()
                true
            } else {
                false
            }
        }

        // ── 로그인 없이 둘러보기 (저장하지 않아서 다음에 열면 다시 이 화면이 나와요) ──
        findViewById<View>(R.id.btnGuest).setOnClickListener {
            AuthStore.guestMode = true
            openMain(firstLogin = false)
        }

        // 글씨 크기를 바꿔 화면이 다시 그려진 경우, 받아 둔 인증번호 화면을 그대로 보여줘요.
        if (state.otp.code != null) showCodeSection()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ── 카카오 ─────────────────────────────────────────────

    private fun startKakaoLogin() {
        if (!KakaoAuth.isConfigured) {
            Toast.makeText(this, R.string.login_kakao_not_configured, Toast.LENGTH_LONG).show()
            return
        }
        setKakaoBusy(true)
        KakaoAuth.login(this) { result ->
            if (isFinishing || isDestroyed) return@login
            setKakaoBusy(false)
            when (result) {
                is KakaoAuth.Result.Success ->
                    completeLogin(AuthSession(LoginType.KAKAO, result.nickname, System.currentTimeMillis()))
                KakaoAuth.Result.Cancelled -> Unit // 사용자가 취소함: 아무것도 하지 않아요
                is KakaoAuth.Result.Failure ->
                    Toast.makeText(this, R.string.login_kakao_failed, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun setKakaoBusy(busy: Boolean) {
        btnKakao.isEnabled = !busy
        btnKakao.alpha = if (busy) 0.6f else 1f
        kakaoLabel.setText(if (busy) R.string.login_kakao_busy else R.string.login_kakao)
    }

    // ── 전화번호 ───────────────────────────────────────────

    private fun requestCode() {
        val raw = phoneInput.text.toString()
        if (!PhoneNumbers.isValidMobile(raw)) {
            phoneInput.error = getString(R.string.login_phone_invalid)
            phoneInput.requestFocus()
            return
        }
        state.phoneDigits = PhoneNumbers.digitsOnly(raw)
        state.otp.issue()
        state.autoFilled = false
        hideKeyboard()
        showCodeSection()
    }

    /**
     * 인증번호 입력 영역을 보여줘요.
     * 전시용: 실제 문자 대신 문자처럼 보이는 상자에 인증번호를 보여주고, 잠시 뒤 자동으로 입력해요
     * (실제 앱에서는 문자 자동 입력(SMS Retriever) 기능이 같은 역할을 해요).
     */
    private fun showCodeSection() {
        val code = state.otp.code ?: return
        codeSection.visibility = View.VISIBLE
        btnRequestCode.visibility = View.GONE
        smsDemo.text = getString(R.string.login_sms_demo, code)
        codeInput.error = null

        if (state.autoFilled) {
            fillCode(code)
        } else {
            codeInput.setText("")
            autoFillNote.visibility = View.GONE
            handler.postDelayed({
                if (!isFinishing && state.otp.code == code) {
                    state.autoFilled = true
                    fillCode(code)
                }
            }, AUTO_FILL_DELAY_MS)
        }

        handler.removeCallbacks(ticker)
        handler.post(ticker)
        scroll.post { scroll.smoothScrollTo(0, codeSection.top) }
    }

    private fun fillCode(code: String) {
        codeInput.setText(code)
        codeInput.setSelection(code.length)
        autoFillNote.visibility = View.VISIBLE
    }

    private fun renderTimer() {
        if (state.otp.code == null) {
            timerText.text = ""
            return
        }
        val remaining = state.otp.remainingMs()
        if (remaining <= 0L) {
            timerText.setText(R.string.login_code_timeout)
            timerText.setTextColor(color(R.color.red))
        } else {
            timerText.text = getString(R.string.login_code_remaining, OtpSession.formatRemaining(remaining))
            timerText.setTextColor(color(if (remaining < 30_000L) R.color.red else R.color.faint))
        }
    }

    private fun verifyCode() {
        when (state.otp.verify(codeInput.text.toString())) {
            OtpSession.Result.OK -> completeLogin(
                AuthSession(LoginType.PHONE, PhoneNumbers.mask(state.phoneDigits), System.currentTimeMillis())
            )
            OtpSession.Result.WRONG -> codeInput.error = getString(R.string.login_code_wrong)
            OtpSession.Result.EXPIRED -> codeInput.error = getString(R.string.login_code_expired)
            OtpSession.Result.TOO_MANY -> {
                state.otp.reset()
                Toast.makeText(this, R.string.login_code_too_many, Toast.LENGTH_LONG).show()
                codeSection.visibility = View.GONE
                btnRequestCode.visibility = View.VISIBLE
            }
            OtpSession.Result.NOT_ISSUED ->
                Toast.makeText(this, R.string.login_code_request_first, Toast.LENGTH_SHORT).show()
        }
    }

    // ── 공통 ───────────────────────────────────────────────

    private fun completeLogin(session: AuthSession) {
        AuthStore.save(this, session)
        openMain(firstLogin = true)
    }

    private fun openMain(firstLogin: Boolean) {
        startActivity(Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_GUIDE, firstLogin))
        finish()
    }

    private fun hideKeyboard() {
        getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(phoneInput.windowToken, 0)
    }

    private fun color(res: Int) = resources.getColor(res, theme)

    /**
     * 입력하는 대로 010-1234-5678 모양으로 하이픈을 넣어요.
     * (안드로이드 기본 PhoneNumberFormattingTextWatcher는 최신 버전에서 사용 중단 예정이라 직접 만들었어요.)
     */
    private class PhoneHyphenWatcher : TextWatcher {
        private var editing = false
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
        override fun afterTextChanged(s: Editable) {
            if (editing) return
            val formatted = PhoneNumbers.formatPartial(s.toString())
            if (formatted != s.toString()) {
                editing = true
                s.replace(0, s.length, formatted)
                editing = false
            }
        }
    }

    companion object {
        /** 인증번호를 보여준 뒤 자동으로 입력하기까지 기다리는 시간 */
        private const val AUTO_FILL_DELAY_MS = 1500L
    }
}
