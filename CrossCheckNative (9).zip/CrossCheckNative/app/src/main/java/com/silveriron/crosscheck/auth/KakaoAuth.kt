package com.silveriron.crosscheck.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import com.kakao.sdk.auth.model.OAuthToken
import com.kakao.sdk.common.KakaoSdk
import com.kakao.sdk.common.model.ClientError
import com.kakao.sdk.common.model.ClientErrorCause
import com.kakao.sdk.common.util.Utility
import com.kakao.sdk.user.UserApiClient
import com.silveriron.crosscheck.BuildConfig

/**
 * 카카오 로그인 (공식 Kakao SDK).
 *  - 카카오톡 앱이 있으면 앱으로, 없으면 카카오계정(웹 화면)으로 로그인해요.
 *  - 로그인 후 닉네임만 받아서 '내 정보'에 보여줘요.
 *  - 키(local.properties의 KAKAO_NATIVE_APP_KEY)가 없으면 카카오 버튼은 안내만 보여주고 앱은 그대로 동작해요.
 */
object KakaoAuth {
    private const val TAG = "KakaoAuth"

    val isConfigured: Boolean
        get() = BuildConfig.KAKAO_NATIVE_APP_KEY.isNotBlank()

    sealed class Result {
        data class Success(val nickname: String) : Result()
        object Cancelled : Result()
        data class Failure(val message: String) : Result()
    }

    fun init(context: Context) {
        if (!isConfigured) return
        KakaoSdk.init(context, BuildConfig.KAKAO_NATIVE_APP_KEY)
        if (BuildConfig.DEBUG) {
            // 카카오 개발자 콘솔의 Android 플랫폼에 등록해야 하는 '키 해시'를 Logcat에 보여줘요.
            Log.d("KakaoKeyHash", "카카오 개발자 콘솔에 등록할 키 해시: ${Utility.getKeyHash(context)}")
        }
    }

    fun login(activity: Activity, onResult: (Result) -> Unit) {
        val accountCallback: (OAuthToken?, Throwable?) -> Unit = { token, error ->
            handleToken(token, error, onResult)
        }
        val client = UserApiClient.instance
        if (client.isKakaoTalkLoginAvailable(activity)) {
            client.loginWithKakaoTalk(activity) { token, error ->
                if (error != null) {
                    if (isCancelled(error)) {
                        onResult(Result.Cancelled)
                        return@loginWithKakaoTalk
                    }
                    // 카카오톡에 로그인돼 있지 않은 경우 등 → 카카오계정으로 다시 시도해요.
                    Log.w(TAG, "KakaoTalk login failed, falling back to account login", error)
                    client.loginWithKakaoAccount(activity, callback = accountCallback)
                } else {
                    handleToken(token, null, onResult)
                }
            }
        } else {
            client.loginWithKakaoAccount(activity, callback = accountCallback)
        }
    }

    private fun handleToken(token: OAuthToken?, error: Throwable?, onResult: (Result) -> Unit) {
        if (error != null) {
            Log.w(TAG, "Kakao login failed", error)
            onResult(if (isCancelled(error)) Result.Cancelled else Result.Failure(error.message.orEmpty()))
            return
        }
        if (token == null) {
            onResult(Result.Failure("empty token"))
            return
        }
        // 동의 항목에서 '닉네임'을 켜 두면 받아와요. 못 받으면 '카카오 사용자'로 표시해요.
        UserApiClient.instance.me { user, meError ->
            if (meError != null) Log.w(TAG, "Kakao profile request failed", meError)
            val nickname = user?.kakaoAccount?.profile?.nickname?.takeIf { it.isNotBlank() }
            onResult(Result.Success(nickname ?: DEFAULT_NAME))
        }
    }

    fun logout(onDone: () -> Unit) {
        if (!isConfigured) {
            onDone()
            return
        }
        UserApiClient.instance.logout { error ->
            if (error != null) Log.w(TAG, "Kakao logout failed (local logout still done)", error)
            onDone()
        }
    }

    private fun isCancelled(error: Throwable): Boolean =
        error is ClientError && error.reason == ClientErrorCause.Cancelled

    const val DEFAULT_NAME = "카카오 사용자"
}
