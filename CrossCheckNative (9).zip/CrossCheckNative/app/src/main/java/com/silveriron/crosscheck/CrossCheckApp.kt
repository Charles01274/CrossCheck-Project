package com.silveriron.crosscheck

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.silveriron.crosscheck.auth.KakaoAuth
import com.silveriron.crosscheck.news.NewsScheduler
import com.silveriron.crosscheck.ui.common.AppPrefs

/**
 * 앱이 시작될 때 저장된 고대비(어두운 화면) 설정을 먼저 적용해요.
 * 이전에는 휴대폰이 다크 모드면 앱도 어두워졌는데, 화면 밝기 버튼은 '꺼짐'으로 표시돼
 * 첫 번째 누름이 아무 반응이 없는 것처럼 보이는 문제가 있었어요.
 */
class CrossCheckApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppCompatDelegate.setDefaultNightMode(
            if (AppPrefs.isHighContrast(this)) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
        // 전시용은 고정 뉴스만 보여줘요. 정식 앱(LIVE_NEWS_ENABLED = true)에서만 6시간 자동 갱신을 예약해요.
        if (BuildConfig.LIVE_NEWS_ENABLED) NewsScheduler.schedule(this) else NewsScheduler.cancel(this)
        // 카카오 로그인 준비 (키가 없으면 아무것도 하지 않아요)
        KakaoAuth.init(this)
    }
}
