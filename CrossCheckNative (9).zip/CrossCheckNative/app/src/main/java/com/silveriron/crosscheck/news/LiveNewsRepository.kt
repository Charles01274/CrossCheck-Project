package com.silveriron.crosscheck.news

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 실시간 뉴스 저장소.
 *  - 6시간마다(백그라운드 WorkManager) + 앱을 열었는데 6시간이 지났을 때 + 당겨서 새로고침 할 때 갱신
 *  - 받아온 기사는 휴대폰에 저장해 두어, 인터넷이 없어도 마지막 뉴스를 보여줘요.
 */
object LiveNewsRepository {

    const val REFRESH_INTERVAL_HOURS = 6L
    const val REFRESH_INTERVAL_MS = REFRESH_INTERVAL_HOURS * 60 * 60 * 1000

    private const val TAG = "LiveNewsRepository"
    private const val CACHE_FILE = "live_news_cache.json"

    private data class Query(val text: String, val display: Int, val category: String)

    /** '속보'로 속보를 모으고, 분야별 최신 기사를 함께 받아와요 (갱신 1번에 API 4회) */
    private val QUERIES = listOf(
        Query("속보", 40, "속보"),
        Query("정치", 15, "정치"),
        Query("경제", 15, "경제"),
        Query("사회", 15, "사회")
    )

    data class Snapshot(
        val articles: List<LiveArticle>,
        val updatedAt: Long,
        val lastError: NaverNewsClient.Reason?
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)
    private val fileLock = Any()
    @Volatile private var loaded = false

    private val _snapshot = MutableLiveData<Snapshot>()
    val snapshot: LiveData<Snapshot> = _snapshot

    private val _refreshing = MutableLiveData(false)
    val refreshing: LiveData<Boolean> = _refreshing

    /** 저장해 둔 뉴스를 먼저 보여줘요 (앱을 켜자마자 빈 화면이 되지 않게). */
    fun ensureLoaded(context: Context) {
        if (loaded) return
        val app = context.applicationContext
        executor.execute {
            if (!loaded) {
                _snapshot.postValue(readCache(app))
                loaded = true
            }
        }
    }

    /** 마지막 갱신 후 6시간이 지났으면 지금 갱신해요. */
    fun refreshIfStale(context: Context) {
        val app = context.applicationContext
        executor.execute {
            val current = _snapshot.value ?: readCache(app)
            if (System.currentTimeMillis() - current.updatedAt >= REFRESH_INTERVAL_MS) refreshInternal(app)
        }
    }

    /** 당겨서 새로고침 */
    fun refreshNow(context: Context) {
        val app = context.applicationContext
        executor.execute { refreshInternal(app) }
    }

    /** 백그라운드 작업(NewsSyncWorker)이 호출해요. 현재 스레드에서 실행돼요. */
    fun refreshBlocking(context: Context): NaverNewsClient.Reason? = refreshInternal(context.applicationContext)

    private fun refreshInternal(app: Context): NaverNewsClient.Reason? {
        if (!running.compareAndSet(false, true)) return null // 이미 다른 곳에서 갱신 중
        _refreshing.postValue(true)
        try {
            val previous = readCache(app)
            val client = NaverNewsClient()
            if (!client.isConfigured) {
                publish(previous.copy(lastError = NaverNewsClient.Reason.NOT_CONFIGURED))
                return NaverNewsClient.Reason.NOT_CONFIGURED
            }

            val now = System.currentTimeMillis()
            val batches = ArrayList<List<LiveArticle>>()
            var lastFailure: NaverNewsClient.Reason? = null
            for (query in QUERIES) {
                when (val result = client.search(query.text, query.display, query.category, now)) {
                    is NaverNewsClient.Result.Success -> batches += result.items
                    is NaverNewsClient.Result.Failure -> lastFailure = result.reason
                }
            }
            if (batches.isEmpty()) {
                // 모두 실패하면 이전 뉴스를 그대로 두고 이유만 알려줘요.
                publish(previous.copy(lastError = lastFailure))
                return lastFailure
            }

            val merged = FeedArranger.merge(batches).filter { now - it.publishedAt <= FeedArranger.KEEP_WINDOW_MS }
            val fresh = Snapshot(merged, now, null)
            writeCache(app, fresh)
            publish(fresh)
            return null
        } catch (e: Exception) {
            Log.w(TAG, "refresh failed", e)
            return NaverNewsClient.Reason.SERVER
        } finally {
            running.set(false)
            _refreshing.postValue(false)
        }
    }

    private fun publish(snapshot: Snapshot) {
        _snapshot.postValue(snapshot)
        loaded = true
    }

    // ── 휴대폰 저장 (JSON 파일) ─────────────────────────────────────

    private fun readCache(app: Context): Snapshot = synchronized(fileLock) {
        try {
            val file = File(app.filesDir, CACHE_FILE)
            if (!file.exists()) return Snapshot(emptyList(), 0L, null)
            val json = JSONObject(file.readText(Charsets.UTF_8))
            val array = json.optJSONArray("articles") ?: JSONArray()
            val articles = ArrayList<LiveArticle>(array.length())
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                articles += LiveArticle(
                    id = o.optString("id"),
                    title = o.optString("title"),
                    summary = o.optString("summary"),
                    link = o.optString("link"),
                    originalLink = o.optString("originalLink"),
                    source = o.optString("source"),
                    category = o.optString("category"),
                    publishedAt = o.optLong("publishedAt"),
                    isBreaking = o.optBoolean("isBreaking")
                )
            }
            Snapshot(articles, json.optLong("updatedAt"), null)
        } catch (e: Exception) {
            Log.w(TAG, "cache read failed", e)
            Snapshot(emptyList(), 0L, null)
        }
    }

    private fun writeCache(app: Context, snapshot: Snapshot) = synchronized(fileLock) {
        try {
            val array = JSONArray()
            snapshot.articles.forEach { a ->
                array.put(
                    JSONObject()
                        .put("id", a.id).put("title", a.title).put("summary", a.summary)
                        .put("link", a.link).put("originalLink", a.originalLink).put("source", a.source)
                        .put("category", a.category).put("publishedAt", a.publishedAt).put("isBreaking", a.isBreaking)
                )
            }
            val json = JSONObject().put("updatedAt", snapshot.updatedAt).put("articles", array)
            File(app.filesDir, CACHE_FILE).writeText(json.toString(), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.w(TAG, "cache write failed", e)
        }
    }
}
