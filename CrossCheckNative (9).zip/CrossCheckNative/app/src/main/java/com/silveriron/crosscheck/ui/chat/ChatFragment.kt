package com.silveriron.crosscheck.ui.chat

import android.os.Bundle
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.ai.AiReportSender
import com.silveriron.crosscheck.model.ChatMessage
import com.silveriron.crosscheck.model.NewsItem
import com.silveriron.crosscheck.ui.common.FontBarView
import com.silveriron.crosscheck.ui.common.HardwareHangulInput

/**
 * AI 돋보기 화면 — 지금 보고 있는 기사에 대해 생성형 AI(Gemini)에게 물어봐요.
 * 대화 상태는 ChatViewModel(MainActivity 범위)이 갖고 있어서 탭을 옮겨도 유지돼요.
 */
class ChatFragment : Fragment(R.layout.fragment_chat) {

    private val prompts = listOf("3줄 요약", "어려운 단어 설명", "왜 중요한가요?")

    private lateinit var chatViewModel: ChatViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel
        chatViewModel = ViewModelProvider(activity)[ChatViewModel::class.java]

        // 시각 비교 기사 또는 방금 본 실시간 기사(속보·최신 뉴스)
        val article = appViewModel.chatArticle()
        chatViewModel.bindArticle(article)

        // 실시간 기사에서 왔으면 그 기사로, 아니면 시각 비교 화면으로 돌아가요.
        view.findViewById<View>(R.id.btnBack).setOnClickListener { activity.goBack() }
        view.findViewById<FontBarView>(R.id.fontBar).connect(viewLifecycleOwner, appViewModel)

        view.findViewById<TextView>(R.id.chatArticleTitle).text =
            getString(R.string.chat_article_context, article.title)
        view.findViewById<TextView>(R.id.chatSubtitle).setText(
            if (chatViewModel.isAiConfigured) R.string.chat_subtitle else R.string.chat_subtitle_offline
        )

        val recycler = view.findViewById<RecyclerView>(R.id.messageRecycler)
        recycler.layoutManager = LinearLayoutManager(requireContext()).apply { stackFromEnd = true }
        val adapter = ChatAdapter { message -> showReportDialog(article, message) }
        recycler.adapter = adapter

        val input = view.findViewById<EditText>(R.id.messageInput)
        // 컴퓨터 키보드로도 한글이 입력되게 해요 (전시장 에뮬레이터용). 휴대폰 화면 키보드는 그대로예요.
        val hangul = HardwareHangulInput(input, view.findViewById(R.id.btnLangToggle))
        hangul.attach()   // 컴퓨터 키보드가 연결돼 있으면 처음부터 한글 모드
        val btnSend = view.findViewById<View>(R.id.btnSend)

        val chipsContainer = view.findViewById<LinearLayout>(R.id.promptChips)
        val chips = prompts.map { label ->
            val chip = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_prompt_chip, chipsContainer, false) as TextView
            chip.text = label
            chip.setOnClickListener { chatViewModel.send(label) }
            chipsContainer.addView(chip)
            chip
        }

        fun submitInput() {
            hangul.commit()   // 조합 중인 글자까지 확정한 뒤 보내요
            if (chatViewModel.send(input.text.toString())) {
                input.text.clear()
                hangul.reset()
            }
        }
        btnSend.setOnClickListener { submitInput() }
        input.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEND || isEnter) {
                submitInput()
                true
            } else {
                false
            }
        }

        chatViewModel.messages.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            if (list.isNotEmpty()) recycler.scrollToPosition(list.size - 1)
        }
        // 답변을 기다리는 동안에는 보내기 버튼과 질문 칩을 잠시 흐리게 막아 둬요.
        chatViewModel.isWaiting.observe(viewLifecycleOwner) { waiting ->
            btnSend.isEnabled = !waiting
            btnSend.alpha = if (waiting) 0.4f else 1f
            chips.forEach { chip ->
                chip.isEnabled = !waiting
                chip.alpha = if (waiting) 0.5f else 1f
            }
        }
    }

    /** 플레이스토어 생성형 AI 정책: 앱을 벗어나지 않고 AI 답변을 신고할 수 있어야 해요. */
    private fun showReportDialog(article: NewsItem, message: ChatMessage) {
        val reasons = resources.getStringArray(R.array.report_reasons)
        var selected = 0
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.report_title)
            .setSingleChoiceItems(reasons, selected) { _, which -> selected = which }
            .setPositiveButton(R.string.report_submit) { _, _ ->
                val context = context ?: return@setPositiveButton
                AiReportSender.submit(
                    context = context,
                    articleTitle = article.title,
                    question = chatViewModel.questionBefore(message),
                    answer = message.text,
                    reason = reasons[selected]
                )
                Toast.makeText(context, R.string.report_done, Toast.LENGTH_LONG).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
