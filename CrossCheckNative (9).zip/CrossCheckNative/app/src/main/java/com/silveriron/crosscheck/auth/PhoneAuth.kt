package com.silveriron.crosscheck.auth

import java.security.SecureRandom

/** 휴대폰 번호 확인·표시 (안드로이드와 상관없는 순수 로직이라 따로 테스트할 수 있어요) */
object PhoneNumbers {

    private val MOBILE = Regex("^01[016789]\\d{7,8}$")

    fun digitsOnly(raw: String): String = raw.filter { it.isDigit() }

    /** 010·011·016·017·018·019로 시작하는 10~11자리 휴대폰 번호인지 */
    fun isValidMobile(raw: String): Boolean = MOBILE.matches(digitsOnly(raw))

    /** 01012345678 → 010-1234-5678 / 0111234567 → 011-123-4567 */
    fun format(raw: String): String {
        val d = digitsOnly(raw)
        return when (d.length) {
            11 -> "${d.substring(0, 3)}-${d.substring(3, 7)}-${d.substring(7)}"
            10 -> "${d.substring(0, 3)}-${d.substring(3, 6)}-${d.substring(6)}"
            else -> d
        }
    }

    /** 입력하는 도중에도 하이픈을 넣어요: 0101 → 010-1, 01012345 → 010-1234-5 */
    fun formatPartial(raw: String): String {
        val d = digitsOnly(raw).take(11)
        return when {
            d.length <= 3 -> d
            d.length <= 7 -> "${d.substring(0, 3)}-${d.substring(3)}"
            d.length == 10 && !d.startsWith("010") -> "${d.substring(0, 3)}-${d.substring(3, 6)}-${d.substring(6)}"
            else -> "${d.substring(0, 3)}-${d.substring(3, 7)}-${d.substring(7)}"
        }
    }

    /** 가운데를 가린 번호: 010-****-5678 (저장·표시에는 이것만 써요) */
    fun mask(raw: String): String {
        val d = digitsOnly(raw)
        if (d.length < 10) return d
        val middle = "*".repeat(d.length - 7)
        return "${d.substring(0, 3)}-$middle-${d.substring(d.length - 4)}"
    }
}

/**
 * 문자 인증번호 (전시용 데모).
 *
 * 실제 문자 발송에는 서버와 문자 발송 서비스가 필요해서, 전시용에서는 인증번호를 앱이 만들어
 * 화면에 '문자처럼' 보여주고 자동으로 입력해 줘요. 기획서대로 유효 시간 3분, 5번 틀리면 다시 받기.
 * 서버가 생기면 issue()는 서버의 /auth/phone/request-otp 호출로, verify()는 /auth/phone/verify-otp로
 * 바꾸면 되고, 화면 코드는 그대로 둘 수 있어요.
 */
class OtpSession(
    private val now: () -> Long = { System.currentTimeMillis() },
    private val random: java.util.Random = SecureRandom()
) {
    enum class Result { OK, WRONG, EXPIRED, TOO_MANY, NOT_ISSUED }

    var code: String? = null
        private set
    private var issuedAt = 0L
    private var attempts = 0

    fun issue(): String {
        val newCode = random.nextInt(1_000_000).toString().padStart(CODE_LENGTH, '0')
        code = newCode
        issuedAt = now()
        attempts = 0
        return newCode
    }

    fun remainingMs(): Long = if (code == null) 0L else (TTL_MS - (now() - issuedAt)).coerceAtLeast(0L)

    fun verify(input: String): Result {
        val expected = code ?: return Result.NOT_ISSUED
        if (remainingMs() <= 0L) return Result.EXPIRED
        if (attempts >= MAX_ATTEMPTS) return Result.TOO_MANY
        attempts++
        if (input.filter { it.isDigit() } == expected) {
            code = null // 한 번 쓴 인증번호는 다시 못 쓰게
            return Result.OK
        }
        return if (attempts >= MAX_ATTEMPTS) Result.TOO_MANY else Result.WRONG
    }

    fun reset() {
        code = null
        attempts = 0
    }

    companion object {
        const val CODE_LENGTH = 6
        const val TTL_MS = 3 * 60 * 1000L
        const val MAX_ATTEMPTS = 5

        /** 남은 시간 표시: 2:59 */
        fun formatRemaining(ms: Long): String {
            val totalSeconds = (ms + 999) / 1000
            return "${totalSeconds / 60}:${(totalSeconds % 60).toString().padStart(2, '0')}"
        }
    }
}
