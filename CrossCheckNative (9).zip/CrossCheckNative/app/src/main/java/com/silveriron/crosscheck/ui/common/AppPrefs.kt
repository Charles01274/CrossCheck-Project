package com.silveriron.crosscheck.ui.common

import android.content.Context
import android.content.SharedPreferences

/**
 * 앱 설정(글씨 크기 단계, 고대비 모드)을 휴대폰에 저장해요.
 * 앱을 껐다 켜도 사용자가 고른 설정이 그대로 유지돼요.
 */
object AppPrefs {
    private const val PREFS_NAME = "crosscheck_prefs"
    private const val KEY_LEVEL = "font_level"
    private const val KEY_HIGH_CONTRAST = "high_contrast"

    const val MIN_LEVEL = 1
    const val MAX_LEVEL = 3

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getLevel(context: Context): Int =
        prefs(context).getInt(KEY_LEVEL, MIN_LEVEL).coerceIn(MIN_LEVEL, MAX_LEVEL)

    fun setLevel(context: Context, level: Int) {
        prefs(context).edit().putInt(KEY_LEVEL, level.coerceIn(MIN_LEVEL, MAX_LEVEL)).apply()
    }

    fun isHighContrast(context: Context): Boolean =
        prefs(context).getBoolean(KEY_HIGH_CONTRAST, false)

    fun setHighContrast(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_HIGH_CONTRAST, enabled).apply()
    }

    /** theme.ts LEVEL_SIZE 비율(16 / 19 / 22sp)을 배율로 바꾼 값이에요. */
    fun scaleForLevel(level: Int): Float = when (level) {
        1 -> 1.0f
        2 -> 1.1875f
        else -> 1.375f
    }

    /**
     * 휴대폰 설정에서 이미 글씨를 키운 사용자가 앱에서 오히려 작아 보이지 않도록,
     * 휴대폰 글씨 배율 × 앱 글씨 단계 배율로 계산해요. (너무 커져 화면이 깨지지 않게 2배로 제한)
     */
    fun effectiveFontScale(systemFontScale: Float, level: Int): Float =
        (systemFontScale * scaleForLevel(level)).coerceAtMost(2.0f)
}
