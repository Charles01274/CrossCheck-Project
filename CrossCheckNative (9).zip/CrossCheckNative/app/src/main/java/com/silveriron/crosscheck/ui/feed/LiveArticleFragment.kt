package com.silveriron.crosscheck.ui.feed

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.RecyclerView
import com.silveriron.crosscheck.MainActivity
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.news.NewsText
import com.silveriron.crosscheck.ui.common.FontBarView
import com.silveriron.crosscheck.ui.common.RelatedLink
import com.silveriron.crosscheck.ui.common.RelatedVideoSection
import com.silveriron.crosscheck.ui.common.openWebPage

/**
 * 속보·최신 뉴스를 눌렀을 때 나오는 화면.
 *  - 제목·요약·언론사 (네이버 뉴스 검색 결과)
 *  - 원문 기사로 연결
 *  - AI 돋보기에게 이 기사에 대해 묻기
 *  - 관련 유튜브 영상으로 연결 (하이퍼링크 시스템)
 */
class LiveArticleFragment : Fragment(R.layout.fragment_live_article) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val activity = requireActivity() as MainActivity
        val appViewModel = activity.appViewModel

        val article = appViewModel.selectedLive
        if (article == null) {
            // 앱이 오래 백그라운드에 있다가 다시 열리면 선택 정보가 사라질 수 있어요 → 뉴스 목록으로
            view.post { if (isAdded) activity.navigateTo(MainActivity.Screen.FEED) }
            return
        }

        view.findViewById<View>(R.id.btnBack).setOnClickListener { activity.goBack() }
        view.findViewById<FontBarView>(R.id.fontBar).connect(viewLifecycleOwner, appViewModel)

        val now = System.currentTimeMillis()
        view.findViewById<View>(R.id.liveBreakingBadge).visibility =
            if (article.isBreaking) View.VISIBLE else View.GONE
        view.findViewById<TextView>(R.id.liveMeta).text = listOf(
            if (article.isBreaking) null else article.category,
            NewsText.timeAgo(article.publishedAt, now),
            article.source
        ).filterNotNull().joinToString(" · ")
        view.findViewById<TextView>(R.id.liveTitle).text = article.title
        view.findViewById<TextView>(R.id.liveSummary).text =
            article.summary.ifBlank { getString(R.string.live_no_summary) }

        view.findViewById<TextView>(R.id.btnOpenOriginalText).text =
            getString(R.string.open_original_from, article.source)
        view.findViewById<View>(R.id.btnOpenOriginal).setOnClickListener {
            openWebPage(it.context, article.bestLink)
        }

        view.findViewById<View>(R.id.btnAskAi).setOnClickListener {
            appViewModel.useLiveForChat()
            activity.navigateTo(MainActivity.Screen.CHAT)
        }

        // 관련 유튜브 영상
        val query = NewsText.searchQueryFor(article.title)
        RelatedVideoSection(
            fragment = this,
            recycler = view.findViewById<RecyclerView>(R.id.videoRecycler),
            status = view.findViewById(R.id.relatedVideosHint)
        ).load(
            query = query,
            curated = emptyList(),
            fallback = listOf(
                RelatedLink.Search(
                    title = getString(R.string.search_youtube_for, article.title),
                    label = getString(R.string.video_badge_search),
                    query = query,
                    thumbUrl = ""
                )
            )
        )
    }
}
