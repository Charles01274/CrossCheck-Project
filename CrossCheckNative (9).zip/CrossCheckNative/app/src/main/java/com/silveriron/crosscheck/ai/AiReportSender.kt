package com.silveriron.crosscheck.ai

import android.content.Context
import android.util.Log
import com.silveriron.crosscheck.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * AI 답변 신고 처리.
 *
 * 구글 플레이 정책상 생성형 AI 앱은 "앱을 벗어나지 않고" 불쾌하거나 잘못된 AI 답변을
 * 개발자에게 신고할 수 있는 기능이 반드시 있어야 해요.
 *
 *  1) 신고 내용을 먼저 휴대폰에 저장하고 (인터넷이 끊겨도 사라지지 않게)
 *  2) local.properties의 AI_REPORT_URL로 전송해요. 실패하면 다음 신고 때 다시 보내요.
 *
 * AI_REPORT_URL은 나중에 FastAPI 백엔드의 /ai/report 주소로 바꾸면 되고,
 * 그전까지는 README의 '구글 스프레드시트로 신고 받기' 방법을 쓰면 돼요.
 */
object AiReportSender {

    private const val TAG = "AiReportSender"
    private const val PREFS_NAME = "crosscheck_ai_reports"
    private const val KEY_QUEUE = "pending_reports"
    private const val MAX_QUEUE = 50

    private val executor = Executors.newSingleThreadExecutor()
    private val lock = Any()

    val hasEndpoint: Boolean
        get() = BuildConfig.AI_REPORT_URL.isNotBlank()

    fun submit(
        context: Context,
        articleTitle: String,
        question: String?,
        answer: String,
        reason: String
    ) {
        val appContext = context.applicationContext
        val report = JSONObject()
            .put("app", "CrossCheck")
            .put("appVersion", BuildConfig.VERSION_NAME)
            .put("model", BuildConfig.GEMINI_MODEL)
            .put("reason", reason)
            .put("article", articleTitle)
            .put("question", question.orEmpty())
            .put("answer", answer)
            .put("reportedAt", timestamp())

        executor.execute {
            synchronized(lock) {
                val queue = load(appContext)
                queue.put(report)
                save(appContext, keepLatest(queue))
                flush(appContext)
            }
        }
    }

    private fun flush(context: Context) {
        val endpoint = BuildConfig.AI_REPORT_URL
        if (endpoint.isBlank()) return

        val queue = load(context)
        val remaining = JSONArray()
        for (i in 0 until queue.length()) {
            val item = queue.optJSONObject(i) ?: continue
            if (!post(endpoint, item)) remaining.put(item)
        }
        save(context, remaining)
    }

    private fun post(endpoint: String, body: JSONObject): Boolean = try {
        val conn = URL(endpoint).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 15_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            // 구글 Apps Script는 처리 후 302로 응답하므로 3xx도 성공으로 봐요.
            conn.responseCode in 200..399
        } finally {
            conn.disconnect()
        }
    } catch (e: Exception) {
        Log.w(TAG, "Report upload failed; will retry next time", e)
        false
    }

    private fun load(context: Context): JSONArray {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_QUEUE, null)
        return try {
            if (raw.isNullOrBlank()) JSONArray() else JSONArray(raw)
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun save(context: Context, queue: JSONArray) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_QUEUE, queue.toString())
            .apply()
    }

    private fun keepLatest(queue: JSONArray): JSONArray {
        if (queue.length() <= MAX_QUEUE) return queue
        val trimmed = JSONArray()
        for (i in queue.length() - MAX_QUEUE until queue.length()) trimmed.put(queue.get(i))
        return trimmed
    }

    private fun timestamp(): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date())
}
