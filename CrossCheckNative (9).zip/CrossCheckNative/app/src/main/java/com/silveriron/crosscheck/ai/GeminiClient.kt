package com.silveriron.crosscheck.ai

import android.util.Log
import com.silveriron.crosscheck.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Google Gemini API(생성형 AI)를 호출하는 클라이언트예요.
 *
 * - 추가 라이브러리 없이 안드로이드 기본 HttpURLConnection + org.json만 써요.
 * - 공식 REST 엔드포인트 `models/{모델}:generateContent`를 사용해요.
 * - 키와 모델 이름은 local.properties → BuildConfig로 들어와요 (코드에 키를 적지 않아요).
 *
 * ⚠️ 네트워크를 쓰기 때문에 반드시 백그라운드 스레드에서 generate()를 호출해야 해요.
 *
 * 나중에 FastAPI 백엔드(/ai/chat)가 생기면 이 클래스만 백엔드 호출로 바꾸면 되고,
 * 화면 코드는 그대로 둘 수 있어요.
 */
class GeminiClient(
    private val apiKey: String = BuildConfig.GEMINI_API_KEY,
    model: String = BuildConfig.GEMINI_MODEL
) {
    private val model: String = model.ifBlank { DEFAULT_MODEL }

    val isConfigured: Boolean
        get() = apiKey.isNotBlank()

    sealed class Result {
        data class Success(val text: String) : Result()
        data class Failure(val reason: Reason, val detail: String = "") : Result()
    }

    enum class Reason {
        NOT_CONFIGURED, // 키가 없음
        NETWORK,        // 인터넷 연결 문제·시간 초과
        QUOTA,          // 사용량 한도 초과 (429)
        AUTH,           // 키가 잘못됐거나 권한 없음
        BAD_REQUEST,    // 모델 이름 오류 등 요청 문제
        BLOCKED,        // 안전 정책으로 답변이 차단됨
        SERVER,         // 구글 서버 문제
        EMPTY           // 응답은 왔지만 글자가 비어 있음
    }

    fun generate(systemInstruction: String, userText: String): Result {
        if (!isConfigured) return Result.Failure(Reason.NOT_CONFIGURED)

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", textParts(systemInstruction)))
            .put(
                "contents",
                JSONArray().put(JSONObject().put("role", "user").put("parts", textParts(userText)))
            )

        var connection: HttpURLConnection? = null
        return try {
            val conn = URL("$BASE_URL/models/$model:generateContent").openConnection() as HttpURLConnection
            connection = conn
            conn.requestMethod = "POST"
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = READ_TIMEOUT_MS
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey)

            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (code in 200..299) {
                parseSuccess(raw)
            } else {
                val message = errorMessage(raw)
                Log.w(TAG, "Gemini HTTP $code: $message")
                Result.Failure(reasonFor(code, message), "HTTP $code $message")
            }
        } catch (e: IOException) {
            Log.w(TAG, "Gemini network error", e)
            Result.Failure(Reason.NETWORK, e.javaClass.simpleName)
        } catch (e: Exception) {
            Log.w(TAG, "Gemini unexpected error", e)
            Result.Failure(Reason.SERVER, e.javaClass.simpleName)
        } finally {
            connection?.disconnect()
        }
    }

    private fun textParts(text: String): JSONArray =
        JSONArray().put(JSONObject().put("text", text))

    private fun parseSuccess(raw: String): Result {
        val json = JSONObject(raw)

        val feedback = json.optJSONObject("promptFeedback")
        if (feedback != null && feedback.has("blockReason")) {
            return Result.Failure(Reason.BLOCKED, feedback.optString("blockReason"))
        }

        val candidates = json.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) return Result.Failure(Reason.EMPTY)

        val first = candidates.optJSONObject(0) ?: return Result.Failure(Reason.EMPTY)
        val parts = first.optJSONObject("content")?.optJSONArray("parts")
        val builder = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue // 모델의 '생각' 요약은 화면에 보이지 않게
                builder.append(part.optString("text", ""))
            }
        }

        val text = cleanup(builder.toString())
        if (text.isBlank()) {
            val finish = first.optString("finishReason", "")
            val blocked = finish in setOf("SAFETY", "PROHIBITED_CONTENT", "BLOCKLIST", "SPII", "RECITATION")
            return Result.Failure(if (blocked) Reason.BLOCKED else Reason.EMPTY, finish)
        }
        return Result.Success(text)
    }

    private fun errorMessage(raw: String): String = try {
        JSONObject(raw).optJSONObject("error")?.optString("message", "").orEmpty()
    } catch (e: Exception) {
        raw.take(200)
    }

    private fun reasonFor(code: Int, message: String): Reason = when {
        code == 429 -> Reason.QUOTA
        code == 401 || code == 403 -> Reason.AUTH
        code == 400 && message.contains("API key", ignoreCase = true) -> Reason.AUTH
        code == 400 || code == 404 -> Reason.BAD_REQUEST
        else -> Reason.SERVER
    }

    companion object {
        private const val TAG = "GeminiClient"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

        /** 2026년 10월 기준 구글이 새 프로젝트에 권장하는 빠르고 저렴한 안정(stable) 모델 */
        const val DEFAULT_MODEL = "gemini-3.5-flash-lite"

        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 60_000

        /**
         * 말풍선은 일반 글자라서, AI가 습관처럼 쓰는 마크다운 기호(**, #, *)를 정리해요.
         */
        fun cleanup(text: String): String =
            text.replace("**", "")
                .replace("__", "")
                .lines()
                .joinToString("\n") { line ->
                    val trimmed = line.trim()
                    when {
                        trimmed.startsWith("#") -> trimmed.trimStart('#').trim()
                        trimmed.startsWith("* ") -> "· " + trimmed.removePrefix("* ")
                        trimmed.startsWith("- ") -> "· " + trimmed.removePrefix("- ")
                        else -> line.trimEnd()
                    }
                }
                .trim()
    }
}
