package com.silveriron.crosscheck.ui.common

import android.net.Uri
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.model.GlideUrl
import com.bumptech.glide.load.model.LazyHeaders
import com.silveriron.crosscheck.model.NewsItem

/**
 * 기사 사진 불러오기 — 위키미디어 공용(Wikimedia Commons)의 자유 이용 실제 사진.
 *  1) 처음 한 번 인터넷에서 받아 휴대폰에 저장(캐시)해요 → 그 뒤로는 인터넷이 없어도 보여요.
 *  2) 받는 동안이나 실패하면 앱에 들어 있는 지도 그래픽을 대신 보여줘요 → 빈칸·깨진 그림이 없어요.
 *  3) 위키미디어 이용 규칙에 따라 앱 이름을 밝히는 User-Agent를 보내요.
 */
object NewsPhotos {
    private const val USER_AGENT = "CrossCheck/1.0 (Android news app; graduation exhibition)"

    fun url(fileName: String, width: Int): String =
        "https://commons.wikimedia.org/wiki/Special:FilePath/" + Uri.encode(fileName) + "?width=" + width

    /** @param square 목록의 정사각형 썸네일이면 true (작은 크기로 받아요) */
    fun load(target: ImageView, item: NewsItem, square: Boolean = false) {
        val fallback = if (square) item.thumbRes else item.imageRes
        if (item.photoFile.isBlank()) {
            Glide.with(target).load(fallback).centerCrop().into(target)
            return
        }
        val model = GlideUrl(
            url(item.photoFile, if (square) 500 else 1280),
            LazyHeaders.Builder().addHeader("User-Agent", USER_AGENT).build()
        )
        Glide.with(target).load(model).centerCrop().placeholder(fallback).error(fallback).into(target)
    }
}
