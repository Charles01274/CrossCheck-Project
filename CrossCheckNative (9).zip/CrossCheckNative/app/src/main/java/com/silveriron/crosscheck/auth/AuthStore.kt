package com.silveriron.crosscheck.auth

import android.content.Context

enum class LoginType { KAKAO, PHONE }

/** 로그인한 사람의 정보 — 꼭 필요한 것만, 이 휴대폰 안에만 저장해요. */
data class AuthSession(
    val type: LoginType,
    val displayName: String,   // 카카오 닉네임, 또는 가운데를 가린 전화번호(010-****-5678)
    val loggedInAt: Long
)

/**
 * 로그인 상태 저장소.
 *  - 한 번 로그인하면 정보를 저장해 두고, 다음에 앱을 열면 로그인 화면 없이 바로 들어가요 (자동 로그인).
 *  - 전화번호는 가운데를 가린 형태로만 저장해요. 전체 번호는 남기지 않아요.
 *  - '로그인 없이 둘러보기'는 저장하지 않아서, 다음에 열면 다시 로그인 화면이 나와요.
 */
object AuthStore {
    private const val PREFS = "crosscheck_auth"
    private const val KEY_TYPE = "type"
    private const val KEY_NAME = "display_name"
    private const val KEY_AT = "logged_in_at"

    /** 로그인 없이 둘러보는 중인지 (앱을 완전히 끄면 사라져요) */
    @Volatile
    var guestMode: Boolean = false

    fun current(context: Context): AuthSession? {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val type = prefs.getString(KEY_TYPE, null)?.let { name ->
            LoginType.entries.firstOrNull { it.name == name }
        } ?: return null
        val name = prefs.getString(KEY_NAME, null) ?: return null
        return AuthSession(type, name, prefs.getLong(KEY_AT, 0L))
    }

    fun save(context: Context, session: AuthSession) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_TYPE, session.type.name)
            .putString(KEY_NAME, session.displayName)
            .putLong(KEY_AT, session.loggedInAt)
            .apply()
        guestMode = false
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        guestMode = false
    }

    /** 로그인했거나, 둘러보기 중이면 앱을 쓸 수 있어요. */
    fun hasAccess(context: Context): Boolean = guestMode || current(context) != null
}
