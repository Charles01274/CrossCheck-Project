package com.silveriron.crosscheck.ui.chat

import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.silveriron.crosscheck.R
import com.silveriron.crosscheck.model.ChatMessage

/**
 * 채팅 말풍선 목록.
 *  - 사용자 말풍선 / AI 말풍선 두 종류
 *  - 생성형 AI가 만든 답변에만 'AI가 만든 답변' 표시와 [신고] 버튼을 보여줘요
 *  - '답변을 준비하고 있어요…'는 흐린 기울임 글씨로 보여줘요
 */
class ChatAdapter(
    private val onReport: (ChatMessage) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var items: List<ChatMessage> = emptyList()

    fun submitList(list: List<ChatMessage>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int) = if (items[position].isUser) TYPE_USER else TYPE_AI

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_USER) {
            UserHolder(inflater.inflate(R.layout.item_chat_user, parent, false))
        } else {
            AiHolder(inflater.inflate(R.layout.item_chat_ai, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = items[position]
        when (holder) {
            is UserHolder -> holder.bind(message)
            is AiHolder -> holder.bind(message, onReport)
        }
    }

    class UserHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val text: TextView = view.findViewById(R.id.bubbleText)

        fun bind(message: ChatMessage) {
            text.text = message.text
        }
    }

    class AiHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val text: TextView = view.findViewById(R.id.bubbleText)
        private val metaRow: View = view.findViewById(R.id.metaRow)
        private val btnReport: View = view.findViewById(R.id.btnReport)

        fun bind(message: ChatMessage, onReport: (ChatMessage) -> Unit) {
            val context = itemView.context
            text.text = message.text
            text.setTextColor(
                context.resources.getColor(if (message.isTyping) R.color.faint else R.color.ink, context.theme)
            )
            text.setTypeface(null, if (message.isTyping) Typeface.ITALIC else Typeface.NORMAL)

            metaRow.visibility = if (message.isGenerated) View.VISIBLE else View.GONE
            btnReport.setOnClickListener { onReport(message) }
        }
    }

    companion object {
        private const val TYPE_USER = 0
        private const val TYPE_AI = 1
    }
}
