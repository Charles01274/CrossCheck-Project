package com.silveriron.crosscheck.news

import java.net.URI
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** 뉴스 글자 정리·속보 판별·날짜 해석 (네트워크와 무관해서 단독으로 테스트할 수 있어요) */
object NewsText {

    private val TAG = Regex("<[^>]*>")
    private val NUMERIC_ENTITY = Regex("&#([xX]?[0-9a-fA-F]+);")
    private val SPACES = Regex("\\s+")

    /** [속보] <속보> (속보) 【속보】 [긴급] [1보] 같은 표시 */
    private val BREAKING_MARKER = Regex("[\\[<(【]\\s*(속보|긴급|\\d+\\s*보)\\s*[\\]>)】]")

    /** 제목 맨 앞의 '속보 ' / '속보: ' 형태 */
    private val LEADING_BREAKING = Regex("^\\s*속보\\s*[:：·)\\-]?\\s+")

    private val SEOUL: TimeZone = TimeZone.getTimeZone("Asia/Seoul")

    /** HTML 태그(<b> 등)를 지우고 &quot; 같은 기호를 원래 글자로 바꿔요. */
    fun stripHtml(raw: String): String {
        var text = TAG.replace(raw, "")
        text = NUMERIC_ENTITY.replace(text) { m ->
            val v = m.groupValues[1]
            val code = if (v.startsWith("x") || v.startsWith("X")) v.substring(1).toIntOrNull(16) else v.toIntOrNull()
            if (code != null && code in 1..0x10FFFF) String(Character.toChars(code)) else m.value
        }
        text = text
            .replace("&quot;", "\"").replace("&apos;", "'")
            .replace("&lt;", "<").replace("&gt;", ">")
            .replace("&nbsp;", " ").replace("&middot;", "·").replace("&hellip;", "…")
            .replace("&lsquo;", "‘").replace("&rsquo;", "’")
            .replace("&ldquo;", "“").replace("&rdquo;", "”")
            .replace("&amp;", "&") // 반드시 마지막에
        return SPACES.replace(text, " ").trim()
    }

    fun isBreaking(title: String): Boolean =
        BREAKING_MARKER.containsMatchIn(title) || LEADING_BREAKING.containsMatchIn(title)

    /** 화면에는 '속보' 빨간 표시를 따로 보여주므로 제목 속 표시는 지워요. */
    fun cleanTitle(title: String): String {
        val withoutMarkers = LEADING_BREAKING.replace(BREAKING_MARKER.replace(title, " "), "")
        return SPACES.replace(withoutMarkers, " ").trim()
    }

    /** 유튜브 검색어: 따옴표·괄호 기호를 빼고 너무 길면 줄여요. */
    fun searchQueryFor(title: String): String {
        val cleaned = cleanTitle(title).replace(Regex("[\"“”‘’'\\[\\]<>()【】…]"), " ")
        return SPACES.replace(cleaned, " ").trim().take(60)
    }

    /** 맨 앞의 요일("Wed, ")은 버려요. 요일이 실제 날짜와 다르게 적힌 기사도 날짜를 놓치지 않게요. */
    private val LEADING_WEEKDAY = Regex("^[A-Za-z]{3,9},\\s*")

    private val DATE_PATTERNS = listOf(
        "d MMM yyyy HH:mm:ss Z",
        "d MMM yyyy HH:mm:ss zzz",
        "d MMM yyyy HH:mm Z",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy.MM.dd HH:mm"
    )

    /**
     * 네이버(RFC 822, 예: "Thu, 15 Oct 2026 14:30:00 +0900") 등 여러 날짜 표기를 읽어요.
     * 날짜를 못 읽으면 속보 '최신순' 정렬이 틀어지므로, 요일 표기 오류에도 견디게 했어요.
     */
    fun parseDate(raw: String?): Long? {
        val text = LEADING_WEEKDAY.replace(raw?.trim().orEmpty(), "")
        if (text.isEmpty()) return null
        for (pattern in DATE_PATTERNS) {
            try {
                val format = SimpleDateFormat(pattern, Locale.ENGLISH)
                format.isLenient = false
                if (!pattern.contains('Z') && !pattern.contains('X') && !pattern.contains('z')) format.timeZone = SEOUL
                val date = format.parse(text) ?: continue
                return date.time
            } catch (e: Exception) {
                // 다음 형식으로 다시 시도
            }
        }
        return null
    }

    private val OUTLETS = linkedMapOf(
        "yonhapnewstv.co.kr" to "연합뉴스TV", "yna.co.kr" to "연합뉴스", "hani.co.kr" to "한겨레",
        "khan.co.kr" to "경향신문", "chosun.com" to "조선일보", "donga.com" to "동아일보",
        "joongang.co.kr" to "중앙일보", "hankookilbo.com" to "한국일보", "seoul.co.kr" to "서울신문",
        "segye.com" to "세계일보", "kmib.co.kr" to "국민일보", "munhwa.com" to "문화일보",
        "kbs.co.kr" to "KBS", "imbc.com" to "MBC", "sbs.co.kr" to "SBS", "jtbc.co.kr" to "JTBC",
        "ytn.co.kr" to "YTN", "ichannela.com" to "채널A", "tvchosun.com" to "TV조선", "mbn.co.kr" to "MBN",
        "newsis.com" to "뉴시스", "news1.kr" to "뉴스1", "nocutnews.co.kr" to "노컷뉴스",
        "ohmynews.com" to "오마이뉴스", "pressian.com" to "프레시안", "mk.co.kr" to "매일경제",
        "hankyung.com" to "한국경제", "sedaily.com" to "서울경제", "mt.co.kr" to "머니투데이",
        "edaily.co.kr" to "이데일리", "fnnews.com" to "파이낸셜뉴스", "asiae.co.kr" to "아시아경제",
        "heraldcorp.com" to "헤럴드경제", "news.naver.com" to "네이버뉴스"
    )

    /** 기사 주소로 언론사 이름을 알아내요. 모르는 곳이면 주소(도메인)를 그대로 보여줘요. */
    fun outletName(url: String): String {
        val host = try {
            URI(url.trim()).host.orEmpty().lowercase()
        } catch (e: Exception) {
            ""
        }.removePrefix("www.").removePrefix("m.")
        if (host.isEmpty()) return "언론사"
        return OUTLETS.entries.firstOrNull { (domain, _) -> host == domain || host.endsWith(".$domain") }?.value ?: host
    }

    /** 같은 기사를 한 번만 보여주기 위한 고정 id */
    fun stableId(link: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(link.trim().lowercase().toByteArray(Charsets.UTF_8))
        return digest.take(8).joinToString("") { "%02x".format(it) }
    }

    /** "방금 전", "15분 전", "3시간 전", "10월 14일 18:20" */
    fun timeAgo(publishedAt: Long, now: Long): String {
        val diff = now - publishedAt
        return when {
            diff < 60_000L -> "방금 전"
            diff < 3_600_000L -> "${diff / 60_000L}분 전"
            diff < 86_400_000L -> "${diff / 3_600_000L}시간 전"
            else -> SimpleDateFormat("M월 d일 HH:mm", Locale.KOREA).format(Date(publishedAt))
        }
    }
}
