package com.silveriron.crosscheck.ui.common

import android.content.Context
import android.content.res.Configuration
import android.text.Editable
import android.text.InputType
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.UnderlineSpan
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.TextView
import com.silveriron.crosscheck.R

/**
 * 컴퓨터(실물) 키보드로 한글을 칠 수 있게 해요 — 전시장 컴퓨터의 에뮬레이터 시연용.
 *
 * [동작 방식] 키 신호를 가로채지 않고, '입력칸에 영문 글자가 들어온 결과'를 보고 한글로 바꿔요.
 * 에뮬레이터에서는 Gboard 같은 입력기가 키 신호를 먼저 가져가는 경우가 있어서, 키 신호 대신
 * 입력칸의 변화를 보는 쪽이 어떤 경로로 글자가 들어오든 항상 동작해요.
 *
 *  - 컴퓨터 키보드가 연결돼 있으면 처음부터 '한글' 모드예요. 입력칸 왼쪽 [한] 버튼으로 바꿔요.
 *  - 한/영 키·Shift+Space·Ctrl+Space가 에뮬레이터에 전달되면 그 키로도 바뀌어요.
 *  - 휴대폰(화면 키보드만 있음)에서는 아무 것도 바꾸지 않아요.
 */
class HardwareHangulInput(
    private val field: EditText,
    private val toggle: TextView?
) : TextWatcher {

    private val engine = HangulTextEngine()
    private val underline = UnderlineSpan()
    private var selfEdit = false
    private var changeStart = 0
    private var changeBefore = 0
    private var changeCount = 0
    private var enabled = false
    private val defaultHint: CharSequence? = field.hint

    var koreanMode = false
        private set

    fun attach() {
        field.addTextChangedListener(this)
        field.setOnKeyListener { _, keyCode, event -> onKey(keyCode, event) }
        toggle?.setOnClickListener { setKorean(!koreanMode) }
        if (hasPhysicalKeyboard(field.context)) enable() else toggle?.visibility = View.GONE
    }

    /** 보내기 전에 조합 중인 글자를 확정해요. */
    fun commit() {
        engine.finish()
        field.text.removeSpan(underline)
    }

    /** 입력칸을 비운 뒤 호출해요. */
    fun reset() = commit()

    private fun enable() {
        if (enabled) return
        enabled = true
        koreanMode = true
        // 입력기의 자동 완성·추천을 꺼서, 입력기가 글자를 붙잡고 있지 않게 해요.
        field.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        toggle?.visibility = View.VISIBLE
        render()
    }

    private fun setKorean(on: Boolean) {
        commit()
        koreanMode = on
        render()
    }

    private fun render() {
        field.hint = if (enabled && koreanMode) field.context.getString(R.string.chat_hint_hangul) else defaultHint
        val t = toggle ?: return
        t.setText(if (koreanMode) R.string.lang_toggle_ko else R.string.lang_toggle_en)
        t.setBackgroundResource(if (koreanMode) R.drawable.bg_circle_primary else R.drawable.bg_pill_outline)
        t.setTextColor(t.resources.getColor(if (koreanMode) R.color.onPrimary else R.color.ink, t.context.theme))
        t.contentDescription = t.context.getString(
            if (koreanMode) R.string.lang_toggle_desc_ko else R.string.lang_toggle_desc_en
        )
    }

    // ── 입력칸 변화 감시 ──────────────────────────────────────

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if (selfEdit) return
        changeStart = start
        changeBefore = before
        changeCount = count
    }

    override fun afterTextChanged(e: Editable) {
        if (selfEdit || !enabled || !koreanMode) return
        val imeWasComposing = BaseInputConnection.getComposingSpanStart(e) >= 0
        selfEdit = true
        val cursor = try {
            engine.afterChange(EditableBuffer(e), changeStart, changeBefore, changeCount)
        } finally {
            selfEdit = false
        }
        e.removeSpan(underline)
        if (engine.isComposing) {
            e.setSpan(underline, engine.compStart, engine.compStart + engine.compLen, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (cursor != null) {
            field.setSelection(cursor.coerceIn(0, e.length))
            if (imeWasComposing) {
                // 입력기가 붙잡고 있던 '조합 중 단어'를 놓게 해서, 다음 글자가 깨끗하게 들어오게 해요.
                BaseInputConnection.removeComposingSpans(e)
                field.context.getSystemService(InputMethodManager::class.java)?.restartInput(field)
            }
        }
    }

    // ── 키 신호 (전달될 때만): 한/영 전환, 키보드가 늦게 연결된 경우 ──────────

    private fun onKey(keyCode: Int, event: KeyEvent): Boolean {
        val device = event.device
        if (!enabled && device != null && !device.isVirtual && device.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC) {
            enable()
        }
        if (enabled && isToggleKey(keyCode, event)) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) setKorean(!koreanMode)
            return true
        }
        return false
    }

    private fun isToggleKey(keyCode: Int, event: KeyEvent): Boolean = when (keyCode) {
        KeyEvent.KEYCODE_LANGUAGE_SWITCH, KeyEvent.KEYCODE_KANA, KeyEvent.KEYCODE_EISU,
        KeyEvent.KEYCODE_HENKAN, KeyEvent.KEYCODE_MUHENKAN, KeyEvent.KEYCODE_KATAKANA_HIRAGANA,
        KeyEvent.KEYCODE_ZENKAKU_HANKAKU, KeyEvent.KEYCODE_ALT_RIGHT -> true   // 한/영 키는 보통 오른쪽 Alt로 들어와요
        KeyEvent.KEYCODE_SPACE -> event.isShiftPressed || event.isCtrlPressed
        else -> false
    }

    private class EditableBuffer(private val e: Editable) : TextBuffer {
        override val length: Int get() = e.length
        override fun substring(start: Int, end: Int): String = e.subSequence(start, end).toString()
        override fun replace(start: Int, end: Int, text: String) {
            e.replace(start, end, text)
        }
    }

    companion object {
        /** 실물 키보드(에뮬레이터라면 컴퓨터 키보드)가 연결돼 있는지 */
        fun hasPhysicalKeyboard(context: Context): Boolean {
            if (context.resources.configuration.keyboard == Configuration.KEYBOARD_QWERTY) return true
            return InputDevice.getDeviceIds().any { id ->
                val d = InputDevice.getDevice(id)
                d != null && !d.isVirtual && d.keyboardType == InputDevice.KEYBOARD_TYPE_ALPHABETIC
            }
        }
    }
}
