package com.silveriron.crosscheck.ui.common

/**
 * 두벌식 한글 조합기 — 컴퓨터 키보드의 영문 키(QWERTY)를 한글 글자로 조합해요.
 *
 * 왜 필요한가요? 전시장에서는 컴퓨터의 에뮬레이터로 앱을 시연하는데, 에뮬레이터는 컴퓨터 키보드를
 * '영문 자판 신호'로만 받아서 윈도우의 한/영 전환이 전달되지 않아요. 그래서 앱이 직접 조합해요.
 *  예) d k s s u d → 안녕,  r k q t d l → 갑시 (받침이 다음 글자로 넘어가요)
 *
 * 안드로이드와 무관한 순수 로직이라 단독으로 테스트할 수 있어요.
 */
class HangulComposer {

    private var cho: Char? = null   // 첫소리
    private var jung: Char? = null  // 가운뎃소리
    private var jong: Char? = null  // 받침

    val isComposing: Boolean
        get() = cho != null || jung != null

    /**
     * 영문 키 하나를 넣어요.
     * @return 이번 입력으로 '완성되어 확정된' 글자 (없으면 빈 문자열). 조합 중인 글자는 [composing].
     *         한글로 바꿀 수 없는 키면 조합 중인 글자를 확정한 뒤 그 키를 그대로 돌려줘요.
     */
    fun input(key: Char): String {
        val jamo = KEYMAP[key] ?: KEYMAP[key.lowercaseChar()] ?: return flush() + key
        return if (jamo in VOWELS) inputVowel(jamo) else inputConsonant(jamo)
    }

    /** 지금 조합 중인 글자 (예: "안", "ㄱ", "ㅘ") */
    fun composing(): String {
        val c = cho
        val v = jung
        return when {
            c != null && v != null -> syllable(c, v, jong).toString()
            c != null -> c.toString()
            v != null -> v.toString()
            else -> ""
        }
    }

    /** 조합 중인 글자를 확정하고 비워요. */
    fun flush(): String {
        val out = composing()
        reset()
        return out
    }

    fun reset() {
        cho = null
        jung = null
        jong = null
    }

    /** 자모 하나만 지워요 (안 → 아 → ㅇ). 지울 게 없으면 false */
    fun backspace(): Boolean {
        when {
            jong != null -> jong = JONG_SPLIT[jong]?.first          // 겹받침은 앞 자음만 남겨요 (값 → 갑)
            jung != null -> jung = VOWEL_SPLIT[jung]?.first          // 겹모음은 앞 모음만 남겨요 (과 → 고)
            cho != null -> cho = null
            else -> return false
        }
        return true
    }

    private fun inputConsonant(c: Char): String {
        val curJung = jung
        val curJong = jong
        return when {
            cho == null && curJung == null -> { cho = c; "" }
            curJung == null || cho == null -> { val out = flush(); cho = c; out }   // 자음만/모음만 있던 글자는 확정
            curJong == null ->
                if (c in JONG_SINGLE) { jong = c; "" } else { val out = flush(); cho = c; out }
            else -> {
                val combined = JONG_COMBO[curJong to c]
                if (combined != null) { jong = combined; "" } else { val out = flush(); cho = c; out }
            }
        }
    }

    private fun inputVowel(v: Char): String {
        val curJung = jung
        val curJong = jong
        return when {
            curJung == null -> { jung = v; "" }                       // 빈 상태 또는 첫소리만 있는 상태
            curJong == null -> {
                val combined = VOWEL_COMBO[curJung to v]
                if (combined != null) { jung = combined; "" } else { val out = flush(); jung = v; out }
            }
            else -> {
                // 받침이 다음 글자의 첫소리로 넘어가요: 값+ㅣ → 갑시, 안+ㅏ → 아나
                val split = JONG_SPLIT[curJong]
                val moving: Char
                if (split != null) {
                    jong = split.first
                    moving = split.second
                } else {
                    jong = null
                    moving = curJong
                }
                val out = flush()
                cho = moving
                jung = v
                out
            }
        }
    }

    companion object {
        private const val CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
        private const val JUNG = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
        private const val JONG = "ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ"   // 앞에 '받침 없음'이 하나 더 있어요
        private val VOWELS = JUNG.toSet()
        private val JONG_SINGLE = "ㄱㄲㄴㄷㄹㅁㅂㅅㅆㅇㅈㅊㅋㅌㅍㅎ".toSet()          // ㄸ ㅃ ㅉ 는 받침이 될 수 없어요

        private val KEYMAP: Map<Char, Char> = mapOf(
            'q' to 'ㅂ', 'w' to 'ㅈ', 'e' to 'ㄷ', 'r' to 'ㄱ', 't' to 'ㅅ', 'y' to 'ㅛ', 'u' to 'ㅕ', 'i' to 'ㅑ', 'o' to 'ㅐ', 'p' to 'ㅔ',
            'a' to 'ㅁ', 's' to 'ㄴ', 'd' to 'ㅇ', 'f' to 'ㄹ', 'g' to 'ㅎ', 'h' to 'ㅗ', 'j' to 'ㅓ', 'k' to 'ㅏ', 'l' to 'ㅣ',
            'z' to 'ㅋ', 'x' to 'ㅌ', 'c' to 'ㅊ', 'v' to 'ㅍ', 'b' to 'ㅠ', 'n' to 'ㅜ', 'm' to 'ㅡ',
            // Shift를 누른 채로: 된소리와 ㅒ ㅖ
            'Q' to 'ㅃ', 'W' to 'ㅉ', 'E' to 'ㄸ', 'R' to 'ㄲ', 'T' to 'ㅆ', 'O' to 'ㅒ', 'P' to 'ㅖ'
        )

        private val VOWEL_COMBO = mapOf(
            ('ㅗ' to 'ㅏ') to 'ㅘ', ('ㅗ' to 'ㅐ') to 'ㅙ', ('ㅗ' to 'ㅣ') to 'ㅚ',
            ('ㅜ' to 'ㅓ') to 'ㅝ', ('ㅜ' to 'ㅔ') to 'ㅞ', ('ㅜ' to 'ㅣ') to 'ㅟ', ('ㅡ' to 'ㅣ') to 'ㅢ'
        )
        private val VOWEL_SPLIT = VOWEL_COMBO.entries.associate { (pair, combined) -> combined to pair }

        private val JONG_COMBO = mapOf(
            ('ㄱ' to 'ㅅ') to 'ㄳ', ('ㄴ' to 'ㅈ') to 'ㄵ', ('ㄴ' to 'ㅎ') to 'ㄶ', ('ㄹ' to 'ㄱ') to 'ㄺ',
            ('ㄹ' to 'ㅁ') to 'ㄻ', ('ㄹ' to 'ㅂ') to 'ㄼ', ('ㄹ' to 'ㅅ') to 'ㄽ', ('ㄹ' to 'ㅌ') to 'ㄾ',
            ('ㄹ' to 'ㅍ') to 'ㄿ', ('ㄹ' to 'ㅎ') to 'ㅀ', ('ㅂ' to 'ㅅ') to 'ㅄ'
        )
        private val JONG_SPLIT = JONG_COMBO.entries.associate { (pair, combined) -> combined to pair }

        /** 첫소리·가운뎃소리·받침 → 완성형 글자 (유니코드 '가'부터 순서대로 배열돼 있어요) */
        private fun syllable(c: Char, v: Char, j: Char?): Char {
            val jongIndex = if (j == null) 0 else JONG.indexOf(j) + 1
            return (0xAC00 + (CHO.indexOf(c) * 21 + JUNG.indexOf(v)) * 28 + jongIndex).toChar()
        }
    }
}
