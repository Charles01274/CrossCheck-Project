package com.silveriron.crosscheck.ui.common

/** 글자 칸을 고치는 최소한의 기능 (안드로이드 입력칸 / 테스트용 StringBuilder 둘 다 연결할 수 있게) */
interface TextBuffer {
    val length: Int
    fun substring(start: Int, end: Int): String
    fun replace(start: Int, end: Int, text: String)
}

/**
 * 입력칸에 '영문 글자가 들어온 결과'를 보고 한글로 바꿔요.
 *
 * 키 신호를 가로채지 않는 이유: 에뮬레이터에서는 Gboard 같은 입력기가 컴퓨터 키보드 신호를 먼저 가져가서,
 * 앱이 키 신호를 못 받는 경우가 있어요. 대신 '입력칸에 글자가 들어온 결과'는 어떤 경로든 반드시 거치므로
 * 여기서 바꾸면 항상 동작해요.
 *  - 한 글자씩 들어오면: 이어서 조합 (d→ㅇ, k→아, s→안)
 *  - 입력기가 단어 전체를 다시 보내면(dk→dks): 그 단어를 처음부터 다시 조합
 *  - 조합 중인 글자를 백스페이스로 지우면: 자모 하나만 지워요 (안 → 아)
 *  - 띄어쓰기·숫자·문장부호·커서 이동: 조합을 끝내요 (이미 보이는 글자는 그대로)
 */
class HangulTextEngine {
    private val composer = HangulComposer()

    /** 조합 중인 글자의 위치 (-1이면 조합 중 아님) */
    var compStart = -1
        private set
    var compLen = 0
        private set

    val isComposing: Boolean
        get() = compStart >= 0 && compLen > 0

    /**
     * 입력칸 글자가 바뀐 직후 호출해요 (안드로이드 TextWatcher의 start/before/count 그대로).
     * @return 한글로 바꿨으면 새 커서 위치, 아무것도 안 했으면 null
     */
    fun afterChange(buf: TextBuffer, start: Int, before: Int, count: Int): Int? {
        // 1) 백스페이스로 조합 중인 글자가 지워짐 → 자모 하나만 지운 것처럼 다시 써 넣어요
        if (count == 0 && before == 1 && compStart >= 0 && compLen == 1 && start == compStart) {
            composer.backspace()
            val comp = composer.composing()
            if (comp.isEmpty()) {
                finish()
                return null
            }
            buf.replace(compStart, compStart, comp)
            compLen = comp.length
            return guard(buf)
        }

        // 2) 영문 글자가 들어옴 → 한글로 조합
        if (count > 0 && start + count <= buf.length) {
            val inserted = buf.substring(start, start + count)
            if (inserted.all { it in 'a'..'z' || it in 'A'..'Z' }) {
                val continuing = compStart >= 0 && before == 0 && start == compStart + compLen
                if (!continuing) {
                    // 새 자리에서 시작하거나, 입력기가 단어 전체를 다시 보낸 경우 → 처음부터 조합
                    composer.reset()
                    compStart = start
                    compLen = 0
                }
                buf.replace(start, start + count, "")
                val committed = StringBuilder()
                for (ch in inserted) committed.append(composer.input(ch))
                val comp = composer.composing()
                buf.replace(compStart, compStart + compLen, committed.toString() + comp)
                compStart += committed.length
                compLen = comp.length
                return guard(buf)
            }
        }

        // 3) 그 밖의 변화 → 조합을 끝내요
        finish()
        return null
    }

    /** 조합을 끝내요 (화면에 보이는 글자는 그대로). 보내기 전, 언어 전환, 입력칸 비울 때 호출. */
    fun finish() {
        composer.reset()
        compStart = -1
        compLen = 0
    }

    /** 글자 수 제한(300자) 등으로 다 들어가지 못했을 때도 위치가 어긋나지 않게 */
    private fun guard(buf: TextBuffer): Int {
        if (compStart < 0) return buf.length
        if (compStart + compLen > buf.length) {
            val end = buf.length
            finish()
            return end
        }
        val cursor = compStart + compLen
        if (compLen == 0) finish()
        return cursor
    }
}
