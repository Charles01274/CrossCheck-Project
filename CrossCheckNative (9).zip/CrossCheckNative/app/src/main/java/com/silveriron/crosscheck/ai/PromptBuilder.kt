package com.silveriron.crosscheck.ai

import com.silveriron.crosscheck.model.ChatMessage
import com.silveriron.crosscheck.model.NewsItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Gemini에게 보낼 지시문(시스템 프롬프트)과 질문을 만들어요.
 *
 * 핵심 원칙: '무엇이든 답하는 AI'가 아니라 **지금 보고 있는 기사를 쉽게 풀어주는 뉴스 도우미**로 동작하게 해요.
 *  1) 기사 정보를 근거로만 답하고, 기사에 없는 숫자·날짜·발언은 지어내지 않기
 *  2) 정치적으로 중립 (CrossCheck의 존재 이유)
 *  3) 뉴스와 무관한 요청은 정중히 사양
 *  4) 시니어 사용자를 위한 짧고 쉬운 존댓말
 */
object PromptBuilder {

    private const val MAX_HISTORY = 8

    fun systemInstruction(article: NewsItem): String {
        val today = SimpleDateFormat("yyyy년 M월 d일 EEEE", Locale.KOREA).format(Date())

        // trimIndent()는 여러 줄 값이 끼어들면 들여쓰기를 못 지우므로 buildString으로 조립해요.
        return buildString {
            appendLine("당신은 뉴스 앱 'CrossCheck'의 'AI 돋보기'입니다. 60대 이상 사용자가 뉴스 기사를 쉽게 이해하도록 돕습니다.")
            appendLine()
            appendLine("[답변 규칙]")
            appendLine("1. 쉬운 우리말 존댓말로 답합니다. 보통 3~5문장으로 짧게 쓰고, 어려운 낱말은 풀어서 설명합니다.")
            appendLine("2. 아래 [기사 정보]를 근거로 답합니다. 기사에 없는 숫자·날짜·인물의 발언은 지어내지 말고, 모르는 내용은 \"기사에서 확인되지 않는 내용이에요\"라고 솔직하게 말합니다.")
            appendLine("3. 정치적으로 중립을 지킵니다. 어느 쪽 입장도 지지하거나 깎아내리지 않고, 두 시각을 공정하게 소개합니다. 사용자가 누가 옳은지 물으면 판단은 사용자께 맡기고 양쪽 근거를 정리해 드립니다.")
            appendLine("4. 뉴스·시사와 관계없는 요청(숙제 대신하기, 코딩, 글 대신 써 주기 등)은 정중히 사양하고, 이 기사에 대해 물어봐 달라고 안내합니다.")
            appendLine("5. 건강·법률·돈 문제처럼 중요한 결정이 걸린 질문에는 일반적인 설명만 하고, 전문가와 상담하시라고 권합니다.")
            appendLine("6. 별표(*), 샵(#), 표 같은 기호를 쓰지 말고 일반 문장으로 씁니다. 순서가 필요하면 ①②③을 씁니다.")
            appendLine("7. 오늘 날짜는 $today 입니다.")
            if (article.isLive) {
                appendLine("8. 이 기사는 제목과 짧은 요약만 있습니다. 그 범위 안에서만 쉽게 풀어 설명하고, 자세한 내용은 '원문 기사 보기'로 확인하시라고 안내합니다. 이 기사에 대한 언론사별 시각 자료는 아직 없습니다.")
            }
            appendLine()
            appendLine("[기사 정보]")
            appendLine("분류: ${article.tag}")
            if (article.sourceName.isNotBlank()) appendLine("언론사: ${article.sourceName}")
            appendLine("제목: ${article.title}")
            if (article.time.isNotBlank() && !article.isLive) appendLine("기사 기준 시점: ${article.time} (그 이후 상황은 모른다고 안내합니다)")
            if (article.summary.isNotBlank()) appendLine("요약: ${article.summary}")
            if (!article.isLive) {
                appendLine("3줄 요약:")
                article.summaryLines.forEachIndexed { i, line -> appendLine("${i + 1}) $line") }
            }
            if (article.whyItMatters.isNotBlank()) appendLine("왜 중요한가: ${article.whyItMatters}")
            if (article.outlook.isNotBlank()) appendLine("앞으로의 흐름: ${article.outlook}")
            if (article.left.label.isNotBlank()) {
                appendLine("[${article.left.label}] ${article.left.headline} ${article.left.body}")
            }
            if (article.right.label.isNotBlank()) {
                appendLine("[${article.right.label}] ${article.right.headline} ${article.right.body}")
            }
            if (article.glossary.isNotEmpty()) {
                appendLine("주요 용어:")
                article.glossary.forEach { appendLine("- ${it.term}: ${it.explanation}") }
            }
        }.trim()
    }

    /**
     * 이전 대화를 글로 함께 보내서 "그럼 그건 왜 그래요?" 같은 이어지는 질문도 이해하게 해요.
     * (매번 하나의 질문으로 보내기 때문에 서버에 대화가 저장되지 않아요.)
     */
    fun userTurn(history: List<ChatMessage>, question: String): String {
        val recent = history.filter { it.includeInHistory }.takeLast(MAX_HISTORY)
        if (recent.isEmpty()) return question

        val transcript = recent.joinToString("\n") { message ->
            val speaker = if (message.isUser) "사용자" else "AI 돋보기"
            "$speaker: ${message.text}"
        }
        return "[지금까지의 대화]\n$transcript\n\n[새 질문]\n$question"
    }
}
