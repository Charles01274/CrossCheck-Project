plugins {
    // AGP 8.11 = 플레이스토어 필수 target API 36을 지원하는 버전 (Gradle 8.13 필요)
    id("com.android.application") version "8.11.1" apply false
    id("org.jetbrains.kotlin.android") version "2.2.21" apply false
}
