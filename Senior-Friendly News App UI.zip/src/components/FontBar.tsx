import type { Palette } from "../theme";

interface Props {
  level: number;                       // 1–3
  setLevel: (n: number) => void;
  highContrast: boolean;
  toggleContrast: () => void;
  c: Palette;
}

// Accessibility bar, fixed top-right on every screen.
//  • 3-step text size (A− / level dots / A+) — discrete 표준·크게·아주 크게
//  • Light / dark mode toggle
// Compact so the stepper and the mode toggle both stay fully visible; the 48px
// tall targets keep the tap area generous for senior users.
export default function FontBar({ level, setLevel, highContrast, toggleContrast, c }: Props) {
  return (
    <div className="flex items-stretch gap-1.5 shrink-0">
      {/* Text-size stepper */}
      <div
        className="flex items-stretch overflow-hidden"
        style={{ borderRadius: "12px", border: `${c.lineWidth} solid ${c.line}`, background: c.bg }}
      >
        <button
          onClick={() => setLevel(level - 1)}
          disabled={level <= 1}
          aria-label="글씨 작게"
          className="flex items-center justify-center transition-opacity"
          style={{ width: "40px", height: "48px", background: "transparent", color: c.ink, opacity: level <= 1 ? 0.3 : 1 }}
        >
          <span style={{ fontWeight: 700, fontSize: "13px", letterSpacing: "-0.3px" }}>A−</span>
        </button>

        {/* Level indicator */}
        <div className="flex items-center justify-center gap-0.5 px-1.5" style={{ borderLeft: `${c.lineWidth} solid ${c.line}`, borderRight: `${c.lineWidth} solid ${c.line}` }}>
          {[1, 2, 3].map((n) => (
            <span
              key={n}
              className="rounded-full"
              style={{ width: "5px", height: n === level ? "11px" : "5px", background: n <= level ? c.ink : c.line, transition: "height 0.15s" }}
            />
          ))}
        </div>

        <button
          onClick={() => setLevel(level + 1)}
          disabled={level >= 3}
          aria-label="글씨 크게"
          className="flex items-center justify-center transition-opacity active:opacity-80"
          style={{ width: "42px", height: "48px", background: c.primary, color: c.onPrimary, opacity: level >= 3 ? 0.4 : 1 }}
        >
          <span style={{ fontWeight: 700, fontSize: "18px", letterSpacing: "-0.3px" }}>A+</span>
        </button>
      </div>

      {/* Light / dark mode toggle */}
      <button
        onClick={toggleContrast}
        aria-pressed={highContrast}
        aria-label={highContrast ? "밝은 화면으로" : "어두운 화면으로"}
        title="화면 밝기"
        className="flex items-center justify-center transition-colors shrink-0"
        style={{
          width: "48px",
          height: "48px",
          borderRadius: "12px",
          border: `${c.lineWidth} solid ${highContrast ? c.primary : c.line}`,
          background: highContrast ? c.primary : c.bg,
          color: highContrast ? c.onPrimary : c.ink,
        }}
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="12" cy="12" r="9" />
          <path d="M12 3a9 9 0 010 18z" fill="currentColor" stroke="none" />
        </svg>
      </button>
    </div>
  );
}
