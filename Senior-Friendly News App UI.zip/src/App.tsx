import { useState } from "react";
import NewsFeedScreen from "./screens/NewsFeedScreen";
import PerspectiveScreen from "./screens/PerspectiveScreen";
import ChatScreen from "./screens/ChatScreen";
import TutorialScreen from "./screens/TutorialScreen";
import { palette, LEVEL_SIZE, SANS } from "./theme";

export type Screen = "feed" | "perspective" | "chat" | "tutorial";

export interface ScreenProps {
  fontSize: number;
  level: number;
  setLevel: (n: number) => void;
  highContrast: boolean;
  toggleContrast: () => void;
  setScreen: (s: Screen) => void;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("feed");
  const [level, setLevelRaw] = useState(1); // 1–3
  const [highContrast, setHighContrast] = useState(false);

  const setLevel = (n: number) => setLevelRaw(Math.min(3, Math.max(1, n)));
  const toggleContrast = () => setHighContrast((v) => !v);
  const fontSize = LEVEL_SIZE[level];
  const c = palette(highContrast);

  const props: ScreenProps = { fontSize, level, setLevel, highContrast, toggleContrast, setScreen };

  return (
    <div
      className="size-full flex items-center justify-center"
      style={{ background: highContrast ? "#000000" : "#E4E4E1", fontFamily: SANS }}
    >
      {/* Phone shell */}
      <div
        className="relative overflow-hidden flex flex-col"
        style={{
          width: "390px",
          height: "844px",
          background: c.bg,
          borderRadius: "44px",
          boxShadow: "0 30px 70px rgba(23,24,28,0.18), 0 0 0 1px rgba(23,24,28,0.06)",
          fontSize: `${fontSize}px`,
        }}
      >
        {/* Status bar */}
        <div className="flex items-center justify-between px-6 shrink-0" style={{ height: "44px", background: c.bg }}>
          <span className="font-bold text-[13px]" style={{ color: c.ink }}>9:41</span>
          <div className="flex items-center gap-1">
            <svg width="16" height="12" viewBox="0 0 16 12" fill={c.ink}>
              <rect x="0" y="4" width="3" height="8" rx="1" />
              <rect x="4.5" y="2.5" width="3" height="9.5" rx="1" />
              <rect x="9" y="1" width="3" height="11" rx="1" />
              <rect x="13.5" y="0" width="2.5" height="12" rx="1" opacity="0.3" />
            </svg>
            <svg width="15" height="12" viewBox="0 0 15 12" fill={c.ink}>
              <path d="M7.5 2.5C9.9 2.5 12 3.5 13.5 5.2L15 3.5C13.1 1.3 10.4 0 7.5 0S1.9 1.3 0 3.5L1.5 5.2C3 3.5 5.1 2.5 7.5 2.5Z" />
              <path d="M7.5 5.5C9 5.5 10.4 6.1 11.4 7.2L12.9 5.5C11.5 4 9.6 3 7.5 3S3.5 4 2.1 5.5L3.6 7.2C4.6 6.1 6 5.5 7.5 5.5Z" />
              <circle cx="7.5" cy="10" r="2" />
            </svg>
            <svg width="25" height="12" viewBox="0 0 25 12" fill="none">
              <rect x="0.5" y="0.5" width="21" height="11" rx="3.5" stroke={c.ink} strokeOpacity="0.3" />
              <rect x="2" y="2" width="16" height="8" rx="2" fill={c.ink} />
              <path d="M23 4v4a2 2 0 000-4z" fill={c.ink} fillOpacity="0.4" />
            </svg>
          </div>
        </div>

        {/* Screen content */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {screen === "feed" && <NewsFeedScreen {...props} />}
          {screen === "perspective" && <PerspectiveScreen {...props} />}
          {screen === "chat" && <ChatScreen {...props} />}
          {screen === "tutorial" && <TutorialScreen {...props} />}
        </div>

        {/* Bottom nav */}
        <div className="shrink-0 flex items-center justify-around px-2 pt-2 pb-5" style={{ borderTop: `${c.lineWidth} solid ${c.line}`, background: c.bg }}>
          {[
            {
              id: "feed",
              label: "뉴스",
              icon: (
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M4 22h16a2 2 0 002-2V4a2 2 0 00-2-2H8a2 2 0 00-2 2v16a2 2 0 01-2 2zm0 0a2 2 0 01-2-2v-9c0-1.1.9-2 2-2h2" />
                  <path d="M18 14h-8M15 18h-5M10 6h8v4h-8z" />
                </svg>
              ),
            },
            {
              id: "perspective",
              label: "시각 비교",
              icon: (
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 3v18M5 8l-3 4 3 4M19 8l3 4-3 4" />
                  <path d="M2 12h6M16 12h6" />
                </svg>
              ),
            },
            {
              id: "chat",
              label: "AI 질문",
              icon: (
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2a10 10 0 0110 10 10 10 0 01-10 10c-1.6 0-3.1-.4-4.5-1L2 22l1-5.5A10 10 0 012 12 10 10 0 0112 2z" />
                  <path d="M8 12h.01M12 12h.01M16 12h.01" strokeWidth="2.4" />
                </svg>
              ),
            },
            {
              id: "tutorial",
              label: "가이드",
              icon: (
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3M12 17h.01" />
                </svg>
              ),
            },
          ].map(({ id, label, icon }) => {
            const active = screen === id;
            return (
              <button
                key={id}
                onClick={() => setScreen(id as Screen)}
                className="flex flex-col items-center gap-1 px-2 transition-colors"
                style={{ color: active ? c.ink : c.faint, minWidth: "64px", minHeight: "56px", justifyContent: "center" }}
              >
                {icon}
                <span style={{ fontSize: "11px", fontWeight: active ? 700 : 500 }}>{label}</span>
                <span style={{ width: "16px", height: "2.5px", borderRadius: "2px", background: active ? c.ink : "transparent" }} />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
