// Shared design tokens for the clean, minimalist editorial CrossCheck redesign.
// Two palettes: a light (밝게) editorial look and a dark (어둡게) mode.
// `palette(dark)` returns the active set.
//
// Note the split between text and fills:
//   ink        — primary text drawn on the page background
//   primary    — fill color for primary buttons / badges / avatars
//   onPrimary  — text/icons drawn on top of a `primary` fill
// Keeping these separate lets the whole screen invert cleanly in dark mode.

export type Palette = {
  ink: string; ink2: string; faint: string;
  bg: string; surface: string; surface2: string; line: string;
  primary: string; onPrimary: string;
  blue: string; blueTint: string; blueLine: string; blueText: string;
  red: string; redTint: string; redLine: string; redText: string;
  green: string; greenTint: string; greenLine: string;
  lineWidth: string;
};

const LIGHT: Palette = {
  ink: "#17181C",
  ink2: "#5B5E66",
  faint: "#9A9CA3",
  bg: "#FFFFFF",
  surface: "#F5F5F3",
  surface2: "#FAFAF9",
  line: "#E7E7E4",
  primary: "#17181C", onPrimary: "#FFFFFF",
  blue: "#2F62D6", blueTint: "#EEF3FC", blueLine: "#CBD9F5", blueText: "#274C9E",
  red: "#C43A34", redTint: "#FBEDEB", redLine: "#F0C9C6", redText: "#8F2A25",
  green: "#2E7D53", greenTint: "#EAF4EE", greenLine: "#BFE0CC",
  lineWidth: "1px",
};

const DARK: Palette = {
  ink: "#F3F4F6",
  ink2: "#C2C6CE",
  faint: "#868B95",
  bg: "#0F1115",
  surface: "#1B1E25",
  surface2: "#16181E",
  line: "#2E323B",
  primary: "#F3F4F6", onPrimary: "#0F1115",
  blue: "#6FA3FF", blueTint: "#17233D", blueLine: "#3A5488", blueText: "#CFE0FF",
  red: "#FF8079", redTint: "#331A18", redLine: "#7A3B36", redText: "#FFCCC8",
  green: "#63D18F", greenTint: "#14301F", greenLine: "#2C6644",
  lineWidth: "1px",
};

export function palette(dark: boolean): Palette {
  return dark ? DARK : LIGHT;
}

// Discrete senior-friendly text sizes: 1 표준 · 2 크게 · 3 아주 크게
export const LEVEL_SIZE: Record<number, number> = { 1: 16, 2: 19, 3: 22 };
export const LEVEL_LABEL: Record<number, string> = { 1: "표준", 2: "크게", 3: "아주 크게" };

export const SERIF = "'Noto Serif KR', serif";
export const SANS = "'Noto Sans KR', sans-serif";
