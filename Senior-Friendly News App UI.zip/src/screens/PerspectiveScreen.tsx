import { useState } from "react";
import type { ScreenProps } from "../App";
import FontBar from "../components/FontBar";
import { palette, SERIF } from "../theme";

const VIDEOS = [
  {
    id: 1,
    title: "건강보험 개혁안, 5분 만에 이해하기",
    label: "쉬운 해설",
    duration: "5:12",
    thumb: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=320&h=180&fit=crop&auto=format",
  },
  {
    id: 2,
    title: "어르신이 꼭 알아야 할 의약품 급여 변화",
    label: "생활 정보",
    duration: "8:44",
    thumb: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=320&h=180&fit=crop&auto=format",
  },
  {
    id: 3,
    title: "여야가 보는 의료 개혁, 어떻게 다른가",
    label: "심층 비교",
    duration: "12:30",
    thumb: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=320&h=180&fit=crop&auto=format",
  },
];

export default function PerspectiveScreen({ fontSize, level, setLevel, highContrast, toggleContrast, setScreen }: ScreenProps) {
  const C = palette(highContrast);
  const [tab, setTab] = useState<"left" | "right">("left");

  const sm = `${Math.max(11, fontSize - 4)}px`;
  const body = `${Math.max(13, fontSize - 1)}px`;

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Header */}
      <div
        className="px-5 pt-2 pb-3 shrink-0 flex items-center justify-between"
        style={{ borderBottom: `1px solid ${C.line}` }}
      >
        <button
          onClick={() => setScreen("feed")}
          className="flex items-center gap-1 font-bold active:opacity-60"
          style={{ color: C.ink, fontSize: `${Math.max(14, fontSize - 1)}px`, minHeight: "48px" }}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
            <path d="M15 18l-6-6 6-6" />
          </svg>
          뒤로
        </button>
        <FontBar level={level} setLevel={setLevel} highContrast={highContrast} toggleContrast={toggleContrast} c={C} />
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-6">
        {/* Article head */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span style={{ color: C.red, fontSize: "12px", fontWeight: 800, letterSpacing: "0.6px" }}>오늘의 이슈</span>
            <span style={{ color: C.faint, fontSize: "12px" }}>· 2시간 전</span>
          </div>
          <h1 style={{ fontFamily: SERIF, color: C.ink, fontSize: `${fontSize + 9}px`, lineHeight: 1.32, fontWeight: 700 }}>
            국회, 건강보험 개혁안 놓고 여야 대립
          </h1>
          <div className="w-full overflow-hidden rounded-2xl mt-4" style={{ height: "180px", background: C.surface }}>
            <img
              src="https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&h=400&fit=crop&auto=format"
              alt="국회의사당"
              className="w-full h-full object-cover"
              style={{ display: "block" }}
            />
          </div>
        </div>

        {/* AI summary */}
        <div className="rounded-2xl p-4" style={{ background: C.surface2, border: `1px solid ${C.line}` }}>
          <div className="flex items-center gap-2.5 mb-3.5">
            <div className="flex items-center justify-center rounded-lg shrink-0" style={{ width: "34px", height: "34px", background: C.primary }}>
              <svg width="17" height="17" viewBox="0 0 24 24" fill={C.onPrimary}>
                <path d="M12 2L9.5 9.5 2 12l7.5 2.5L12 22l2.5-7.5L22 12l-7.5-2.5L12 2z" />
              </svg>
            </div>
            <div>
              <div className="font-bold" style={{ color: C.ink, fontSize: `${fontSize}px` }}>AI 3줄 요약</div>
              <div style={{ color: C.faint, fontSize: sm }}>어려운 뉴스를 쉬운 말로</div>
            </div>
          </div>
          <ol className="flex flex-col gap-3.5">
            {[
              "국회는 의약품 급여 확대를 위한 건강보험 개혁안을 표결에 부칠 예정입니다.",
              "찬성 측은 고령층 의약품 부담 완화를, 반대 측은 신약 개발 위축을 우려합니다.",
              "이번 개혁안은 전국 약 3,600만 명의 건강보험 가입자에게 직접 영향을 미칩니다.",
            ].map((line, i) => (
              <li key={i} className="flex gap-3 items-start">
                <span
                  className="shrink-0 font-bold"
                  style={{ color: C.faint, fontSize: `${fontSize + 2}px`, lineHeight: 1.4, fontFamily: SERIF }}
                >
                  {i + 1}
                </span>
                <span style={{ color: C.ink, fontSize: body, lineHeight: 1.7 }}>{line}</span>
              </li>
            ))}
          </ol>
          <button
            onClick={() => setScreen("chat")}
            className="mt-4 w-full flex items-center justify-center gap-2 rounded-xl py-3.5 font-bold transition-opacity active:opacity-80"
            style={{ background: C.primary, color: C.onPrimary, fontSize: `${Math.max(13, fontSize - 1)}px`, minHeight: "52px" }}
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <path d="M12 2a10 10 0 0110 10 10 10 0 01-10 10c-1.6 0-3.1-.4-4.5-1L2 22l1-5.5A10 10 0 012 12 10 10 0 0112 2z" />
              <path d="M8 12h.01M12 12h.01M16 12h.01" strokeWidth="2.4" />
            </svg>
            AI에게 더 물어보기
          </button>
        </div>

        {/* Perspective comparison */}
        <div>
          <h2 className="font-bold mb-1" style={{ color: C.ink, fontSize: `${fontSize + 2}px` }}>
            같은 뉴스, 두 가지 시각
          </h2>
          <p style={{ color: C.ink2, fontSize: sm, lineHeight: 1.65, marginBottom: "14px" }}>
            언론사마다 중시하는 가치가 달라 같은 사건을 다르게 전합니다. CrossCheck는 어느 편도 들지 않고 두 시각을 있는 그대로 보여드립니다.
          </p>

          {/* Segmented switcher */}
          <div className="flex rounded-xl p-1 mb-4" style={{ background: C.surface }}>
            {(["left", "right"] as const).map((t) => {
              const on = tab === t;
              const color = t === "left" ? C.blue : C.red;
              return (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className="flex-1 rounded-lg py-2.5 font-bold transition-all flex items-center justify-center gap-1.5"
                  style={{
                    fontSize: `${Math.max(12, fontSize - 3)}px`,
                    background: on ? C.bg : "transparent",
                    color: on ? color : C.ink2,
                    boxShadow: on ? "0 1px 3px rgba(23,24,28,0.1)" : "none",
                    minHeight: "46px",
                  }}
                >
                  <span className="rounded-full" style={{ width: "9px", height: "9px", background: color }} />
                  {t === "left" ? "진보·여당" : "보수·야당"}
                </button>
              );
            })}
          </div>

          {tab === "left" ? (
            <div className="rounded-2xl p-4" style={{ background: C.blueTint, border: `1px solid ${C.blueLine}` }}>
              <div style={{ color: C.blue, fontSize: "12px", fontWeight: 800, letterSpacing: "0.4px", marginBottom: "8px" }}>
                진보 · 여당 시각 — 복지·공공 이익 중시
              </div>
              <p className="font-bold mb-2" style={{ color: C.blueText, fontSize: `${fontSize + 1}px`, fontFamily: SERIF, lineHeight: 1.4 }}>
                “오래 기다려온 의료 복지의 진전”
              </p>
              <p style={{ color: C.blueText, fontSize: body, lineHeight: 1.75 }}>
                이 시각의 언론은 이번 개혁안이 약값 부담으로 고통받는 어르신을 위한 필수적 조치라고 강조합니다. 제약사 이익이 급증하는 동안 환자들이 약을 줄여 복용해야 했던 현실을 지적하며 신속한 통과를 촉구합니다.
              </p>
              <div className="mt-3.5 flex flex-wrap gap-2">
                {["건강보험 보장성 강화", "의약품 접근성 확대", "공공 이익 우선"].map((k) => (
                  <span key={k} className="rounded-full font-bold" style={{ background: C.bg, color: C.blueText, fontSize: sm, padding: "6px 12px", border: `1px solid ${C.blueLine}` }}>
                    {k}
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <div className="rounded-2xl p-4" style={{ background: C.redTint, border: `1px solid ${C.redLine}` }}>
              <div style={{ color: C.red, fontSize: "12px", fontWeight: 800, letterSpacing: "0.4px", marginBottom: "8px" }}>
                보수 · 야당 시각 — 시장·경제 자율 중시
              </div>
              <p className="font-bold mb-2" style={{ color: C.redText, fontSize: `${fontSize + 1}px`, fontFamily: SERIF, lineHeight: 1.4 }}>
                “정부 개입이 신약 개발 의지를 꺾는다”
              </p>
              <p style={{ color: C.redText, fontSize: body, lineHeight: 1.75 }}>
                이 시각의 언론은 가격 통제가 제약사의 연구개발 투자를 위축시킬 수 있다고 경고합니다. 민간 시장에 대한 정부 개입의 전례를 우려하며, 향후 신약 접근성이 오히려 줄어들 수 있다고 주장합니다.
              </p>
              <div className="mt-3.5 flex flex-wrap gap-2">
                {["시장 자율 해결", "신약 개발 투자 보호", "정부 역할 최소화"].map((k) => (
                  <span key={k} className="rounded-full font-bold" style={{ background: C.bg, color: C.redText, fontSize: sm, padding: "6px 12px", border: `1px solid ${C.redLine}` }}>
                    {k}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Related videos */}
        <div>
          <h2 className="font-bold mb-3" style={{ color: C.ink, fontSize: `${fontSize + 1}px` }}>관련 영상</h2>
          <div className="flex gap-3 overflow-x-auto pb-1" style={{ marginRight: "-20px", paddingRight: "20px" }}>
            {VIDEOS.map((v) => (
              <div key={v.id} className="shrink-0" style={{ width: "210px" }}>
                <div className="relative overflow-hidden rounded-xl" style={{ height: "118px", background: C.surface }}>
                  <img src={v.thumb} alt={v.title} className="w-full h-full object-cover" style={{ display: "block" }} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="flex items-center justify-center rounded-full" style={{ width: "42px", height: "42px", background: "rgba(23,24,28,0.6)", backdropFilter: "blur(3px)" }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="#fff"><polygon points="6 4 20 12 6 20 6 4" /></svg>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 rounded font-bold text-white" style={{ background: "rgba(23,24,28,0.75)", fontSize: "11px", padding: "2px 6px" }}>
                    {v.duration}
                  </div>
                </div>
                <p className="font-bold mt-2" style={{ color: C.ink, fontSize: `${Math.max(13, fontSize - 2)}px`, lineHeight: 1.5 }}>
                  {v.title}
                </p>
                <p style={{ color: C.faint, fontSize: sm, marginTop: "3px" }}>{v.label}</p>
              </div>
            ))}
          </div>
        </div>

        <div style={{ height: "8px" }} />
      </div>
    </div>
  );
}
