import { useState, useRef, useEffect } from "react";
import type { ScreenProps } from "../App";
import FontBar from "../components/FontBar";
import { palette } from "../theme";

interface Message {
  id: number;
  role: "user" | "ai";
  text: string;
}

const INITIAL_MESSAGES: Message[] = [
  {
    id: 1,
    role: "ai",
    text: "안녕하세요! 오늘의 건강보험 개혁 뉴스에 대해 쉽게 설명해 드릴게요. 궁금한 것이 있으시면 언제든지 물어보세요.",
  },
];

const PROMPTS = ["3줄 요약", "어려운 단어 설명", "왜 중요한가요?"];

const AI_RESPONSES: Record<string, string> = {
  "3줄 요약":
    "① 국회가 의약품 급여를 늘리는 건강보험 개혁안을 논의하고 있습니다.\n② 찬성 측은 어르신 약값 부담 완화를, 반대 측은 신약 개발 위축을 우려합니다.\n③ 표결은 이번 주 본회의에서 이루어질 예정이며, 결과에 따라 약값이 크게 달라질 수 있습니다.",
  "어려운 단어 설명":
    "건강보험: 아플 때 병원비와 약값을 나라가 함께 부담해주는 제도입니다.\n급여 확대: 지금보다 더 많은 약과 치료가 건강보험 혜택을 받게 되는 것입니다.\n제약사 R&D: 새로운 약을 연구하고 개발하는 활동으로, 막대한 비용이 필요합니다.",
  "왜 중요한가요?":
    "이 법이 통과되면 현재 직접 부담하시는 약값이 크게 줄어들 수 있습니다. 특히 고혈압·당뇨 등 만성질환 약을 꾸준히 드시는 어르신들께 가장 큰 혜택이 돌아갑니다. 지난 10년 사이 가장 큰 의료 복지 변화 중 하나입니다.",
};

export default function ChatScreen({ fontSize, level, setLevel, highContrast, toggleContrast, setScreen }: ScreenProps) {
  const C = palette(highContrast);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const [isListening, setIsListening] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    setMessages((m) => [...m, { id: Date.now(), role: "user", text }]);
    setInput("");
    setIsTyping(true);
    setTimeout(() => {
      setIsTyping(false);
      const response =
        AI_RESPONSES[text] ||
        "좋은 질문이세요! 이 기사에서 핵심은 정부 정책이 일상적인 의료비에 미치는 영향입니다. 혹시 더 구체적으로 궁금한 부분이 있으신가요?";
      setMessages((m) => [...m, { id: Date.now() + 1, role: "ai", text: response }]);
    }, 1200);
  };

  const toggleMic = () => {
    setIsListening((v) => !v);
    if (!isListening) {
      setTimeout(() => {
        setIsListening(false);
        sendMessage("왜 중요한가요?");
      }, 2000);
    }
  };

  const AiAvatar = ({ size }: { size: number }) => (
    <div className="flex items-center justify-center rounded-lg shrink-0" style={{ width: size, height: size, background: C.primary }}>
      <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill={C.onPrimary}>
        <path d="M12 2L9.5 9.5 2 12l7.5 2.5L12 22l2.5-7.5L22 12l-7.5-2.5L12 2z" />
      </svg>
    </div>
  );

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Header */}
      <div className="px-5 pt-2 pb-3 shrink-0" style={{ borderBottom: `1px solid ${C.line}` }}>
        <div className="flex items-center justify-between mb-3">
          <button
            onClick={() => setScreen("perspective")}
            className="flex items-center gap-1 font-bold active:opacity-60"
            style={{ color: C.ink, fontSize: `${Math.max(14, fontSize - 1)}px`, minHeight: "48px" }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
              <path d="M15 18l-6-6 6-6" />
            </svg>
            뒤로
          </button>
          <FontBar level={level} setLevel={setLevel} highContrast={highContrast} toggleContrast={toggleContrast} c={C} />
        </div>
        <div className="flex items-center gap-3">
          <AiAvatar size={44} />
          <div>
            <h1 className="font-bold leading-tight" style={{ color: C.ink, fontSize: `${fontSize + 1}px` }}>
              AI에게 물어보기
            </h1>
            <p style={{ color: C.faint, fontSize: `${Math.max(11, fontSize - 4)}px`, marginTop: "2px" }}>
              쉬운 말로 친절하게 답해드려요
            </p>
          </div>
        </div>
      </div>

      {/* Preset chips */}
      <div className="px-5 py-3 flex gap-2 overflow-x-auto shrink-0" style={{ borderBottom: `1px solid ${C.line}` }}>
        {PROMPTS.map((label) => (
          <button
            key={label}
            onClick={() => sendMessage(label)}
            className="shrink-0 rounded-full px-4 font-bold transition-colors active:bg-[#F0F0EE]"
            style={{
              background: C.bg,
              color: C.ink,
              border: `1.5px solid ${C.line}`,
              fontSize: `${Math.max(13, fontSize - 2)}px`,
              minHeight: "44px",
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-5 py-4 flex flex-col gap-3.5" style={{ background: C.surface2 }}>
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} items-end gap-2`}>
            {msg.role === "ai" && <AiAvatar size={30} />}
            <div
              className="px-4 py-3"
              style={{
                maxWidth: "80%",
                background: msg.role === "user" ? C.primary : C.bg,
                color: msg.role === "user" ? C.onPrimary : C.ink,
                border: msg.role === "ai" ? `1px solid ${C.line}` : "none",
                fontSize: `${fontSize}px`,
                lineHeight: 1.7,
                borderRadius: msg.role === "user" ? "18px 18px 4px 18px" : "4px 18px 18px 18px",
                whiteSpace: "pre-line",
              }}
            >
              {msg.text}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex items-end gap-2">
            <AiAvatar size={30} />
            <div className="flex items-center gap-1.5 px-4 py-3.5" style={{ background: C.bg, border: `1px solid ${C.line}`, borderRadius: "4px 18px 18px 18px" }}>
              {[0, 1, 2].map((i) => (
                <div key={i} className="rounded-full" style={{ width: "7px", height: "7px", background: C.faint, animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite` }} />
              ))}
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <div className="px-5 py-3 shrink-0" style={{ borderTop: `1px solid ${C.line}`, background: C.bg }}>
        <div className="flex items-center gap-2.5">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage(input)}
            placeholder="궁금한 점을 입력하세요..."
            className="flex-1 rounded-full px-5 font-medium outline-none"
            style={{
              background: C.surface,
              color: C.ink,
              fontSize: `${Math.max(14, fontSize - 1)}px`,
              border: `1.5px solid transparent`,
              minHeight: "52px",
            }}
          />
          {input.trim() ? (
            <button
              onClick={() => sendMessage(input)}
              className="flex items-center justify-center rounded-full transition-transform active:scale-90 shrink-0"
              style={{ width: "52px", height: "52px", background: C.primary }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={C.onPrimary} strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round">
                <path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7z" />
              </svg>
            </button>
          ) : (
            <button
              onClick={toggleMic}
              className="flex items-center justify-center rounded-full transition-transform active:scale-90 shrink-0"
              style={{
                width: "54px",
                height: "54px",
                background: isListening ? C.red : C.primary,
                animation: isListening ? "pulse 1.2s ease-in-out infinite" : "none",
              }}
            >
              <svg width="23" height="23" viewBox="0 0 24 24" fill="none" stroke={C.onPrimary} strokeWidth="2" strokeLinecap="round">
                <path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" />
                <path d="M19 10v2a7 7 0 01-14 0v-2M12 19v4M8 23h8" />
              </svg>
            </button>
          )}
        </div>
        {isListening && (
          <div className="flex items-center gap-2 mt-2.5 pl-1">
            <div className="flex gap-1 items-center">
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="rounded-full" style={{ width: "4px", background: C.red, animation: `waveBar 0.7s ease-in-out ${i * 0.12}s infinite alternate`, height: `${12 + i * 4}px` }} />
              ))}
            </div>
            <span style={{ color: C.red, fontSize: `${Math.max(12, fontSize - 3)}px`, fontWeight: 700 }}>듣는 중...</span>
          </div>
        )}
      </div>
    </div>
  );
}
