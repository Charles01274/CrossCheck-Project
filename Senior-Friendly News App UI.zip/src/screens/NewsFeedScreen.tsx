import { useState } from "react";
import type { ScreenProps } from "../App";
import FontBar from "../components/FontBar";
import { palette, SERIF } from "../theme";

const CATEGORIES = ["오늘의 이슈", "정치", "사회", "경제"];

const NEWS = [
  {
    id: 1,
    tag: "오늘의 이슈",
    title: "국회, 건강보험 개혁안 놓고 여야 대립",
    summary: "의약품 가격 인하와 급여 확대를 둘러싼 여야 충돌이 본회의 표결을 앞두고 격화되고 있습니다.",
    image: "https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&h=500&fit=crop&auto=format",
    time: "2시간 전",
    perspectives: 4,
  },
  {
    id: 2,
    tag: "경제",
    title: "한국은행, 기준금리 3개월째 동결 결정",
    summary: "물가·성장 혼조 속에 한은 금통위가 연 3.25% 금리를 유지하기로 했습니다.",
    image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&h=400&fit=crop&auto=format",
    time: "4시간 전",
    perspectives: 6,
  },
  {
    id: 3,
    tag: "사회",
    title: "60대 이상 스마트폰 과다 사용, 수면 질 저하 연관",
    summary: "연구진은 취침 2시간 전 화면 사용을 줄이면 수면의 질이 크게 개선된다고 밝혔습니다.",
    image: "https://images.unsplash.com/photo-1498837167922-ddd27525d352?w=400&h=400&fit=crop&auto=format",
    time: "6시간 전",
    perspectives: 3,
  },
  {
    id: 4,
    tag: "정치",
    title: "지방선거 사전투표율 역대 최고 경신",
    summary: "4년 전 대비 18% 상승한 투표율로, 유권자들의 높은 관심이 반영됐습니다.",
    image: "https://images.unsplash.com/photo-1540910419892-4a36d2c3266c?w=400&h=400&fit=crop&auto=format",
    time: "8시간 전",
    perspectives: 5,
  },
];

function PerspectiveDots({ blue, red, bg }: { blue: string; red: string; bg: string }) {
  return (
    <div className="flex -space-x-1">
      <div className="rounded-full border-2" style={{ width: "16px", height: "16px", background: blue, borderColor: bg }} />
      <div className="rounded-full border-2" style={{ width: "16px", height: "16px", background: red, borderColor: bg }} />
    </div>
  );
}

export default function NewsFeedScreen({ fontSize, level, setLevel, highContrast, toggleContrast, setScreen }: ScreenProps) {
  const C = palette(highContrast);
  const [activeTab, setActiveTab] = useState(0);
  const filtered = activeTab === 0 ? NEWS : NEWS.filter((n) => n.tag === CATEGORIES[activeTab]);
  const [lead, ...rest] = filtered;

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Masthead */}
      <div className="px-5 pt-2 pb-3 shrink-0" style={{ borderBottom: `1px solid ${C.line}` }}>
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <div
                className="flex items-center justify-center rounded-lg shrink-0"
                style={{ width: "30px", height: "30px", background: C.primary }}
              >
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke={C.onPrimary} strokeWidth="2" strokeLinecap="round">
                  <path d="M12 3v18M5 8l-3 4 3 4M19 8l3 4-3 4" />
                </svg>
              </div>
              <span style={{ fontFamily: SERIF, fontSize: "23px", color: C.ink, fontWeight: 700, letterSpacing: "-0.5px" }}>
                CrossCheck
              </span>
            </div>
            <p style={{ color: C.faint, fontSize: "11px", marginTop: "3px", letterSpacing: "0.2px" }}>
              9월 21일 일요일 · 균형 잡힌 뉴스
            </p>
          </div>
          <FontBar level={level} setLevel={setLevel} highContrast={highContrast} toggleContrast={toggleContrast} c={C} />
        </div>

        {/* Category tabs — underlined text */}
        <div className="flex gap-5 mt-4 overflow-x-auto">
          {CATEGORIES.map((cat, i) => {
            const on = activeTab === i;
            return (
              <button
                key={cat}
                onClick={() => setActiveTab(i)}
                className="shrink-0 pb-1.5 transition-colors"
                style={{
                  fontSize: `${Math.max(14, fontSize - 1)}px`,
                  color: on ? C.ink : C.faint,
                  fontWeight: on ? 700 : 500,
                  borderBottom: on ? `2.5px solid ${C.ink}` : "2.5px solid transparent",
                }}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Feed */}
      <div className="flex-1 overflow-y-auto px-5 py-5">
        {/* Lead story */}
        {lead && (
          <button
            onClick={() => setScreen("perspective")}
            className="w-full text-left transition-opacity active:opacity-70"
          >
            <div className="w-full overflow-hidden rounded-2xl" style={{ height: "196px", background: C.surface }}>
              <img src={lead.image} alt={lead.title} className="w-full h-full object-cover" style={{ display: "block" }} />
            </div>
            <div className="flex items-center gap-2 mt-3.5">
              <span style={{ color: C.red, fontSize: "12px", fontWeight: 800, letterSpacing: "0.6px" }}>
                {lead.tag.toUpperCase()}
              </span>
              <span style={{ color: C.faint, fontSize: "12px" }}>· {lead.time}</span>
            </div>
            <h2
              style={{ fontFamily: SERIF, color: C.ink, fontSize: `${fontSize + 8}px`, lineHeight: 1.35, fontWeight: 700, marginTop: "6px" }}
            >
              {lead.title}
            </h2>
            <p style={{ color: C.ink2, fontSize: `${fontSize}px`, lineHeight: 1.7, marginTop: "8px" }}>
              {lead.summary}
            </p>
            <div className="flex items-center gap-2 mt-3">
              <PerspectiveDots blue={C.blue} red={C.red} bg={C.bg} />
              <span style={{ color: C.ink, fontSize: `${Math.max(12, fontSize - 3)}px`, fontWeight: 600 }}>
                {lead.perspectives}개 시각 비교
              </span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={C.ink} strokeWidth="2.4" strokeLinecap="round" style={{ marginLeft: "-2px" }}>
                <path d="M9 18l6-6-6-6" />
              </svg>
            </div>
          </button>
        )}

        {rest.length > 0 && <div style={{ height: "22px", borderBottom: `1px solid ${C.line}`, marginBottom: "4px" }} />}

        {/* List rows */}
        <div className="flex flex-col">
          {rest.map((item, idx) => (
            <button
              key={item.id}
              onClick={() => setScreen("perspective")}
              className="w-full text-left flex gap-4 py-4 transition-opacity active:opacity-60"
              style={{ borderTop: idx === 0 ? "none" : `1px solid ${C.line}` }}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5">
                  <span style={{ color: C.blue, fontSize: "11px", fontWeight: 800, letterSpacing: "0.5px" }}>
                    {item.tag.toUpperCase()}
                  </span>
                  <span style={{ color: C.faint, fontSize: "11px" }}>· {item.time}</span>
                </div>
                <h3 className="font-bold" style={{ color: C.ink, fontSize: `${fontSize + 1}px`, lineHeight: 1.45 }}>
                  {item.title}
                </h3>
                <div className="flex items-center gap-1.5 mt-2.5">
                  <PerspectiveDots blue={C.blue} red={C.red} bg={C.bg} />
                  <span style={{ color: C.ink2, fontSize: `${Math.max(11, fontSize - 4)}px`, fontWeight: 600 }}>
                    {item.perspectives}개 시각
                  </span>
                </div>
              </div>
              <div className="shrink-0 overflow-hidden rounded-xl" style={{ width: "92px", height: "92px", background: C.surface }}>
                <img src={item.image} alt={item.title} className="w-full h-full object-cover" style={{ display: "block" }} />
              </div>
            </button>
          ))}
        </div>
        <div style={{ height: "8px" }} />
      </div>
    </div>
  );
}
