import { useState } from "react";
import type { ScreenProps } from "../App";
import FontBar from "../components/FontBar";
import { palette, SERIF, type Palette } from "../theme";

// Flat, high-contrast font control used inside the live font-size demo.
function TutorialFontBtn({
  label, size, fontSize, variant, onClick, C,
}: {
  label: string;
  size: number;
  fontSize: number;
  variant: "minus" | "plus" | "done";
  onClick: () => void;
  C: Palette;
}) {
  const bg = variant === "done" ? C.green : variant === "plus" ? C.primary : C.bg;
  const fg = variant === "minus" ? C.ink : variant === "done" ? "#FFFFFF" : C.onPrimary;
  const border = variant === "minus" ? `1.5px solid ${C.line}` : "none";
  const radius = Math.round(size * 0.26);

  return (
    <button
      onClick={onClick}
      className="flex items-center justify-center transition-transform active:scale-95"
      style={{ width: `${size}px`, height: `${size}px`, borderRadius: `${radius}px`, background: bg, border, color: fg }}
    >
      <span style={{ fontWeight: 800, fontSize: `${fontSize}px`, lineHeight: 1, letterSpacing: "-0.5px" }}>{label}</span>
    </button>
  );
}

const TOTAL = 4;

export default function TutorialScreen({ fontSize, level, setLevel, highContrast, toggleContrast, setScreen }: ScreenProps) {
  const C = palette(highContrast);
  const [step, setStep] = useState(0);
  const [done, setDone] = useState(false);

  const [fontDemoSize, setFontDemoSize] = useState(16);
  const [fontTapped, setFontTapped] = useState(false);
  const [perspectiveTab, setPerspectiveTab] = useState<"left" | "right" | null>(null);
  const [micActive, setMicActive] = useState(false);
  const [micDone, setMicDone] = useState(false);
  const [cardTapped, setCardTapped] = useState(false);
  const [tappedLeft, setTappedLeft] = useState(false);
  const [tappedRight, setTappedRight] = useState(false);

  const goNext = () => {
    if (!done) return;
    if (step === TOTAL - 1) { setScreen("feed"); return; }
    setStep((s) => s + 1);
    setDone(false);
  };
  const goPrev = () => {
    if (step === 0) return;
    setStep((s) => s - 1);
    setDone(true);
  };

  const handleCardTap = () => { setCardTapped(true); setDone(true); };
  const handleFontIncrease = () => { setFontDemoSize((f) => Math.min(26, f + 2)); setFontTapped(true); setDone(true); };
  const handleFontDecrease = () => setFontDemoSize((f) => Math.max(12, f - 2));
  const handlePerspective = (side: "left" | "right") => {
    setPerspectiveTab(side);
    if (side === "left") setTappedLeft(true);
    if (side === "right") setTappedRight(true);
  };
  if (step === 2 && tappedLeft && tappedRight && !done) setDone(true);
  const handleMic = () => {
    if (micDone) return;
    setMicActive(true);
    setTimeout(() => { setMicActive(false); setMicDone(true); setDone(true); }, 2200);
  };

  const sm = `${Math.max(11, fontSize - 4)}px`;
  const body = `${Math.max(13, fontSize - 1)}px`;

  const stepMeta = [
    { number: 1, title: "뉴스 카드 눌러보기", subtitle: "기사를 탭하면 어떻게 되는지 확인해요" },
    { number: 2, title: "글씨 크기 조절하기", subtitle: "눈에 편한 크기로 바꿀 수 있어요" },
    { number: 3, title: "두 시각 비교하기", subtitle: "진보·보수 두 탭을 모두 눌러보세요" },
    { number: 4, title: "AI에게 말로 물어보기", subtitle: "마이크를 눌러 직접 체험해 보세요" },
  ][step];

  // Neutral instruction callout
  const Callout = ({ children }: { children: React.ReactNode }) => (
    <div className="rounded-xl px-4 py-3" style={{ background: C.surface, border: `1px solid ${C.line}` }}>
      <p style={{ color: C.ink, fontSize: body, lineHeight: 1.65 }}>{children}</p>
    </div>
  );

  // Success banner
  const Success = ({ children }: { children: React.ReactNode }) => (
    <div className="rounded-xl px-4 py-3 flex items-center gap-2.5" style={{ background: C.greenTint, border: `1px solid ${C.greenLine}` }}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={C.green} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
        <path d="M20 6L9 17l-5-5" />
      </svg>
      <p className="font-bold" style={{ color: C.green, fontSize: body }}>{children}</p>
    </div>
  );

  return (
    <div className="flex flex-col flex-1 overflow-hidden">
      {/* Header */}
      <div className="px-5 pt-2 pb-3 shrink-0 flex items-center justify-between" style={{ borderBottom: `1px solid ${C.line}` }}>
        <div>
          <h1 style={{ fontFamily: SERIF, color: C.ink, fontSize: `${fontSize + 4}px`, fontWeight: 700, letterSpacing: "-0.3px" }}>
            사용 가이드
          </h1>
          <p style={{ color: C.faint, fontSize: sm, marginTop: "2px" }}>직접 눌러보며 배워요</p>
        </div>
        <FontBar level={level} setLevel={setLevel} highContrast={highContrast} toggleContrast={toggleContrast} c={C} />
      </div>

      <div className="flex-1 overflow-y-auto px-5 py-5 flex flex-col gap-5">
        {/* Progress */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span style={{ color: C.ink, fontSize: sm, fontWeight: 700 }}>
              {step + 1} / {TOTAL} 단계
            </span>
            <span style={{ color: done ? C.green : C.faint, fontSize: sm, fontWeight: 600 }}>
              {done ? "완료됨" : "아래를 눌러보세요"}
            </span>
          </div>
          <div className="flex gap-1.5">
            {Array.from({ length: TOTAL }).map((_, i) => {
              const filled = i < step || (i === step && done);
              return (
                <div key={i} className="flex-1 rounded-full transition-all duration-500" style={{ height: "6px", background: filled ? C.ink : C.line }} />
              );
            })}
          </div>
        </div>

        {/* Step header */}
        <div className="flex items-center gap-3.5">
          <div
            className="flex items-center justify-center rounded-full font-bold shrink-0"
            style={{ width: "44px", height: "44px", background: C.primary, color: C.onPrimary, fontSize: `${fontSize + 2}px`, fontFamily: SERIF }}
          >
            {stepMeta.number}
          </div>
          <div>
            <p className="font-bold" style={{ color: C.ink, fontSize: `${fontSize + 2}px` }}>{stepMeta.title}</p>
            <p style={{ color: C.ink2, fontSize: sm, marginTop: "1px" }}>{stepMeta.subtitle}</p>
          </div>
        </div>

        {/* STEP 0 */}
        {step === 0 && (
          <div className="flex flex-col gap-4">
            <Callout>아래 뉴스 카드를 <strong>한 번 눌러보세요.</strong> 기사 상세 화면으로 이동합니다.</Callout>
            <button
              onClick={handleCardTap}
              className="rounded-2xl overflow-hidden text-left w-full transition-all active:scale-97"
              style={{ background: C.bg, border: cardTapped ? `2px solid ${C.green}` : `2px dashed ${C.ink}` }}
            >
              <div style={{ height: "150px", background: C.surface, overflow: "hidden" }}>
                <img src="https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&h=300&fit=crop&auto=format" alt="국회의사당" className="w-full h-full object-cover" style={{ display: "block" }} />
              </div>
              <div className="px-4 py-3.5">
                <div className="flex items-center gap-2 mb-1.5">
                  <span style={{ color: C.red, fontSize: "11px", fontWeight: 800, letterSpacing: "0.5px" }}>오늘의 이슈</span>
                  <span style={{ color: C.faint, fontSize: "11px" }}>· 2시간 전</span>
                </div>
                <p className="font-bold" style={{ color: C.ink, fontSize: `${fontSize + 1}px`, lineHeight: 1.45 }}>
                  국회, 건강보험 개혁안 놓고 여야 대립
                </p>
              </div>
            </button>
            {cardTapped && <Success>잘 하셨어요! 뉴스 카드를 누르면 자세한 내용을 볼 수 있어요.</Success>}
          </div>
        )}

        {/* STEP 1 */}
        {step === 1 && (
          <div className="flex flex-col gap-4">
            <Callout>아래 <strong>A+ 버튼</strong>을 눌러 글씨를 크게 만들어 보세요.</Callout>
            <div
              className="rounded-2xl p-5 flex flex-col gap-5"
              style={{ background: C.bg, border: fontTapped ? `2px solid ${C.green}` : `2px dashed ${C.ink}` }}
            >
              <p className="font-bold text-center" style={{ color: C.ink, fontSize: `${fontDemoSize}px`, lineHeight: 1.5 }}>
                글씨 크기가 바뀝니다.{"\n"}이 문장을 보세요.
              </p>
              <div className="flex items-center justify-center gap-6">
                <TutorialFontBtn label="A−" size={56} fontSize={Math.max(15, fontSize - 1)} variant="minus" onClick={handleFontDecrease} C={C} />
                <div className="flex flex-col items-center" style={{ minWidth: "48px" }}>
                  <span style={{ color: C.faint, fontSize: "11px" }}>현재 크기</span>
                  <span className="font-bold" style={{ color: C.ink, fontSize: "24px", fontFamily: SERIF }}>{fontDemoSize}</span>
                </div>
                <TutorialFontBtn label="A+" size={66} fontSize={Math.max(18, fontSize + 2)} variant={fontTapped ? "done" : "plus"} onClick={handleFontIncrease} C={C} />
              </div>
            </div>
            {fontTapped && <Success>잘 하셨어요! 모든 화면 오른쪽 위에서 항상 조절할 수 있어요.</Success>}
          </div>
        )}

        {/* STEP 2 */}
        {step === 2 && (
          <div className="flex flex-col gap-4">
            <Callout><strong>파란 버튼</strong>과 <strong>빨간 버튼</strong>을 모두 눌러 두 시각의 차이를 확인해 보세요.</Callout>
            <div className="flex rounded-xl p-1" style={{ background: C.surface }}>
              {(["left", "right"] as const).map((t) => {
                const tapped = t === "left" ? tappedLeft : tappedRight;
                const on = perspectiveTab === t;
                const color = t === "left" ? C.blue : C.red;
                return (
                  <button
                    key={t}
                    onClick={() => handlePerspective(t)}
                    className="flex-1 rounded-lg py-3 font-bold transition-all flex items-center justify-center gap-1.5"
                    style={{
                      fontSize: `${Math.max(13, fontSize - 2)}px`,
                      background: on ? C.bg : "transparent",
                      color: on ? color : C.ink2,
                      boxShadow: on ? "0 1px 3px rgba(23,24,28,0.1)" : "none",
                      minHeight: "50px",
                    }}
                  >
                    <span className="rounded-full" style={{ width: "9px", height: "9px", background: tapped ? C.green : color }} />
                    {t === "left" ? "진보·여당" : "보수·야당"}
                  </button>
                );
              })}
            </div>
            {perspectiveTab === "left" && (
              <div className="rounded-2xl p-4" style={{ background: C.blueTint, border: `1px solid ${C.blueLine}` }}>
                <p className="font-bold mb-2" style={{ color: C.blueText, fontSize: `${fontSize}px`, fontFamily: SERIF }}>“오래 기다려온 의료 복지의 진전”</p>
                <p style={{ color: C.blueText, fontSize: body, lineHeight: 1.75 }}>
                  진보 언론은 이번 개혁안이 약값 부담으로 고통받는 어르신을 위한 필수 조치라고 강조합니다.
                </p>
              </div>
            )}
            {perspectiveTab === "right" && (
              <div className="rounded-2xl p-4" style={{ background: C.redTint, border: `1px solid ${C.redLine}` }}>
                <p className="font-bold mb-2" style={{ color: C.redText, fontSize: `${fontSize}px`, fontFamily: SERIF }}>“정부 개입이 신약 개발 의지를 꺾는다”</p>
                <p style={{ color: C.redText, fontSize: body, lineHeight: 1.75 }}>
                  보수 언론은 가격 통제가 제약사의 연구개발 투자를 위축시킬 수 있다고 경고합니다.
                </p>
              </div>
            )}
            {!perspectiveTab && (
              <div className="rounded-2xl p-4 flex items-center justify-center" style={{ background: C.surface2, border: `1.5px dashed ${C.line}`, minHeight: "80px" }}>
                <p style={{ color: C.faint, fontSize: body }}>위 버튼을 누르면 내용이 나타납니다</p>
              </div>
            )}
            {tappedLeft && tappedRight && <Success>두 시각을 모두 확인하셨어요! 이제 편향 없이 뉴스를 읽을 수 있어요.</Success>}
          </div>
        )}

        {/* STEP 3 */}
        {step === 3 && (
          <div className="flex flex-col gap-4">
            <Callout>아래 <strong>마이크 버튼</strong>을 눌러보세요. AI가 말을 듣고 답해줍니다.</Callout>
            <div
              className="rounded-2xl p-5 flex flex-col gap-3.5"
              style={{ background: C.bg, border: micDone ? `2px solid ${C.green}` : `2px dashed ${C.ink}` }}
            >
              <div className="flex items-end gap-2">
                <div className="flex items-center justify-center rounded-lg shrink-0" style={{ width: "30px", height: "30px", background: C.primary }}>
                  <svg width="15" height="15" viewBox="0 0 24 24" fill={C.onPrimary}><path d="M12 2L9.5 9.5 2 12l7.5 2.5L12 22l2.5-7.5L22 12l-7.5-2.5L12 2z" /></svg>
                </div>
                <div className="px-4 py-3" style={{ background: C.surface, borderRadius: "4px 18px 18px 18px", maxWidth: "82%" }}>
                  <p style={{ color: C.ink, fontSize: body, lineHeight: 1.7 }}>
                    {micDone
                      ? "이번 건강보험 개혁은 많은 어르신의 약값을 낮춰드리는 중요한 법안입니다. 쉽게 말씀드리면, 지금보다 더 적은 돈으로 약을 살 수 있게 해주는 제도예요."
                      : "안녕하세요! 마이크를 눌러 궁금한 것을 말씀해 보세요."}
                  </p>
                </div>
              </div>
              {(micActive || micDone) && (
                <div className="flex justify-end">
                  <div className="px-4 py-3" style={{ background: C.primary, borderRadius: "18px 18px 4px 18px", maxWidth: "75%" }}>
                    <p style={{ color: C.onPrimary, fontSize: body, lineHeight: 1.7 }}>이 뉴스 쉽게 설명해줘</p>
                  </div>
                </div>
              )}
              {micActive && (
                <div className="flex items-center gap-2 pl-10">
                  {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="rounded-full" style={{ width: "4px", background: C.ink, animation: `waveBar 0.7s ${i * 0.12}s ease-in-out infinite alternate`, height: `${10 + i * 3}px` }} />
                  ))}
                  <span style={{ color: C.ink, fontSize: sm, fontWeight: 700, marginLeft: "4px" }}>듣는 중...</span>
                </div>
              )}
              <div className="flex flex-col items-center gap-2 pt-1">
                {!micDone && <p style={{ color: C.faint, fontSize: sm }}>이 버튼을 눌러보세요</p>}
                <button
                  onClick={handleMic}
                  disabled={micDone}
                  className="flex items-center justify-center rounded-full transition-transform active:scale-90"
                  style={{
                    width: "72px",
                    height: "72px",
                    background: micDone ? C.green : micActive ? C.red : C.primary,
                    animation: micActive ? "pulse 1.2s ease-in-out infinite" : "none",
                    cursor: micDone ? "default" : "pointer",
                  }}
                >
                  {micDone ? (
                    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
                  ) : (
                    <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={C.onPrimary} strokeWidth="2" strokeLinecap="round">
                      <path d="M12 1a3 3 0 00-3 3v8a3 3 0 006 0V4a3 3 0 00-3-3z" />
                      <path d="M19 10v2a7 7 0 01-14 0v-2M12 19v4M8 23h8" />
                    </svg>
                  )}
                </button>
              </div>
            </div>
            {micDone && <Success>훌륭하세요! 이제 CrossCheck를 자유롭게 사용하실 수 있어요.</Success>}
          </div>
        )}

        {/* Navigation */}
        <div className="flex gap-3 pt-1">
          {step > 0 && (
            <button
              onClick={goPrev}
              className="flex-1 rounded-2xl py-4 font-bold transition-transform active:scale-95"
              style={{ background: C.bg, color: C.ink, fontSize: `${fontSize}px`, border: `1.5px solid ${C.line}`, minHeight: "58px" }}
            >
              이전
            </button>
          )}
          <button
            onClick={goNext}
            disabled={!done}
            className="flex-1 rounded-2xl py-4 font-bold transition-transform active:scale-95"
            style={{
              background: !done ? C.surface : step === TOTAL - 1 ? C.green : C.primary,
              color: !done ? C.faint : step === TOTAL - 1 ? "#fff" : C.onPrimary,
              fontSize: `${fontSize}px`,
              minHeight: "58px",
              cursor: done ? "pointer" : "not-allowed",
            }}
          >
            {!done ? "위 과제를 먼저 해보세요" : step === TOTAL - 1 ? "앱 사용 시작하기" : "다음 단계"}
          </button>
        </div>
        <div style={{ height: "4px" }} />
      </div>
    </div>
  );
}
